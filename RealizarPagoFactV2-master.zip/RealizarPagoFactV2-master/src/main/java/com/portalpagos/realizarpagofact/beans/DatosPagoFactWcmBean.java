package com.portalpagos.realizarpagofact.beans;

import java.io.Serializable;
import java.util.ResourceBundle;

import javax.portlet.PortletSession;
import javax.portlet.RenderRequest;

import co.com.ath.logger.CustomLogger;
import co.com.ath.payments.mc.auditor.publisher.util.PublisherUtil;
import co.com.ath.payments.mc.service.model.ErrorData;

import com.ath.portalpagos.util.ExceptionManager;
import com.ath.portalpagos.util.Modal;
import com.co.pragma.portal.utils.WCMCliente;
import com.ibm.workplace.wcm.api.FileComponent;
import com.ibm.workplace.wcm.api.exceptions.WCMException;


/** HU21, HU44
 * ManagedBean utilizado para almacenar los datos del pago necesarios para los forms de Captura de Referencia de Pago 
 * y Confirmación de Pago
 * @author: Mélany Rozo
 * @Since: 04/11/14
 **/

public class DatosPagoFactWcmBean implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private String labelTerminosCondiciones;
	
	private String tituloModalTyC;
	
	private String mensajeModalTyC;
	
	private String pdfTyC;
	
	private String heightModalCondiciones;
	
	private String widhtModalCondiciones;
	
	private String intentosMaxCaptcha;
	
	private String errorCaptcha;
	
	public DatosPagoFactWcmBean(){

	}
		
	public String getHeightModalCondiciones() {
		return heightModalCondiciones;
	}

	public void setHeightModalCondiciones(String heightModalCondiciones) {
		this.heightModalCondiciones = heightModalCondiciones;
	}

	public String getWidhtModalCondiciones() {
		return widhtModalCondiciones;
	}

	public void setWidhtModalCondiciones(String widhtModalCondiciones) {
		this.widhtModalCondiciones = widhtModalCondiciones;
	}

	public String getLabelTerminosCondiciones() {
		return labelTerminosCondiciones;
	}

	public void setLabelTerminosCondiciones(String labelTerminosCondiciones) {
		this.labelTerminosCondiciones = labelTerminosCondiciones;
	}

	public String getTituloModalTyC() {
		return tituloModalTyC;
	}

	public void setTituloModalTyC(String tituloModalTyC) {
		this.tituloModalTyC = tituloModalTyC;
	}

	public String getMensajeModalTyC() {
		return mensajeModalTyC;
	}

	public void setMensajeModalTyC(String mensajeModalTyC) {
		this.mensajeModalTyC = mensajeModalTyC;
	}

	public String getPdfTyC() {
		return pdfTyC;
	}

	public void setPdfTyC(String pdfTyC) {
		this.pdfTyC = pdfTyC;
	}
	
	public String getIntentosMaxCaptcha() {
		return intentosMaxCaptcha;
	}

	public void setIntentosMaxCaptcha(String intentosMaxCaptcha) {
		this.intentosMaxCaptcha = intentosMaxCaptcha;
	}

	public String getErrorCaptcha() {
		return errorCaptcha;
	}

	public void setErrorCaptcha(String errorCaptcha) {
		this.errorCaptcha = errorCaptcha;
	}

	/***
	 * HU143
	 * Función encargada de consultar en WCM los datos para check de términos y condiciones
	 * @since 12/08/2016
	 * @author: melany.rozo
	 */
	public DatosPagoFactWcmBean cargarDatos(RenderRequest request, CustomLogger logger, String user, String rquid){
		WCMCliente cliente = null;
		RutaContenidoBean rContenido = (RutaContenidoBean) request.getPortletSession().getAttribute("RutaContenidoBean", PortletSession.APPLICATION_SCOPE);
		ResourceBundle rbPortlet = ResourceBundle.getBundle("com.portalpagos.realizarpagofact.portlet.nl.RealizarPagoFactV2PortletResource");
		
		try{
			
			cliente = new WCMCliente(rContenido.getPathTerminosCondiciones());
			this.labelTerminosCondiciones = rbPortlet.getString("stLabelTerminosCondiciones");
			this.mensajeModalTyC = rbPortlet.getString("stMensajeError");
			this.tituloModalTyC = rbPortlet.getString("stTituloModalError");
			this.pdfTyC = ((FileComponent) cliente.getComponent("raTerminosCondiciones")).getResourceURL();
			if(null!=this.pdfTyC){
				this.pdfTyC=this.pdfTyC.replace("myconnect", "connect");
			}
			//Se calcula el alto y ancho para el contenido del Modal Condiciones de Aceptación
			String categoriaArray[] = Modal.calcularDimensionModal(this.mensajeModalTyC);
			this.widhtModalCondiciones = categoriaArray[0]; 
			this.heightModalCondiciones = categoriaArray[1];

			//Consulta de contenido realizar pago
			this.errorCaptcha = rbPortlet.getString("stErrorCaptcha");
			this.intentosMaxCaptcha = rbPortlet.getString("stMaximoIntentosCaptcha");

		} catch (WCMException e) {
			ErrorData errorData= PublisherUtil.getInstance().getErrorData(e, rquid, ExceptionManager.PP_PORTAL_WCM_01, user, ExceptionManager.MSG_PORTAL_WCM_01+" - Operación: cargarDatos Wcm, Realizar pago facturadores", "cargarDatosWcm", rContenido.getPortletOrigen(), rContenido.getPaginaOrigen(), rContenido.getPortalOrigen()); 
			logger.error(errorData, e);
		} catch (Exception e) {
			ErrorData errorData= PublisherUtil.getInstance().getErrorData(e, rquid, ExceptionManager.PP_PORTAL_GENERIC_01, user, ExceptionManager.MSG_PORTAL_GENERIC_01+" Operación: cargarDatos Wcm, Realizar pago facturadores", "cargarDatosWcm", rContenido.getPortletOrigen(), rContenido.getPaginaOrigen(), rContenido.getPortalOrigen()); 
			logger.error(errorData, e);
		} finally {
			if(null!=cliente){
				cliente.endWorkspace();
			}
		}
		return this;
	}
}