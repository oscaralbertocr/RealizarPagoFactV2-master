package com.portalpagos.realizarpagofact.util;

import java.util.ResourceBundle;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.faces.validator.ValidatorException;

/**
 * HU163
 * Clase que realiza la validaci�n de las referencias, que sean numericas, o si no es obligatoria que acepte vacios
 **/

public class numericValidator{
		
	public String validateNumeric(String numero, String isObligatorio)
			throws ValidatorException {
			ResourceBundle rbNl = ResourceBundle.getBundle("com.portalpagos.realizarpagofact.portlet.nl.RealizarPagoFactV2PortletResource");
			ResourceBundle rb = ResourceBundle.getBundle("com.portalpagos.realizarpagofact.properties.RealizarPagoFactPortletResource");
			String mensaje = rbNl.getString("msg.soloNumeros");
			String pattern = rb.getString("pattern.numeros");			
			if ("true".equalsIgnoreCase(isObligatorio)) {
				if (!validateRegex(pattern,numero)) {
					return mensaje;
				}
			}
			return "true";
	}
	
	public static boolean validateRegex(String pattern, String line){		
		Pattern p = Pattern.compile(pattern);
		Matcher m = p.matcher(line);
		return  m.matches();
	}

	public String validateAlfanumeric(String numero, String isObligatorio)
			throws ValidatorException {
			ResourceBundle rbNl = ResourceBundle.getBundle("com.portalpagos.realizarpagofact.portlet.nl.RealizarPagoFactV2PortletResource");
			ResourceBundle rb = ResourceBundle.getBundle("com.portalpagos.realizarpagofact.properties.RealizarPagoFactPortletResource");
			String mensaje = rbNl.getString("msg.soloNumeros");
			String pattern = rb.getString("pattern.numeros");			
			if ("true".equalsIgnoreCase(isObligatorio)) {
				if (!validateRegex(pattern,numero)) {
					return mensaje;
				}
			}
			return "true";
	}
	
	public String validateTexto(String numero, String isObligatorio)
			throws ValidatorException {
			ResourceBundle rbNl = ResourceBundle.getBundle("com.portalpagos.realizarpagofact.portlet.nl.RealizarPagoFactV2PortletResource");
			ResourceBundle rb = ResourceBundle.getBundle("com.portalpagos.realizarpagofact.properties.RealizarPagoFactPortletResource");
			String mensaje = rbNl.getString("msg.soloNumeros");
			String pattern = rb.getString("pattern.numeros");			
			if ("true".equalsIgnoreCase(isObligatorio)) {
				if (!validateRegex(pattern,numero)) {
					return mensaje;
				}
			}
			return "true";
	}
}
