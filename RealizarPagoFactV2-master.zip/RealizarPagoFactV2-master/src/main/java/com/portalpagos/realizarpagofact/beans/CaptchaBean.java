package com.portalpagos.realizarpagofact.beans;

import java.io.Serializable;


/** HU21, HU44
 * ManagedBean utilizado para almacenar los datos del pago necesarios para los forms de Captura de Referencia de Pago 
 * y Confirmación de Pago
 * @author: Mélany Rozo
 * @Since: 04/11/14
 **/

public class CaptchaBean implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private String activeCaptcha;
	
	private String pathNoImageCaptcha;
	
	private String pathImageCaptcha;
	
	private String labelMensajeCampoCaptcha;

	private String labelMensajeImagenCaptcha;
	
	private String imageCaptcha;
	
	private String errorCaptcha;
	
	public CaptchaBean(){
		
	}


	public String getErrorCaptcha() {
		return errorCaptcha;
	}



	public void setErrorCaptcha(String errorCaptcha) {
		this.errorCaptcha = errorCaptcha;
	}



	public String getActiveCaptcha() {
		return activeCaptcha;
	}


	public void setActiveCaptcha(String activeCaptcha) {
		this.activeCaptcha = activeCaptcha;
	}


	public String getPathNoImageCaptcha() {
		return pathNoImageCaptcha;
	}


	public void setPathNoImageCaptcha(String pathNoImageCaptcha) {
		this.pathNoImageCaptcha = pathNoImageCaptcha;
	}


	public String getPathImageCaptcha() {
		return pathImageCaptcha;
	}


	public void setPathImageCaptcha(String pathImageCaptcha) {
		this.pathImageCaptcha = pathImageCaptcha;
	}


	public String getLabelMensajeCampoCaptcha() {
		return labelMensajeCampoCaptcha;
	}


	public void setLabelMensajeCampoCaptcha(String labelMensajeCampoCaptcha) {
		this.labelMensajeCampoCaptcha = labelMensajeCampoCaptcha;
	}


	public String getLabelMensajeImagenCaptcha() {
		return labelMensajeImagenCaptcha;
	}


	public void setLabelMensajeImagenCaptcha(String labelMensajeImagenCaptcha) {
		this.labelMensajeImagenCaptcha = labelMensajeImagenCaptcha;
	}


	public String getImageCaptcha() {
		return imageCaptcha;
	}


	public void setImageCaptcha(String imageCaptcha) {
		this.imageCaptcha = imageCaptcha;
	}
	
}