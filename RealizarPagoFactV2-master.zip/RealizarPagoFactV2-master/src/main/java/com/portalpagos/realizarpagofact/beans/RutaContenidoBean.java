package com.portalpagos.realizarpagofact.beans;

import java.io.Serializable;

public class RutaContenidoBean implements Serializable {

    private static final long serialVersionUID = 1L;
    private String urlHome;
    private String urlImagenes;
    private String pathReferenceFacturadores;
    private String urlRetornoPasarela;
    private String tituloError;
    private String bankName;
    private String portalOrigen;
    private String portletOrigen;
    private String paginaOrigen;
    private String pathTerminosCondiciones;
    private String bankId;
    private String accionIniciarPago;
    private String ip;
    private String tipoDoc;
    private String documento;
    private String pathImagenConv;
    private String nombreBaseImgConvenio;
    private String dn;
    private String userName;
    // variable para saber que se va hacer un pago de taquillas
    private String taquillas;
    private String pathErroresTecnicos;
    
    //RQ30801 Indicar Medios de Pago
    private String pathImagenMedioPago;

    public String getPathImagenMedioPago() {
		return pathImagenMedioPago;
	}

	public void setPathImagenMedioPago(String pathImagenMedioPago) {
		this.pathImagenMedioPago = pathImagenMedioPago;
	}

    public String getTaquillas() {
        return taquillas;
    }

    public void setTaquillas(String taquillas) {
        this.taquillas = taquillas;
    }

    public String getPathImagenConv() {
        return pathImagenConv;
    }

    public void setPathImagenConv(String pathImagenConv) {
        this.pathImagenConv = pathImagenConv;
    }

    public String getNombreBaseImgConvenio() {
        return nombreBaseImgConvenio;
    }

    public void setNombreBaseImgConvenio(String nombreBaseImgConvenio) {
        this.nombreBaseImgConvenio = nombreBaseImgConvenio;
    }

    public String getTipoDoc() {
        return tipoDoc;
    }

    public void setTipoDoc(String tipoDoc) {
        this.tipoDoc = tipoDoc;
    }

    public String getDocumento() {
        return documento;
    }

    public void setDocumento(String documento) {
        this.documento = documento;
    }

    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    public String getAccionIniciarPago() {
        return accionIniciarPago;
    }

    public void setAccionIniciarPago(String accionIniciarPago) {
        this.accionIniciarPago = accionIniciarPago;
    }

    public String getPathTerminosCondiciones() {
        return pathTerminosCondiciones;
    }

    public void setPathTerminosCondiciones(String pathTerminosCondiciones) {
        this.pathTerminosCondiciones = pathTerminosCondiciones;
    }

    public String getPortalOrigen() {
        return portalOrigen;
    }

    public void setPortalOrigen(String portalOrigen) {
        this.portalOrigen = portalOrigen;
    }

    public String getPortletOrigen() {
        return portletOrigen;
    }

    public void setPortletOrigen(String portletOrigen) {
        this.portletOrigen = portletOrigen;
    }

    public String getPaginaOrigen() {
        return paginaOrigen;
    }

    public void setPaginaOrigen(String paginaOrigen) {
        this.paginaOrigen = paginaOrigen;
    }

    public String getBankName() {
        return bankName;
    }

    public void setBankName(String bankName) {
        this.bankName = bankName;
    }

    public String getUrlHome() {
        return urlHome;
    }

    public void setUrlHome(String urlHome) {
        this.urlHome = urlHome;
    }

    public String getUrlImagenes() {
        return urlImagenes;
    }

    public void setUrlImagenes(String urlImagenes) {
        this.urlImagenes = urlImagenes;
    }

    public String getPathReferenceFacturadores() {
        return pathReferenceFacturadores;
    }

    public void setPathReferenceFacturadores(String pathReferenceFacturadores) {
        this.pathReferenceFacturadores = pathReferenceFacturadores;
    }

    public String getUrlRetornoPasarela() {
        return urlRetornoPasarela;
    }

    public void setUrlRetornoPasarela(String urlRetornoPasarela) {
        this.urlRetornoPasarela = urlRetornoPasarela;
    }

    public String getTituloError() {
        return tituloError;
    }

    public void setTituloError(String tituloError) {
        this.tituloError = tituloError;
    }

    public String getBankId() {
        return bankId;
    }

    public void setBankId(String bankId) {
        this.bankId = bankId;
    }

    public String getDn() {
        return dn;
    }

    public void setDn(String dn) {
        this.dn = dn;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPathErroresTecnicos() {
        return pathErroresTecnicos;
    }

    public void setPathErroresTecnicos(String pathErroresTecnicos) {
        this.pathErroresTecnicos = pathErroresTecnicos;
    }
}
