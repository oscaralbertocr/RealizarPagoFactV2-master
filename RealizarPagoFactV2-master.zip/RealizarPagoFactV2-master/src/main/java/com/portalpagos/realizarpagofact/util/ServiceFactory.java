/**
 * 
 */
package com.portalpagos.realizarpagofact.util;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import co.com.ath.payments.mc.service.bean.view.ServiceBeanLocal;



/**
 * clase para obtener referencia de la interfaz de del Middleware de comunicaciones
 * @author ricardo.paredes
 *
 */
public class ServiceFactory {
	
	private static final String EJB_CONTEXT = "java:comp/env/ejb/ServiceBeanLocal";
	private static ServiceFactory instance;
	private ServiceBeanLocal serviceBean;
	
	private ServiceFactory() throws NamingException {
		    Context context = new InitialContext();
		    serviceBean = (ServiceBeanLocal) context.lookup(EJB_CONTEXT);

	}
	
	/**
	 * Retorna instancia de ServiceFactory
	 * @return
	 * @throws NamingException
	 */
	public static ServiceFactory getInstance() throws NamingException {
		if(null == instance)
			instance = new ServiceFactory();
		return instance;
	}
	
	/**
	 * 
	 * @return ServiceBeanLocal (Middlewarecommunication Interface)
	 */
	public ServiceBeanLocal getServiceBean() {
		return serviceBean;
	}
}
