package com.portalpagos.realizarpagofact.util;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import java.util.ResourceBundle;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.PortletSession;

import com.ath.portalpagos.util.ExceptionManager;
import com.ath.portalpagos.util.IpNodoPortal;
import com.ath.portalpagos.util.JSONUtil;
import com.google.gson.Gson;
import com.portalpagos.realizarpagofact.beans.DatosPagoFactBean;
import com.portalpagos.realizarpagofact.beans.RutaContenidoBean;
import com.portalpagos.realizarpagofact.portlet.RealizarPagoFactV2Portlet;

import co.com.ath.logger.CustomLogger;
import co.com.ath.mc.utilities.util.ValidarTopes;
import co.com.ath.payments.mc.auditor.publisher.traza.TrazaPublisher;
import co.com.ath.payments.mc.auditor.publisher.util.PublisherUtil;
import co.com.ath.payments.mc.service.model.AuditorRq;
import co.com.ath.payments.mc.service.model.ErrorData;
import co.com.ath.payments.mc.service.model.json.ReferenceType;

public class PagoAgilListener implements Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    private static CustomLogger logger = new CustomLogger(RealizarPagoFactV2Portlet.class);
    private String user;
    //private static String rquid;
    private String ip;
    private static final String COMA = "°";
    private static final String FACTURADOR = "Facturadores";
    private static final String DOSPUNTOS = ":";
    private static final String COD_CONVENIO = "Código Convenio";
    private static final String NODO = "Nodo Portal";
    private static final String PRIMERA_REFERENCIA = "Primera referencia adicional";
    private static final String SEGUNDA_REFERENCIA = "Segunda referencia adicional";
    private static final String TERCERA_REFERENCIA = "Tercera referencia adicional";
    private static final String RQ = "RQ";

    public static void processAction(ActionRequest request, ActionResponse responseAction, String rdTipoConsulta,
            List<ReferenceType> listaReferencia) {
    	new PagoAgilListener().processOneAction(request, responseAction, rdTipoConsulta, listaReferencia);
    	
    }
    private void processOneAction(ActionRequest request, ActionResponse responseAction, String rdTipoConsulta,
            List<ReferenceType> listaReferencia) {
    	logger.info("Action pago agil");
        // Se genera nuevo RQUID para acciÃ³n Pagar
        String rquid = PublisherUtil.getInstance().generateRequestID();
        request.getPortletSession().setAttribute("rquid", rquid, PortletSession.APPLICATION_SCOPE);

        user = (String) request.getPortletSession().getAttribute("user", PortletSession.APPLICATION_SCOPE);
        ip = (String) request.getPortletSession().getAttribute("ip", PortletSession.APPLICATION_SCOPE);

        RutaContenidoBean rContenido = (RutaContenidoBean) request.getPortletSession().getAttribute("RutaContenidoBean",
                PortletSession.APPLICATION_SCOPE);

        // Metodo para Trazar el RQ
        ResourceBundle rbPortlet = ResourceBundle
                .getBundle("com.portalpagos.realizarpagofact.portlet.nl.RealizarPagoFactV2PortletResource");
        String accion = rbPortlet.getString("auditoria.pagoAgil");

        // Obtiene de la sesion el bean de datos de pago
        DatosPagoFactBean param = (DatosPagoFactBean) request.getPortletSession().getAttribute("datosPagoFactBean",
                PortletSession.APPLICATION_SCOPE);
        String idConvenio = param.getIdConvenio();
        String paramPago = "";

        try {
            boolean permiteParcial = param.isPermiteParcial();
            String valor = "", msjTope = "";
            if (!permiteParcial || (permiteParcial && rdTipoConsulta.equals("1"))) {
                valor = param.getValorPago();
            } else if (rdTipoConsulta.equals("2")) {
                valor = request.getParameter("valorPagoParcial");
            }

            valor = valor.replace(".", "");
            boolean validTopes = ValidarTopes.validarTopesMedioPago(param.getMediosPago(), param.getTopesPorValor());
            if(validTopes){
                msjTope = param.validarTopes(valor, rContenido, rbPortlet);
            }
            if (msjTope.isEmpty()) {
                Gson gson = new Gson();

                String tipoModalidad = FACTURADOR;
                paramPago += rquid + COMA;
                paramPago += idConvenio.toUpperCase() + COMA;
                paramPago += valor + COMA;
                paramPago += (param.getIntencionPago() == null ? "null" : param.getIntencionPago()) + COMA;
                paramPago += (param.getNumeroDocumento() == null ? "null" : param.getNumeroDocumento()) + COMA;
                paramPago += (param.getTipoDocumento() == null ? "null" : param.getTipoDocumento()) + COMA;
                paramPago += (param.getTrm() == null ? "null" : param.getTrm()) + COMA;
                paramPago += rContenido.getUrlRetornoPasarela() + COMA;
                paramPago += param.getComentarios() + COMA;
                paramPago += param.getNombreConvenio() + COMA;
                // INI HU 21.5.4 GD 12/12/2016 SP 1_2017
                // Agregar costo de transaccion Pago Agil
                paramPago += param.getValorCostoTransaccion() + COMA;
                // FIN HU 21.5.4 GD 12/12/2016
                /* HU 220 Enviar etiquetas en el addTransaction */
                paramPago += (param.getUrlImgConvAddTran() == null ? "null" : param.getUrlImgConvAddTran()) + COMA;
                /* Fin HU 220 */
                // HU 231 - Validacion topes
                paramPago += gson.toJson(param.getTopesPorValor()) + COMA;
                // HU 231 - Lista de referencias HU 21.7
                paramPago += gson.toJson(listaReferencia) + COMA;
                paramPago += tipoModalidad;

                logger.info("Datos a evento paramPago:" + paramPago);
                // Genera el response para enviar el evento al Login
                responseAction.setEvent("requestEventPagoAgilFact", paramPago);
            }
        } catch (Exception e1) {
            ErrorData errorData = PublisherUtil.getInstance().getErrorData(e1, rquid, ExceptionManager.PP_PORTAL_GENERIC_01, user,
                    ExceptionManager.MSG_PORTAL_GENERIC_01 + " OperaciÃ³n: processAction, Realizar pago facturadores", "processAction",
                    rContenido.getPortletOrigen(), rContenido.getPaginaOrigen(), rContenido.getPortalOrigen());
            logger.error(errorData, e1);
            String[] error = ErrorManager.getInstance(request).obtenerErrorWCM(rContenido.getPathErroresTecnicos(),
                    ExceptionManager.PP_PORTAL_GENERIC_01);
            param.mostrarModal(error[0], "icon-error", error[1]);
        } finally {
            trazaPagoAgilRq(rContenido, accion, rquid, rbPortlet.getString("auditoria.nombrePortlet"), ip, user, idConvenio, param, rquid);
        }

    }

    /**
     * HU 21.4 Funcion encargada de Trazar la Rq de trazaPagoAgilRq
     * 
     * @author andrea.florez
     * @since 28/06/2016
     */
    private static void trazaPagoAgilRq(RutaContenidoBean requestPay, String accion, String idRequest, String portlet, String ipAdress,
            String userName, String idConvenio, DatosPagoFactBean param, String rquid) {
        try {
            // Objeto Auditor Rq
            AuditorRq auditorRq = new AuditorRq();
            auditorRq.setAction(accion);
            auditorRq.setAdditionalInfo(
                    JSONUtil.getJson(COD_CONVENIO + DOSPUNTOS + idConvenio, NODO + DOSPUNTOS + IpNodoPortal.getIpNodo()));
            if (null != param.getIsRequierePrimeraReferencia() && param.getIsRequierePrimeraReferencia()) {
                auditorRq.setAdditionalInfo(JSONUtil.getJson(COD_CONVENIO + DOSPUNTOS + idConvenio,
                        PRIMERA_REFERENCIA + DOSPUNTOS + param.getReferenciaPrimeraAdicional(),
                        NODO + DOSPUNTOS + IpNodoPortal.getIpNodo()));
            }
            if (null != param.getIsRequiereSegundaReferencia() && param.getIsRequiereSegundaReferencia()) {
                auditorRq.setAdditionalInfo(JSONUtil.getJson(COD_CONVENIO + DOSPUNTOS + idConvenio,
                        PRIMERA_REFERENCIA + DOSPUNTOS + param.getReferenciaPrimeraAdicional(),
                        SEGUNDA_REFERENCIA + DOSPUNTOS + param.getReferenciaSegundaAdicional(),
                        NODO + DOSPUNTOS + IpNodoPortal.getIpNodo()));
            }
            if (null != param.getIsRequiereTerceraReferencia() && param.getIsRequiereTerceraReferencia()) {
                auditorRq.setAdditionalInfo(JSONUtil.getJson(COD_CONVENIO + DOSPUNTOS + idConvenio,
                        PRIMERA_REFERENCIA + DOSPUNTOS + param.getReferenciaPrimeraAdicional(),
                        SEGUNDA_REFERENCIA + DOSPUNTOS + param.getReferenciaSegundaAdicional(),
                        TERCERA_REFERENCIA + DOSPUNTOS + param.getReferenciaTerceraAdicional(),
                        NODO + DOSPUNTOS + IpNodoPortal.getIpNodo()));
            }
            auditorRq.setExecutionDate(CommonUtils.getInstance().asXMLGregorianCalendar(new Date()));
            auditorRq.setIpAddress(ipAdress);
            auditorRq.setOriginPortal(requestPay.getBankName());
            auditorRq.setPage(requestPay.getPaginaOrigen());
            auditorRq.setPortlet(portlet);
            auditorRq.setRequestId(idRequest);
            auditorRq.setTipoServicio(RQ);
            auditorRq.setUser(userName);
            auditorRq.setReference(param.getReferenciaPago());

            // Llamado al m�todo para trazar rq
            TrazaPublisher.getInstance().publish(auditorRq);
        } catch (Exception e1) {
            ErrorData errorData = PublisherUtil.getInstance().getErrorData(e1, rquid, ExceptionManager.PP_PORTAL_GENERIC_01, userName,
                    ExceptionManager.MSG_PORTAL_GENERIC_01 + " Operación: trazaPagoAgilRq, Realizar pago facturadores", "trazaPagoAgilRq",
                    requestPay.getPortletOrigen(), requestPay.getPaginaOrigen(), requestPay.getPortalOrigen());
            logger.error(errorData, e1);
        }
    }

}
