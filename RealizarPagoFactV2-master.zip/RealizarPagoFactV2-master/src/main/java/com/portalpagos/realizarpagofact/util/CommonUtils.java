/**
 * 
 */
package com.portalpagos.realizarpagofact.util;

import java.util.GregorianCalendar;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

/**
 * @author ricardo.paredes
 * 
 */
public class CommonUtils {

	private static CommonUtils instance;
	private static DatatypeFactory df = null;

	private CommonUtils() {
		try {
			df = DatatypeFactory.newInstance();
		} catch (DatatypeConfigurationException e) {
			e.printStackTrace();
		}
	}

	public static CommonUtils getInstance() {
		if (null == instance)
			instance = new CommonUtils();
		return instance;
	}

	/**
	 * 
	 * @param xmlGC
	 * @return
	 */
	public java.util.Date asDate(XMLGregorianCalendar xmlGC) {
		if (xmlGC == null) {
			return null;
		} else {
			return xmlGC.toGregorianCalendar().getTime();
		}
	}

	public XMLGregorianCalendar asXMLGregorianCalendar(
			java.util.Date date) {
		if (date == null) {
			return null;
		} else {
			GregorianCalendar gc = new GregorianCalendar();
			gc.setTimeInMillis(date.getTime());
			return df.newXMLGregorianCalendar(gc);
		}
	}
	
	/**
	 * Metodo que valida si un string es alfanumérico
	 * @author jonnatan.rios
	 * @param cadena
	 * @return boolean
	 * 			true si es alfanumérico
	 */
	public boolean isAlphanumeric(String cadena) {
		char[] chars = cadena.toCharArray();
		int lengthArr = chars.length;
		boolean isAlphanumeric = false;
		
		for (int i = 0; i < lengthArr; i++) {
			if(Character.isLetter(chars[i])){
				isAlphanumeric = true;
				break;
			}
		}
		return isAlphanumeric;
	}

}
