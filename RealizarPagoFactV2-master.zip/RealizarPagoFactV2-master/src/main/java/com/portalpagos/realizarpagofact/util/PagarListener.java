package com.portalpagos.realizarpagofact.util;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.ResourceBundle;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.PortletSession;

import co.com.ath.clientes.payments.mc.service.util.ConfigurationService;
import co.com.ath.logger.CustomLogger;
import co.com.ath.mc.utilities.util.ValidarTopes;
import co.com.ath.payments.mc.auditor.publisher.traza.TrazaPublisher;
import co.com.ath.payments.mc.auditor.publisher.util.PublisherUtil;
import co.com.ath.payments.mc.auditor.publisher.util.WebServiceClientHTTPS;
import co.com.ath.payments.mc.service.model.AuditorRq;
import co.com.ath.payments.mc.service.model.ErrorData;
import co.com.ath.payments.mc.service.model.json.BankInfoType;
import co.com.ath.payments.mc.service.model.json.ExecutePaymentRq;
import co.com.ath.payments.mc.service.model.json.ExecutePaymentRs;
import co.com.ath.payments.mc.service.model.json.MedioPagoType;
import co.com.ath.payments.mc.service.model.json.TopeMedioPagoType;
import co.com.ath.payments.mc.service.util.CommonUtils;

import com.ath.portalpagos.util.ExceptionManager;
import com.ath.portalpagos.util.IpNodoPortal;
import com.ath.portalpagos.util.JSONUtil;
import com.google.gson.Gson;
import com.portalpagos.realizarpagofact.beans.DatosPagoFactBean;
import com.portalpagos.realizarpagofact.beans.RutaContenidoBean;
import com.portalpagos.realizarpagofact.portlet.RealizarPagoFactV2Portlet;

/**
 * HU20.1 ActionListener que procesa la petici�n del usuario al confirmar el
 * pago presionando el bot�n pagar del form de Confirmaci�n de Pago de flujo
 * de Facturadores
 * 
 * @author: M�lany Rozo
 * @Since: 22/12/14
 **/

public class PagarListener implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static final String RQ = "RQ";
	private static final String RS = "RS";
	private static CustomLogger logger = new CustomLogger(RealizarPagoFactV2Portlet.class);
	private String user;
	private String ip;
	private static final String DOSPUNTOS = ":";

	private static final String NODO_INTREGRA = "Nodo WebLogic";

	private static final String COD_CONVENIO = "Código Convenio";

	private static final String NODO = "Nodo Portal";

	private static final String PRIMERA_REFERENCIA = "Primera referencia adicional";

	private static final String SEGUNDA_REFERENCIA = "Segunda referencia adicional";

	private static final String TERCERA_REFERENCIA = "Tercera referencia adicional";

	/**
	 * Función que recupera de sesión el ManagedBean con los datos del pago,
	 * consulta en las preferencias del portlet la url a la que PP debe retornar
	 * cuando finalice el pago. Se envían los datos al Middleware de comunicaciones
	 * y se obtiene la url con el token para redireccionar a Pasarela de Pagos.
	 * Finally - Cuando finaliza el flujo del portlet se destruye el ManagedBean que
	 * se encuentra en sesión
	 * 
	 * @author: melany.rozo
	 * @return
	 * @since 22/12/2014
	 **/
	public static String processAction(ActionRequest request, ActionResponse responseAction, String rdTipoConsulta) {
		return new PagarListener().processOneAction(request, responseAction, rdTipoConsulta);

	}

	private String processOneAction(ActionRequest request, ActionResponse responseAction, String rdTipoConsulta) {

		logger.info("processAction, request: " + request);
		// Se genera nuevo RQUID para acción Pagar
		PortletSession session = request.getPortletSession();

		String rquid = PublisherUtil.getInstance().generateRequestID();
		session.setAttribute("rquid", rquid, PortletSession.APPLICATION_SCOPE);

		ip = (String) session.getAttribute("ip", PortletSession.APPLICATION_SCOPE);

		String page = "/jsp/formConfirmacionPago.jsp";

		RutaContenidoBean rContenido = (RutaContenidoBean) session.getAttribute("RutaContenidoBean",
				PortletSession.APPLICATION_SCOPE);

		user = (String) session.getAttribute("user", PortletSession.APPLICATION_SCOPE);

		// Método para Trazar el RQ
		ResourceBundle rbPortlet = ResourceBundle
				.getBundle("com.portalpagos.realizarpagofact.portlet.nl.RealizarPagoFactV2PortletResource");
		String accion = rbPortlet.getString("auditoria.pagar");

		// Obtiene de la sesion el bean de datos de pago
		DatosPagoFactBean param = (DatosPagoFactBean) session.getAttribute("datosPagoFactBean",
				PortletSession.APPLICATION_SCOPE);
		// Alertas INI
		String idConvenio = param.getIdConvenio() == null ? "" : param.getIdConvenio();
		logger.info("idConvenio: " + idConvenio);
		// Alertas Fin

		// Invocaci�n al m�todo que ejecuta la traza
		auditorRqExecutePayment(rContenido, accion, rquid, rbPortlet.getString("auditoria.nombrePortlet"), ip, user,
				idConvenio, param, rquid);

		ExecutePaymentRq requestExe = null;
		ExecutePaymentRs response = null;
		String errorCode = "";
		logger.info("processAction, rdTipoConsulta: " + rdTipoConsulta);
		try 
		{
			requestExe = new ExecutePaymentRq();
			response = new ExecutePaymentRs();
			String msjTope = "", valor = "";
			boolean permiteParcial = param.isPermiteParcial();
			if (!permiteParcial || (permiteParcial && rdTipoConsulta.equals("1"))) 
			{
				valor = param.getValorPago();
				logger.info("No permite pago parcial, valor factura: " + valor);
			}
			else if (rdTipoConsulta.equals("2")) 
			{
				valor = request.getParameter("valorPagoParcial");
				logger.info("Valor factura: " + param.getValorPago());
				logger.info("permite pago parcial: " + valor);
				logger.info("Porcentaje Tope Valor: " + param.getPorcentajeTope());
				if(param.isValidTope())
				{
					if(request.getParameter("valorPagoParcial") != null)
					{
						if(!validacionTopeFactura(param, param.getValorPago(), request.getParameter("valorPagoParcial"), param.getPorcentajeTope()))
						{
							return page;
						}
					}
				}
				
			}
			logger.info("Valor es: " + valor);
			valor = valor.replace(".", "");
			boolean validTopes = ValidarTopes.validarTopesMedioPago(param.getMediosPago(), param.getTopesPorValor());
			logger.info("validTopes [processAction - pagar]: " + validTopes);
			if (validTopes) 
			{
				msjTope = param.validarTopes(valor, rContenido, rbPortlet);
			}
			logger.info("Mensaje topes [processAction - pagar]: " + msjTope);
			if (msjTope.isEmpty()) 
			{
				BankInfoType objBanco = new BankInfoType();
				objBanco.setBankName(rContenido.getBankName());
				objBanco.setBankId(rContenido.getBankId());

				String urlRetorno = rContenido.getUrlRetornoPasarela();
				// Crea el objeto de consulta para enviar al MWC
				requestExe.setAgreementId(idConvenio.toUpperCase());

				// Envio de Referencias Multiples HU 21.7
				requestExe.setReferences(param.getValoresReferenciaAdicionalList());

				requestExe.setIntencionPago(param.getIntencionPago());
				requestExe.setNumeroDocumentoDuenoObligacion(
						param.getNumeroDocumento() == null ? "" : param.getNumeroDocumento());
				requestExe.setTipoDocumentoDuenoObligacion(
						param.getTipoDocumento() == null ? "" : param.getTipoDocumento());
				requestExe.setTRM(param.getTrm() == null ? "" : param.getTrm());
				requestExe.setReturnUrl(urlRetorno);
				requestExe.setComments(param.getComentarios());
				requestExe.setAgreementName(param.getNombreConvenio());
				requestExe.setBankID(rContenido.getBankId());
				requestExe.setBancoPortal(rContenido.getBankName());
				requestExe.setRequestDate(new Date());
				requestExe.setRequestOriginPortal(rContenido.getPortalOrigen());
				requestExe.setRequestPage(rContenido.getPaginaOrigen());
				requestExe.setRequestSender(rContenido.getPortletOrigen());
				requestExe.setBankInfo(objBanco);
				requestExe.setIpAddress(ip);
				requestExe.setRequestID(rquid);
				requestExe.setPaymentAmmount(Long.parseLong(valor));

				// RQ 29184 Factura personalizada
				if (param.getCamposFacturaPersonzalizada() != null
						&& !param.getCamposFacturaPersonzalizada().isEmpty()) {
					requestExe.setCustomInvoice(param.getCamposFacturaPersonzalizada());
				}

				/* HU 220 Envio de etiquetas en el addTransaction */
				requestExe.setTemplate("0");
				requestExe.setLogoUrl(param.getUrlImgConvAddTran() == null ? "" : param.getUrlImgConvAddTran());
				requestExe.setTheme("");
				requestExe.setCostoTransaccion(param.getValorCostoTransaccion());

				/* HU 231 Topes por convenio */
				requestExe.setTopesMedioPago(param.getTopesPorValor());

				if (null != rContenido.getTaquillas() && !"".equals(rContenido.getTaquillas())) {
					requestExe.setTaquilla(true);

					/*
					 * HU 220 Envio de etiquetas en el addTransaction
					 */
					requestExe.setTemplate("1");
					requestExe.setLogoUrl(param.getUrlImgConvAddTran() == null ? "" : param.getUrlImgConvAddTran());
					requestExe.setTheme(param.getTemaConv());
				} else {
					requestExe.setRequestUser(user);
					requestExe.setUserName(user);
				}

				logger.info("[REQUEST - ExecutePayment] DATA: " + new Gson().toJson(requestExe));

				// Invoca el m�todo del MWC
				String EndPointRESTServiceExecutePayment = ConfigurationService.getInstance().getEndpointRest();

				response = (ExecutePaymentRs) WebServiceClientHTTPS.getInstance(ExecutePaymentRs.class)
						.procesarRequest(EndPointRESTServiceExecutePayment + "addTransaction", requestExe);
				logger.info("EndPoint: " + EndPointRESTServiceExecutePayment + "addTransaction");
				logger.info("Peticion: " + new Gson().toJson(requestExe));
				logger.info("[RESPONSE - ExecutePayment] DATA: " + new Gson().toJson(response));

				if (!("SUCCESS".equals(response.getStatus().getStatusCode()))) {
					if (null != response.getExcepcion() && null != response.getExcepcion().getCodigo()) {
						errorCode = response.getExcepcion().getCodigo();
					}

					String[] error = new String[2];
					String tipo = "";
					if ("ERROR_27".equals(response.getStatus().getStatusCode())) {
						String errorMensajePendiente = rbPortlet.getString("txtError27");
						String statusDesError = response.getStatus().getStatusDesc();
						String pmtId[] = statusDesError.split(" ");
						String pmtIdError = pmtId[pmtId.length - 1];
						errorMensajePendiente = errorMensajePendiente.replace("#", "simboloNumeral");
						if (param.getReferenciaPago() != null && param.getReferenciaPago() != "") {
							errorMensajePendiente = errorMensajePendiente.replace("numRef", param.getReferenciaPago());
						}

						if (pmtIdError != null && !pmtIdError.isEmpty()) {
							logger.info("La transaccion se encuentra pendiente el PMTID es: " + pmtIdError);
							errorMensajePendiente = errorMensajePendiente.replace("pmtId", pmtIdError);
						}
						
						error[0] = errorMensajePendiente;
						error[1] = "ERROR";
						tipo = "icon-alert";
					} else if ("ERROR_TOPE_TX".equals(response.getStatus().getStatusCode())) {
						// HU231 Validacion de topes
						error[0] = rbPortlet.getString("stMensajeErrorTopesTx");
						error[1] = rbPortlet.getString("stMensajeInformacion");
						tipo = "icon-alert";
					} else if ("ERROR_200".equals(response.getStatus().getStatusCode())) {
						String mensajeGeneral = rbPortlet.getString("stMsgErrorConsultaFactura");
						String serverStatusCode = null != response.getStatus().getServerStatusCode()
								&& !response.getStatus().getServerStatusCode().isEmpty()
										? "(" + response.getStatus().getServerStatusCode() + ")"
										: "";
						error[0] = null != response.getStatus().getServerStatusDescp()
								&& !response.getStatus().getServerStatusDescp().isEmpty()
										? response.getStatus().getServerStatusDescp() + " " + serverStatusCode
										: mensajeGeneral + " " + serverStatusCode;
						error[1] = rbPortlet.getString("stTituloMensajeError");
						tipo = "icon-alert";
					} else if ("ERROR_100".equals(response.getStatus().getStatusCode())) {
						String mensajeGeneral = rbPortlet.getString("stMensajeError100");
						String serverStatusCode = null != response.getStatus().getServerStatusCode()
								&& !response.getStatus().getServerStatusCode().isEmpty()
										? "(" + response.getStatus().getServerStatusCode() + ")"
										: "";
						error[0] = mensajeGeneral + " " + serverStatusCode;
						error[1] = rbPortlet.getString("stTituloMensajeError");
						tipo = "icon-alert";
					} else if ("ERROR_300".equals(response.getStatus().getStatusCode())) {
						String mensajeGeneral = rbPortlet.getString("stMensajeError300");
						String serverStatusCode = null != response.getStatus().getServerStatusCode()
								&& !response.getStatus().getServerStatusCode().isEmpty()
										? "(" + response.getStatus().getServerStatusCode() + ")"
										: "";
						error[0] = mensajeGeneral + " " + serverStatusCode;
						error[1] = rbPortlet.getString("stTituloMensajeError");
						tipo = "icon-alert";
					} else if ("ERROR_600".equals(response.getStatus().getStatusCode())) {
						String mensajeGeneral = rbPortlet.getString("stMensajeError600");
						String serverStatusCode = null != response.getStatus().getServerStatusCode()
								&& !response.getStatus().getServerStatusCode().isEmpty()
										? "(" + response.getStatus().getServerStatusCode() + ")"
										: "";
						error[0] = mensajeGeneral + " " + serverStatusCode;
						error[1] = rbPortlet.getString("stTituloMensajeError");
						tipo = "icon-alert";
					} else if ("ERROR_700".equals(response.getStatus().getStatusCode())) {
						String mensajeGeneral = rbPortlet.getString("stMensajeError700");
						String serverStatusCode = null != response.getStatus().getServerStatusCode()
								&& !response.getStatus().getServerStatusCode().isEmpty()
										? "(" + response.getStatus().getServerStatusCode() + ")"
										: "";
						error[0] = mensajeGeneral + " " + serverStatusCode;
						error[1] = rbPortlet.getString("stTituloMensajeError");
						tipo = "icon-alert";
					} else {
						error = ErrorManager.getInstance(request).obtenerErrorWCM(rContenido.getPathErroresTecnicos(),
								response.getExcepcion().getCodigo());
						tipo = "icon-error";
					}

					param.mostrarModal(error[0], tipo, error[1]);

					logger.info("executePayment ID: " + param.getIdConvenio() + ", REFERENCIA: "
							+ param.getReferenciaPago() + ". Response CODE: " + response.getStatus().getStatusCode()
							+ ", DESC: " + response.getStatus().getStatusDesc() + "; COD_SERV: "
							+ response.getCodigoServicio());
				} else {
					logger.info("Respuesta exitosa Execute payment");
					// Obtiene la url con el token y redirecciona a Pasarela
					String url = response.getPortalUrl();
					if (url != null) {
						page = "";
						// Elimina el bean de la sesión
						session.removeAttribute("datosPagoFactBean", PortletSession.PORTLET_SCOPE);
						session.removeAttribute("datosPagoWcmBean", PortletSession.PORTLET_SCOPE);
						session.removeAttribute("RutaContenidoBean", PortletSession.PORTLET_SCOPE);
						responseAction.sendRedirect(url);
					} else {
						logger.info("executePayment ID: " + param.getIdConvenio() + ", REFERENCIA: "
								+ param.getReferenciaPago() + ". URL Pasarela: " + url);
						String[] error = ErrorManager.getInstance(request).obtenerErrorWCM(
								rContenido.getPathErroresTecnicos(), ExceptionManager.PP_PORTAL_GENERIC_01);
						param.mostrarModal(error[0], "icon-error", error[1]);
					}
				}
			}
		} catch (Exception e1) {
			errorCode = ExceptionManager.PP_PORTAL_GENERIC_01;
			ErrorData errorData = PublisherUtil.getInstance().getErrorData(e1, rquid,
					ExceptionManager.PP_PORTAL_GENERIC_01, user,
					errorCode + " Operación: processAction, Realizar pago facturadores", "processAction",
					rContenido.getPortletOrigen(), rContenido.getPaginaOrigen(), rContenido.getPortalOrigen());
			logger.error(errorData, e1);
			String[] error = ErrorManager.getInstance(request).obtenerErrorWCM(rContenido.getPathErroresTecnicos(),
					errorCode);
			param.mostrarModal(error[0], "icon-error", error[1]);
		} finally {
			auditorRsExecutePayment(response, requestExe, accion, rquid, errorCode, param, rContenido, rquid, user);
		}
		logger.info("Página a renderizar [Process action - pagar]: " + page);
		return page;
	}

	/**
	 * HU 143 Funci�n encargada de Trazar la Rq de auditorRqPayCentralBillRq
	 * 
	 * @author germandiaz
	 * @param idRequest
	 * @since 13/08/2015
	 */
	private static void auditorRqExecutePayment(RutaContenidoBean requestPay, String accion, String idRequest,
			String portlet, String ipAdress, String userName, String idConvenio, DatosPagoFactBean param,
			String rquid) {
		try {
			// Objeto Auditor Rq
			AuditorRq auditorRq = new AuditorRq();
			auditorRq.setAction(accion);
			auditorRq.setAdditionalInfo(JSONUtil.getJson(COD_CONVENIO + DOSPUNTOS + idConvenio,
					NODO + DOSPUNTOS + IpNodoPortal.getIpNodo()));
			if (null != param.getIsRequierePrimeraReferencia() && param.getIsRequierePrimeraReferencia()) {
				auditorRq.setAdditionalInfo(JSONUtil.getJson(COD_CONVENIO + DOSPUNTOS + idConvenio,
						PRIMERA_REFERENCIA + DOSPUNTOS + param.getReferenciaPrimeraAdicional(),
						NODO + DOSPUNTOS + IpNodoPortal.getIpNodo()));
			}
			if (null != param.getIsRequiereSegundaReferencia() && param.getIsRequiereSegundaReferencia()) {
				auditorRq.setAdditionalInfo(JSONUtil.getJson(COD_CONVENIO + DOSPUNTOS + idConvenio,
						PRIMERA_REFERENCIA + DOSPUNTOS + param.getReferenciaPrimeraAdicional(),
						SEGUNDA_REFERENCIA + DOSPUNTOS + param.getReferenciaSegundaAdicional(),
						NODO + DOSPUNTOS + IpNodoPortal.getIpNodo()));
			}
			if (null != param.getIsRequiereTerceraReferencia() && param.getIsRequiereTerceraReferencia()) {
				auditorRq.setAdditionalInfo(JSONUtil.getJson(COD_CONVENIO + DOSPUNTOS + idConvenio,
						PRIMERA_REFERENCIA + DOSPUNTOS + param.getReferenciaPrimeraAdicional(),
						SEGUNDA_REFERENCIA + DOSPUNTOS + param.getReferenciaSegundaAdicional(),
						TERCERA_REFERENCIA + DOSPUNTOS + param.getReferenciaTerceraAdicional(),
						NODO + DOSPUNTOS + IpNodoPortal.getIpNodo()));
			}
			auditorRq.setExecutionDate(CommonUtils.getInstance().asXMLGregorianCalendar(new Date()));
			auditorRq.setIpAddress(ipAdress);
			auditorRq.setOriginPortal(requestPay.getBankName());
			auditorRq.setPage(requestPay.getPaginaOrigen());
			auditorRq.setPortlet(portlet);
			auditorRq.setRequestId(idRequest);
			auditorRq.setTipoServicio(RQ);
			auditorRq.setUser(userName);
			auditorRq.setReference(param.getReferenciaPago());

			// Llamado al m�todo para trazar rq
			TrazaPublisher.getInstance().publish(auditorRq);
		} catch (Exception e1) {
			ErrorData errorData = PublisherUtil.getInstance().getErrorData(e1, rquid,
					ExceptionManager.PP_PORTAL_GENERIC_01, userName,
					ExceptionManager.MSG_PORTAL_GENERIC_01
							+ " Operación: auditorRqExecutePayment, Realizar pago facturadores",
					"auditorRqExecutePayment", requestPay.getPortletOrigen(), requestPay.getPaginaOrigen(),
					requestPay.getPortalOrigen());
			logger.error(errorData, e1);
		}
	}

	/**
	 * HU 143 Función encargada de Trazar del RS de auditorRqPayCentralBillRs
	 * 
	 * @author germandiaz
	 * @param ExecutePaymentRs, ExecutePaymentRq, accion, idRequest
	 * @since 13/08/2015
	 */
	private static void auditorRsExecutePayment(ExecutePaymentRs response, ExecutePaymentRq requestExe, String accion,
			String idRequest, String errorCode, DatosPagoFactBean param, RutaContenidoBean rContenido, String rquid,
			String userName) {
		try {
			// Objeto Auditor Rq
			AuditorRq auditorRq = new AuditorRq();
			auditorRq.setAction(accion);
			logger.info("CargueArchivoPersonalizado - auditorRsExecutePayment");
			logger.info("CargueArchivoPersonalizado verificando nulos " + requestExe + " " + response);
			auditorRq.setAdditionalInfo(JSONUtil.getJson(COD_CONVENIO + DOSPUNTOS + requestExe.getAgreementId(),
					NODO + DOSPUNTOS + IpNodoPortal.getIpNodo(),
					NODO_INTREGRA + DOSPUNTOS + response.getIpIntegracion()));
			if (null != param.getIsRequierePrimeraReferencia() && param.getIsRequierePrimeraReferencia()) {
				auditorRq.setAdditionalInfo(JSONUtil.getJson(COD_CONVENIO + DOSPUNTOS + requestExe.getAgreementId(),
						PRIMERA_REFERENCIA + DOSPUNTOS + param.getReferenciaPrimeraAdicional(),
						NODO + DOSPUNTOS + IpNodoPortal.getIpNodo(),
						NODO_INTREGRA + DOSPUNTOS + response.getIpIntegracion()));
			}
			if (null != param.getIsRequiereSegundaReferencia() && param.getIsRequiereSegundaReferencia()) {
				auditorRq.setAdditionalInfo(JSONUtil.getJson(
						COD_CONVENIO + DOSPUNTOS + requestExe.getAgreementId() + DOSPUNTOS
								+ param.getReferenciaPrimeraAdicional(),
						SEGUNDA_REFERENCIA + DOSPUNTOS + param.getReferenciaSegundaAdicional(),
						NODO + DOSPUNTOS + IpNodoPortal.getIpNodo(),
						NODO_INTREGRA + DOSPUNTOS + response.getIpIntegracion()));
			}
			if (null != param.getIsRequiereTerceraReferencia() && param.getIsRequiereTerceraReferencia()) {
				auditorRq.setAdditionalInfo(JSONUtil.getJson(
						COD_CONVENIO + DOSPUNTOS + requestExe.getAgreementId() + DOSPUNTOS
								+ param.getReferenciaPrimeraAdicional(),
						SEGUNDA_REFERENCIA + DOSPUNTOS + param.getReferenciaSegundaAdicional(),
						TERCERA_REFERENCIA + DOSPUNTOS + param.getReferenciaTerceraAdicional(),
						NODO + DOSPUNTOS + IpNodoPortal.getIpNodo(),
						NODO_INTREGRA + DOSPUNTOS + response.getIpIntegracion()));
			}
			auditorRq.setCodigoServicioInt(response.getCodigoServicio());
			auditorRq.setErrorCode(errorCode);
			auditorRq.setExecutionDate(CommonUtils.getInstance().asXMLGregorianCalendar(new Date()));
			auditorRq.setIpAddress(requestExe.getIpAddress());
			auditorRq.setOriginPortal(requestExe.getBankInfo() == null?null:requestExe.getBankInfo().getBankName());
			auditorRq.setPage(requestExe.getRequestPage());
			auditorRq.setPortlet(requestExe.getRequestSender());

			// Validar##
			// auditorRq.setReference(requestExe.getPaymentReference());

			auditorRq.setRequestId(idRequest);
			auditorRq.setTipoServicio(RS);
			auditorRq.setUser(requestExe.getRequestUser());
			auditorRq.setPaymentId(response.getPmtId());

			// Llamado al m�todo para trazar rq
			TrazaPublisher.getInstance().publish(auditorRq);
		} catch (Exception e1) {
			ErrorData errorData = PublisherUtil.getInstance().getErrorData(e1, rquid,
					ExceptionManager.PP_PORTAL_GENERIC_01, userName,
					ExceptionManager.MSG_PORTAL_GENERIC_01
							+ " Operación: auditorRsExecutePayment, Realizar pago facturadores",
					"auditorRsExecutePayment", rContenido.getPortletOrigen(), rContenido.getPaginaOrigen(),
					rContenido.getPortalOrigen());
			logger.error(errorData, e1);
		}
	}
	
	private boolean validacionTopeFactura(DatosPagoFactBean param, String valorFactura, String valorPago, Integer porcentajeTope)
	{
		logger.info("VALOR ORIGINAL DE ENTRADA, valor pago: " + valorPago + ", valor factura: " + valorFactura+", porcentajeTope: "+porcentajeTope);
		boolean pagoValido = true;
		valorFactura = valorFactura.replace(".", "");
		valorPago = valorPago.replace(".", "");
		logger.info("Ingresa a validación de tope, valor pago(String): " + valorPago + ", valor factura(String): " + valorFactura);
		BigDecimal valorFacturaB =  new BigDecimal(valorFactura);
		BigDecimal valorPagoB =  new BigDecimal(valorPago);
		
    	if((valorPagoB.compareTo(valorFacturaB)>0) && porcentajeTope == null)
    	{
    		logger.info("El valor de pago excede el valor de la factura, valor pago: " + Integer.parseInt(valorPago) + ", valor factura: " + Integer.parseInt(valorFactura));
    		param.mostrarModal("El valor del pago no puede exceder el valor de la factura", "icon-error", "Valor Pago Invalido");
    		pagoValido = false;
    		logger.info("Pago valido: " + pagoValido);
    	}else {
    		BigDecimal porceValor = porcentajeValor(valorFactura, porcentajeTope);
    		logger.info("Valor pago porcentaje: " + porceValor);
           if(valorPagoB.compareTo(porceValor)>0 && porcentajeTope > 0){
         		logger.info("El valor de pago excede el valor del porcentaje, valor pago: " + Integer.parseInt(valorPago) + ", valor factura: " + Integer.parseInt(valorFactura) + ", porcentajeTope: " + porcentajeTope);
        		param.mostrarModal("Excede el monto máximo permitido para pago, si desea realizar pagos adicionales favor diríjase a nuestras oficinas o realícelo a través de nuestros canales Banca Móvil o Portal Transaccional. Para mayor información comuníquese a línea nacional 01 8000 514652 o en Bogotá al 390 20 58", "icon-error", "Valor Pago Invalido");
        		pagoValido = false;
        		logger.info("Pago valido por porcentaje: " + pagoValido);
    		}    		
    	}
		return pagoValido;
	}
	
	private BigDecimal porcentajeValor(String valorPago, Integer porcentajeTope){
		BigDecimal porcentajevalor= BigDecimal.ZERO;
		if(porcentajeTope == null) {
			porcentajevalor = new BigDecimal(valorPago);
		}else {			
			BigDecimal valorPagoB = new BigDecimal(valorPago);
			BigDecimal porcentaje = new BigDecimal(porcentajeTope);
			BigDecimal divisor = new BigDecimal(100);
			porcentajevalor = (valorPagoB.multiply(porcentaje)).divide(divisor);			
		}
		return porcentajevalor;
	}
}