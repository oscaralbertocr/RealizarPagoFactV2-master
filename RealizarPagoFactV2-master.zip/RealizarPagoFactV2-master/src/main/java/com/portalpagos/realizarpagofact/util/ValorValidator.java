package com.portalpagos.realizarpagofact.util;

import java.util.ResourceBundle;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.component.UIInput;
import javax.faces.context.FacesContext;
import javax.faces.validator.FacesValidator;
import javax.faces.validator.Validator;
import javax.faces.validator.ValidatorException;

/**
 * HU21 Clase que realiza la validaci�n de que el valor ingresado sea mayor a
 * cero
 * 
 * @author: M�lany Rozo
 * @Since: 18/12/14
 **/

@FacesValidator(value = "valorValidator")
public class ValorValidator implements Validator {

	/**
	 * Funci�n que obtiene el valor del campo Valor Parcial y valida que sea
	 * mayor a cero
	 * 
	 * @author: M�lany Rozo
	 * @Since: 18/12/14
	 **/
	@Override
	public void validate(FacesContext context, UIComponent component, Object value)
			throws ValidatorException {
		
		//Se obtiene el valor del campo de tipo de pago
		UIInput tipoPago = (UIInput) component.getAttributes().get("tipoPago");
		Object tipo = tipoPago.getSubmittedValue();

		if(tipo.equals("2")){
			//Se obtiene el valor del campo de valor parcial
			UIInput valorInput = (UIInput) component.getAttributes().get("valorPagoParcial");
			Object valorPago = valorInput.getSubmittedValue();
			
			if(valorPago!=null || !"".equals(valorPago)){
				String val=(String) valorPago;
				String valor=val.replace(".", "");
				int numero;
				try{
					numero=Integer.parseInt(valor);
				}catch(Exception e){
					ResourceBundle rb = ResourceBundle.getBundle("com.portalpagos.realizarpagofact.portlet.nl.RealizarPagoFactV2PortletResource");
					String mensaje = rb.getString("msg.valorCero");
					FacesMessage msg = new FacesMessage(mensaje);
				    msg.setSeverity(FacesMessage.SEVERITY_ERROR);
				    throw new ValidatorException(msg);
				}
				
				
				if(numero<=0){
					ResourceBundle rb = ResourceBundle.getBundle("com.portalpagos.realizarpagofact.portlet.nl.RealizarPagoFactV2PortletResource");
					String mensaje = rb.getString("msg.valorCero");
					FacesMessage msg = new FacesMessage(mensaje);
				    msg.setSeverity(FacesMessage.SEVERITY_ERROR);
				    throw new ValidatorException(msg);
				}
				
			}
			
		}	
	}
}
