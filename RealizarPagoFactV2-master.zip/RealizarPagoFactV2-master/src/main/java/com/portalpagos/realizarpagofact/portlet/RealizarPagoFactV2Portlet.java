package com.portalpagos.realizarpagofact.portlet;

import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.ResourceBundle;

import javax.naming.NamingException;
import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.Event;
import javax.portlet.EventRequest;
import javax.portlet.EventResponse;
import javax.portlet.GenericPortlet;
import javax.portlet.PortletException;
import javax.portlet.PortletPreferences;
import javax.portlet.PortletRequest;
import javax.portlet.PortletRequestDispatcher;
import javax.portlet.PortletSession;
import javax.portlet.ProcessAction;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;
import javax.portlet.ResourceRequest;
import javax.portlet.ResourceResponse;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.exception.ExceptionUtils;

import com.ath.portalpagos.util.ExceptionManager;
import com.ath.portalpagos.util.IpNodoPortal;
import com.ath.portalpagos.util.JSONUtil;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.ibm.portal.portlet.service.PortletServiceUnavailableException;
import com.ibm.portal.um.User;
import com.ibm.portal.um.exceptions.PumaException;
import com.portalpagos.realizarpagofact.beans.CaptchaBean;
import com.portalpagos.realizarpagofact.beans.DatosPagoFactBean;
import com.portalpagos.realizarpagofact.beans.DatosPagoFactWcmBean;
import com.portalpagos.realizarpagofact.beans.RutaContenidoBean;
import com.portalpagos.realizarpagofact.util.CommonUtils;
import com.portalpagos.realizarpagofact.util.ErrorManager;
import com.portalpagos.realizarpagofact.util.PagarListener;
import com.portalpagos.realizarpagofact.util.PagoAgilListener;
import com.portalpagos.realizarpagofact.util.Puma;
import com.portalpagos.realizarpagofact.util.ReferenciaValidator;

import co.com.ath.clientes.payments.mc.service.util.ConfigurationService;
import co.com.ath.logger.CustomLogger;
import co.com.ath.parameterspage.ParametersPage;
import co.com.ath.payments.mc.auditor.publisher.traza.TrazaPublisher;
import co.com.ath.payments.mc.auditor.publisher.util.PublisherUtil;
import co.com.ath.payments.mc.auditor.publisher.util.WebServiceClientHTTPS;
import co.com.ath.payments.mc.service.model.AuditorRq;
import co.com.ath.payments.mc.service.model.ErrorData;
import co.com.ath.payments.mc.service.model.json.BankInfoType;
import co.com.ath.payments.mc.service.model.json.CnvBusquedasFrecuentesRq;
import co.com.ath.payments.mc.service.model.json.CnvBusquedasFrecuentesRs;
import co.com.ath.payments.mc.service.model.json.ReferenceType;

/**
 * A sample portlet
 */
public class RealizarPagoFactV2Portlet extends GenericPortlet {

    private static final String RQ = "RQ";
    private CustomLogger logger = new CustomLogger(RealizarPagoFactV2Portlet.class);
    private static String user;
    private static String ip;
    private static String rquid;
    private static final String DOSPUNTOS = ":";
    private static final String COD_CONVENIO = "Código Convenio";
    private static final String NODO = "Nodo Portal";
    
    private boolean guardarBusqueda;
    private static final String MAX_LENGTH = "8";

    /**
     * @see javax.portlet.Portlet#init()
     */
    public void init() throws PortletException {
        super.init();
        this.guardarBusqueda = Boolean.FALSE;
    }

    /**
     * Serve up the <code>view</code> mode.
     * 
     * @see javax.portlet.GenericPortlet#doView(javax.portlet.RenderRequest, javax.portlet.RenderResponse)
     */
    public void doView(RenderRequest request, RenderResponse response) throws PortletException, IOException {
    	logger.info("Cargando doView...");
        RutaContenidoBean rContenido = null;
        // Set the MIME type for the render response
        response.setContentType(request.getResponseContentType());
        PortletRequestDispatcher rd;
        try {
            consultarDatosIniciales(request);
            rContenido = rutaContenido(request, response);
            DatosPagoFactWcmBean bean = (DatosPagoFactWcmBean) request.getPortletSession().getAttribute("datosPagoFactWcmBean",
                    PortletSession.APPLICATION_SCOPE);
            
            if (null == bean) {
                bean = new DatosPagoFactWcmBean();
            }

            DatosPagoFactWcmBean beanPagoFactWcm = bean.cargarDatos(request, logger, user, rquid);
            bean.setErrorCaptcha(beanPagoFactWcm.getErrorCaptcha());
            // generación del captcha
            generarCaptcha(request, response, rContenido, beanPagoFactWcm.getIntentosMaxCaptcha());

            request.setAttribute("msgErrorCaptcha", beanPagoFactWcm.getErrorCaptcha());
            request.getPortletSession().setAttribute("datosPagoFactWcmBean", bean, PortletSession.APPLICATION_SCOPE);

            String vista = request.getParameter("vista");
            String errorReferencia = request.getParameter("errorReferencia");
            if (null != vista) {
                cargarInfoReferencia(request);
                rd = getPortletContext().getRequestDispatcher(vista);
            } else {
                if (request.getParameter("evento") != null) {
                    cargarInfoReferencia2(request);
                    vista = "/jsp/formConfirmacionPago.jsp";
                    request.removeAttribute("evento");
                    request.removeAttribute("pagoParcial");
                    request.removeAttribute("pagoTotal");
                    request.removeAttribute("refPago");
                } else {
                    cargarInfoReferencia(request);
                    vista = "/jsp/CapturaReferenciaView.jsp";
                }
            }
            logger.info("Vista que se desea renderiza: " + vista);
            logger.info("Error referencia: " + errorReferencia);
            if (null != errorReferencia && !"".equals(errorReferencia)) {
                request.setAttribute("errorReferencia", errorReferencia);
            }
            rd = getPortletContext().getRequestDispatcher(vista);
            rd.include(request, response);

            this.guardarBusqueda = Boolean.FALSE;
        } catch (NoClassDefFoundError e) {
        	logger.info("NoClassDefFoundError en doview");
            Exception e1 = (Exception) ExceptionUtils.getRootCause(e);
            ErrorData errorData = PublisherUtil.getInstance().getErrorData(e1, rquid, ExceptionManager.PP_PORTAL_LIBRERIAS_01, user,
                    ExceptionManager.MSG_PORTAL_LIBRERIAS_01 + " - Operación: Cargar vista, Realizar pago facturadores", "doView",
                    rContenido.getPortletOrigen(), rContenido.getPaginaOrigen(), rContenido.getPortalOrigen());
            logger.error(errorData, e1);
            String error[] = ErrorManager.getInstance(request).obtenerErrorWCM(rContenido.getPathErroresTecnicos(),
                    ExceptionManager.PP_PORTAL_LIBRERIAS_01);
            this.mostrarModalError(request, error);
        } catch (Exception e) {
            try {
                throw ExceptionUtils.getRootCause(e);
            } catch (Exception e1) {
                ErrorData errorData = PublisherUtil.getInstance().getErrorData(e1, rquid, ExceptionManager.PP_PORTAL_FACES_01, user,
                        ExceptionManager.MSG_PORTAL_FACES_01 + " - Operación: Cargar vista, Realizar pago facturadores", "doView",
                        rContenido.getPortletOrigen(), rContenido.getPaginaOrigen(), rContenido.getPortalOrigen());
                logger.error(errorData, e1);
                String error[] = ErrorManager.getInstance(request).obtenerErrorWCM(rContenido.getPathErroresTecnicos(),
                        ExceptionManager.PP_PORTAL_FACES_01);
                this.mostrarModalError(request, error);
            } catch (Throwable e1) {
                ErrorData errorData = PublisherUtil.getInstance().getErrorData(e, rquid, ExceptionManager.PP_PORTAL_GENERIC_01, user,
                        ExceptionManager.MSG_PORTAL_GENERIC_01 + " - Operación: Cargar vista, Realizar pago facturadores", "doView",
                        rContenido.getPortletOrigen(), rContenido.getPaginaOrigen(), rContenido.getPortalOrigen());
                logger.error(errorData, e);
                String error[] = ErrorManager.getInstance(request).obtenerErrorWCM(rContenido.getPathErroresTecnicos(),
                        ExceptionManager.PP_PORTAL_GENERIC_01);
                this.mostrarModalError(request, error);
            }
        }
    }

    /**
     * Función encargada de setear datos al bean para mostrar modal de error
     * 
     * @author melany.rozo
     * @since 08/09/2015
     */
    public void mostrarModalError(PortletRequest request, String error[]) {
    	logger.info("Mostrando modal error en portlet");
        PortletSession session = request.getPortletSession();
        try {
            DatosPagoFactBean bean = (DatosPagoFactBean) session.getAttribute("datosPagoFactBean", PortletSession.APPLICATION_SCOPE);
            logger.info("bean de sesión en mostrar modal: " + bean);
            if (null == bean) {
                bean = new DatosPagoFactBean();
            }
            bean.mostrarModal(error[0], "icon-error", error[1]);
            session.setAttribute("datosPagoFactBean", bean, PortletSession.APPLICATION_SCOPE);
        } catch (Exception e) {
            RutaContenidoBean rContenido = (RutaContenidoBean) session.getAttribute("RutaContenidoBean", PortletSession.APPLICATION_SCOPE);
            ErrorData errorData = PublisherUtil.getInstance().getErrorData(e, rquid, ExceptionManager.PP_PORTAL_GENERIC_01, user,
                    ExceptionManager.MSG_PORTAL_GENERIC_01 + " - Operación: mostrarModalError, Realizar pago facturadores",
                    "mostrarModalError", rContenido.getPortletOrigen(), rContenido.getPaginaOrigen(), rContenido.getPortalOrigen());
            logger.error(errorData, e);
        }
    }

    /**
     * Función encargada de obtener los datos básicos necesarios para traza, auditoría y logs
     * 
     * @author melany.rozo
     * @since 07/09/2015
     */
    public void consultarDatosIniciales(PortletRequest request) {
    	logger.info("Consultando datos iniciales...");
        PortletSession session = request.getPortletSession();
        RutaContenidoBean rContenido = (RutaContenidoBean) session.getAttribute("RutaContenidoBean", PortletSession.APPLICATION_SCOPE);

        try {
            // Se genera un RQUID si no existe uno y se guarda en sesión
            rquid = (String) session.getAttribute("rquid", PortletSession.APPLICATION_SCOPE);
            if (null == rquid) {
                rquid = PublisherUtil.getInstance().generateRequestID();
                session.setAttribute("rquid", rquid, PortletSession.APPLICATION_SCOPE);
            }

            // Se consulta el usuario autenticado y se guarda en sesión
            user = (String) session.getAttribute("user", PortletSession.APPLICATION_SCOPE);
            if (null == user) {
                Puma puma = new Puma();
                User currentUser = puma.getCurrenUser(request);
                if (null != currentUser) {
                    user = puma.getPropertyFromPuma("uid", request);
                    session.setAttribute("user", user, PortletSession.APPLICATION_SCOPE);
                } else {
                    user = null;
                    session.removeAttribute("user");
                }
            }

            // Se obtiene ip del usuario y se guarda en sesión
            ip = (String) request.getPortletSession().getAttribute("ip", PortletSession.APPLICATION_SCOPE);
            if (null == ip) {
                ip = getIpAddr(com.ibm.ws.portletcontainer.portlet.PortletUtils.getHttpServletRequest(request), request);
                session.setAttribute("ip", ip, PortletSession.APPLICATION_SCOPE);
            }
            logger.info("Datos iniciales: Rquid: " + rquid + ", user: " + user + ", ip: " + ip);

        } catch (PortletServiceUnavailableException e) {
            ErrorData errorData = PublisherUtil.getInstance().getErrorData(e, rquid, ExceptionManager.PP_PORTAL_PUMA_01, user,
                    ExceptionManager.MSG_PORTAL_PUMA_01 + " - Operación: consultarDatosIniciales, Realizar pago facturadores",
                    "consultarDatosIniciales", rContenido.getPortletOrigen(), rContenido.getPaginaOrigen(), rContenido.getPortalOrigen());
            logger.error(errorData, e);
        } catch (NamingException e) {
            ErrorData errorData = PublisherUtil.getInstance().getErrorData(e, rquid, ExceptionManager.PP_PORTAL_PUMA_01, user,
                    ExceptionManager.MSG_PORTAL_PUMA_01 + " - Operación: consultarDatosIniciales, Realizar pago facturadores",
                    "consultarDatosIniciales", rContenido.getPortletOrigen(), rContenido.getPaginaOrigen(), rContenido.getPortalOrigen());
            logger.error(errorData, e);
        } catch (PumaException e) {
            ErrorData errorData = PublisherUtil.getInstance().getErrorData(e, rquid, ExceptionManager.PP_PORTAL_PUMA_01, user,
                    ExceptionManager.MSG_PORTAL_PUMA_01 + " - Operación: consultarDatosIniciales, Realizar pago facturadores",
                    "consultarDatosIniciales", rContenido.getPortletOrigen(), rContenido.getPaginaOrigen(), rContenido.getPortalOrigen());
            logger.error(errorData, e);
        } catch (Exception e) {
            ErrorData errorData = PublisherUtil.getInstance().getErrorData(e, rquid, ExceptionManager.PP_PORTAL_GENERIC_01, user,
                    ExceptionManager.MSG_PORTAL_GENERIC_01 + " - Operación: consultarDatosIniciales, Realizar pago facturadores",
                    "consultarDatosIniciales", rContenido.getPortletOrigen(), rContenido.getPaginaOrigen(), rContenido.getPortalOrigen());
            logger.error(errorData, e);
        }
    }

    public void processEvent(EventRequest request, EventResponse response) throws PortletException {
    	logger.info("Iniciando Process Event...");
        Event event = request.getEvent();
        String responseEventData = event.getValue().toString();
        logger.info("Parametros del evento entrante: " + responseEventData);
        try {
            String categoriaArray[] = responseEventData.split("°");
            String idConvenio = "";
            String idRequest = "";
            logger.info("event::  " + responseEventData);
            if (!categoriaArray[0].equals("ConvFrecuentes")) {
            	this.validarPeticionBusqueda(categoriaArray);
                idConvenio = categoriaArray[0];
                logger.info("Id convenio event: " + idConvenio);
                String pagParcial = categoriaArray[1];
                logger.info("pagParcial event: " + pagParcial);
                String pagTotal = categoriaArray[2];
                logger.info("pagTotal event: " + pagTotal);
                String bandera = categoriaArray[3];
                logger.info("bandera event: " + bandera);
                idRequest = categoriaArray[4];

                String listadoReferencias = categoriaArray[5];

                response.setRenderParameter("nombre", bandera);
                response.setRenderParameter("evento", "true");
                response.setRenderParameter("pagoParcial", pagParcial);
                response.setRenderParameter("pagoTotal", pagTotal);
                response.setRenderParameter("rquid", idRequest);

                response.setRenderParameter("refPago", listadoReferencias);

            } else {
            	idConvenio = categoriaArray[1];
                logger.info("Id del convenio convFrecuentes event: " + idConvenio);
                idRequest = categoriaArray[2];
                this.validarPeticionBusqueda(categoriaArray);
                if (categoriaArray.length > 2) {
                    String referenciasAdicionales = categoriaArray[3];
                    logger.info("ref adicionales convFrecuentes event: " + referenciasAdicionales);
                    response.setRenderParameter("referenciasAdicionales", referenciasAdicionales);
                    // HU 60.1.6.2 INI
                    // Otros datos del pago que vienen de convenios frecuentes
                    if (categoriaArray.length > 3) {
                        response.setRenderParameter("datosPago", responseEventData);
                        response.setRenderParameter("conveniosFrecuetes", "convFrec");
                    }
                    // HU 60.1.6.2 FIN
                }
            }
            response.setRenderParameter("convenioId", idConvenio);
            response.setRenderParameter("rquid", idRequest);
            request.getPortletSession().setAttribute("rquid", idRequest, PortletSession.APPLICATION_SCOPE);

        } catch (Exception e) {
        	logger.info("Exception en process event: " + e.getMessage());
            String categoriaArray[] = responseEventData.split("°");
            responseEventData = categoriaArray[0];
            String idRequest = categoriaArray[1];
            response.setRenderParameter("convenioId", responseEventData);
            response.setRenderParameter("rquid", idRequest);
        }

    }
    
    /**
     * 
     * @param categoriaArray
     * @throws Exception
     */
    private void validarPeticionBusqueda(String categoriaArray[]) throws Exception{
    	
    	if(categoriaArray.length == 3 && categoriaArray[2].equals("buscar")){
    		this.guardarBusqueda = Boolean.TRUE;
    	}
    }

    /**
     * HU60.3 Método encargado de consultar la informacion del convenio para cargar los datos respectivos de la factura
     * 
     * @author santiago.cuervo
     */
    public void cargarInfoReferencia2(RenderRequest request) {
    	logger.info("Cargando Info referencia evento...");
        String sinReferenciaAdicional = "";
        DatosPagoFactBean bean = (DatosPagoFactBean) request.getPortletSession().getAttribute("datosPagoFactBean",
                PortletSession.APPLICATION_SCOPE);
        RutaContenidoBean rContenido = (RutaContenidoBean) request.getPortletSession().getAttribute("RutaContenidoBean",
                PortletSession.APPLICATION_SCOPE);
        if (null == bean) {
            bean = new DatosPagoFactBean();
        }

        try {
            String convenioId = request.getParameter("convenioId");
            logger.info("convenioId param cargar referencia event: " + convenioId);
            if (null == convenioId) {
                convenioId = this.capturarId(request);
                if (null == convenioId) {
                    convenioId = bean.getIdConvenio();
                }
            }
            logger.info("convenioId cargar referencia event: " + convenioId);
            request.setAttribute("urlHome", rContenido.getUrlHome());
            if (null != convenioId) {
                if (bean.getIdConvenio() != convenioId) {
                    bean = new DatosPagoFactBean();
                    bean.setIdConvenio(convenioId);

                    String valorPago = request.getParameter("pagoTotal");
                    logger.info("valor pagos cargar referencia event: " + valorPago);
                    
                    bean.setValorPago(valorPago);
                    bean.setValorTotal(valorPago);
                    bean.setValorPagoParcial(request.getParameter("pagoParcial"));
                    bean.setIsMisFinanzas(true);
                    
                    // Obtiene la lista de referecias y lo convierte de string a objeto
                    String refPago = request.getParameter("refPago");
                    logger.info("refPago cargar referencia event: " + refPago);
                    Gson gson = new Gson();
                    Type type = new TypeToken<List<ReferenceType>>() {
                    }.getType();
                    List<ReferenceType> listaReferencias = gson.fromJson(refPago, type);
                    String numeroRefPago = "";
                    if (null != listaReferencias.get(0).getReference() && !listaReferencias.get(0).getReference().equals("")) {
                        numeroRefPago = listaReferencias.get(0).getReference();
                    }
                    bean.setValoresReferenciaAdicionalList(listaReferencias);
                    bean.setReferenciaPago(numeroRefPago);
                    bean.cargarDatos(rContenido.getUrlImagenes(), request, sinReferenciaAdicional);
                }
            } else {
            	logger.info("No se pudo cargar el id del convenio");
                String[] error = ErrorManager.getInstance(request).obtenerErrorWCM(rContenido.getPathErroresTecnicos(), "");
                bean.mostrarModal(error[0], "icon-error", error[1]);
            }
            // Se valida si es un pago de taquillas y se concatena a la url el id del convenio para cargar la personalizacion en comprobante
            // de pago
            logger.info("Es pago por ventanilla: " + rContenido.getTaquillas());
            if (null != rContenido.getTaquillas() && !"".equals(rContenido.getTaquillas())) {
                rContenido.setUrlRetornoPasarela(rContenido.getUrlRetornoPasarela() + "idConv=" + bean.getIdConvenio() + "&");
            }
        } catch (Exception e) {
            ErrorData errorData = PublisherUtil.getInstance().getErrorData(e, rquid, ExceptionManager.PP_PORTAL_GENERIC_01, user,
                    ExceptionManager.MSG_PORTAL_GENERIC_01 + " - Operación: cargarInfoReferencia2, Realizar pago facturadores",
                    "cargarInfoReferencia2", rContenido.getPortletOrigen(), rContenido.getPaginaOrigen(), rContenido.getPortalOrigen());
            logger.error(errorData, e);
            String error[] = ErrorManager.getInstance(request).obtenerErrorWCM(rContenido.getPathErroresTecnicos(),
                    ExceptionManager.PP_PORTAL_GENERIC_01);
            this.mostrarModalError(request, error);
        } finally {
        	logger.info("Bean seteado a sesión: " + bean);
            request.getPortletSession().setAttribute("datosPagoFactBean", bean, PortletSession.APPLICATION_SCOPE);
        }
    }

    /**
     * HU18 Método encargado de obtener el id del convenio por evento, por url o del bean y mostrar el formulario con los datos respectivos.
     * 
     * @author melany.rozo
     * @since 24/03/2015
     * @exception Controla
     *                los errores ocasionados cuando no se puede capturar el id del convenio
     */
    public void cargarInfoReferencia(RenderRequest request) {
    	logger.info("Cargando info referencia...");
        DatosPagoFactBean bean = (DatosPagoFactBean) request.getPortletSession().getAttribute("datosPagoFactBean",
                PortletSession.APPLICATION_SCOPE);
        RutaContenidoBean rContenido = (RutaContenidoBean) request.getPortletSession().getAttribute("RutaContenidoBean",
                PortletSession.APPLICATION_SCOPE);
        
        if (null == bean) {
            bean = new DatosPagoFactBean();
        }

        try {
            String convenioId = request.getParameter("convenioId");
            logger.info("Convenio id [cargarInfoReferencia]: " + convenioId);
            String refernAdicionales = request.getParameter("referenciasAdicionales");
            logger.info("refernAdicionales [cargarInfoReferencia]: " + refernAdicionales);
            if (null == convenioId) {
                convenioId = this.capturarId(request);
                if (null == convenioId) {
                    convenioId = bean.getIdConvenio();
                }
            }

            // HU 60.1.6.2 INI
            String datosPago = request.getParameter("datosPago");
            logger.info("datosPago [cargarInfoReferencia]: " + datosPago);
            String datosConvFrec = request.getParameter("conveniosFrecuetes");
            logger.info("datosConvFrec [cargarInfoReferencia]: " + datosConvFrec);
            
            String intencionPago = "";
            String tipoDocumento = "";
            String numeroDocumento = "";
            boolean mostrarTooltip = false;
            if (null != datosConvFrec && !"".equals(datosConvFrec)) {
                if (null != datosPago && datosPago.trim().length() > 0) {
                    String datosPagoSplit[] = datosPago.split("°");
                    if (datosPagoSplit.length > 5) {
                        tipoDocumento = datosPagoSplit[6] != null ? datosPagoSplit[6] : "";
                        numeroDocumento = datosPagoSplit[7] != null ? datosPagoSplit[7] : "";
                        intencionPago = datosPagoSplit[8] != null && !datosPagoSplit[8].equals("-1") ? datosPagoSplit[8] : "";

                        mostrarTooltip = true;
                    }
                }
            }
            // HU 60.1.6.2 FIN
            
            String origen = capturoParametro(request, rContenido, "origen");
            if (origen != null && !origen.isEmpty() && origen.equals("buscar")){
            	this.guardarBusqueda = Boolean.TRUE;
            }

            // Traza RQ Iniciar Pago
            auditorRqInicarPago(rContenido.getAccionIniciarPago(), rquid, rContenido.getBankName(), rContenido.getPortletOrigen(),
                    rContenido.getPaginaOrigen(), ip, user, convenioId, rContenido);
            request.setAttribute("urlHome", rContenido.getUrlHome());
            if (null != convenioId) {
                if (bean.getIdConvenio() != convenioId) {
                    bean = new DatosPagoFactBean();
                    bean.setIdConvenio(convenioId);
                    // HU 60.1.6.2 INI
                    bean.setIntencionPago(intencionPago);
                    bean.setTipoDocumento(tipoDocumento);
                    bean.setNumeroDocumento(numeroDocumento);
                    bean.setMostrarTooltipValorPAgo(mostrarTooltip);
                    // HU 60.1.6.2 FIN
                    bean.cargarDatos(rContenido.getUrlImagenes(), request, refernAdicionales);

                    if (null != datosConvFrec && !"".equals(datosConvFrec)) {
                        if (tipoDocumento != null && !"".equals(tipoDocumento)) {
                            bean.setTipoDocumento(tipoDocumento);
                        }
                        if (numeroDocumento != null && !"".equals(numeroDocumento)) {
                            bean.setNumeroDocumento(numeroDocumento);
                        }
                        if (intencionPago != null && !"".equals(intencionPago) && !"-1".equals(intencionPago)) {
                            bean.setIntencionPago(intencionPago);
                        }
                        bean.setMostrarTooltipValorPAgo(mostrarTooltip);
                    }

                }
            } else {
            	logger.info("No se pudo obtener el id del convenio");
                String[] error = ErrorManager.getInstance(request).obtenerErrorWCM(rContenido.getPathErroresTecnicos(), "");
                bean.mostrarModal(error[0], "icon-error", error[1]);
            }

            // Se valida si es un pago de taquillas y se concatena a la url el id del convenio para cargar la personalizacion en comprobante
            // de pago
            logger.info("Pago taquilla: " + rContenido.getTaquillas());
            if (null != rContenido.getTaquillas() && !"".equals(rContenido.getTaquillas())) {
                rContenido.setUrlRetornoPasarela(rContenido.getUrlRetornoPasarela() + "idConv=" + bean.getIdConvenio() + "&");
            }

            /* Incidencia ventanilla in-habilitada */
            String previsualizacion = capturoParametro(request, rContenido, "rCarga");
            if (rContenido.getTaquillas() != null && !"".equals(rContenido.getTaquillas())) {
                if (null != previsualizacion && !"".equals(previsualizacion) && "p".equals(previsualizacion)) {
                    logger.info("Pago normal [cargarInfoReferencia]");
                	bean.setValidacionEstadoVentanilla("");
                } else {
                	logger.info("Pago ventanilla [cargarInfoReferencia]");
                    bean.consultarConfiguracionVentanilla(convenioId);
                }
            } else {
                bean.setValidacionEstadoVentanilla("");
            }

            // Se verifica que el portlet origen alguno de busqueda
			if(this.guardarBusqueda && bean.getNombreConvenio() != null && !bean.getNombreConvenio().isEmpty()){
				try{
					guardarBusquedaFrecuente(bean.getNombreConvenio(), rContenido);
				} catch(Exception e){
					logger.error("No se guardó la busqueda frecuente con el convenio: " + bean.getNombreConvenio(), e);
				}
			}
        } catch (Exception e) {
            ErrorData errorData = PublisherUtil.getInstance().getErrorData(e, rquid, ExceptionManager.PP_PORTAL_GENERIC_01, user,
                    ExceptionManager.MSG_PORTAL_GENERIC_01 + " - Operación: cargarInfoReferencia, Realizar pago facturadores",
                    "cargarInfoReferencia", rContenido.getPortletOrigen(), rContenido.getPaginaOrigen(), rContenido.getPortalOrigen());
            logger.error(errorData, e);
            String error[] = ErrorManager.getInstance(request).obtenerErrorWCM(rContenido.getPathErroresTecnicos(),
                    ExceptionManager.PP_PORTAL_GENERIC_01);
            this.mostrarModalError(request, error);
            bean.mostrarModal(error[0], "icon-error", error[1]);
        } finally {
        	logger.info("Bean seteado en sesión [cargarInfoReferencia]");
            request.getPortletSession().setAttribute("datosPagoFactBean", bean, PortletSession.APPLICATION_SCOPE);
        }
    }
    
    /**
	 * 
	 * @param nombreConvenio
	 * @throws Exception
	 */
	private void guardarBusquedaFrecuente(String nombreConvenio, RutaContenidoBean rContenido) throws Exception{
		
		CnvBusquedasFrecuentesRq request = new CnvBusquedasFrecuentesRq();
		CnvBusquedasFrecuentesRs response = new CnvBusquedasFrecuentesRs();
		BankInfoType bankInfo = new BankInfoType();
		
		// Se configura el request
		bankInfo.setBankId(rContenido.getBankId());
		bankInfo.setBankName(rContenido.getBankName());
		
		request.setBankInfo(bankInfo);
		request.setIpAddress(rContenido.getIp());
		request.setNombreConvenio(nombreConvenio);
		request.setRequestDate(new Date());
		request.setRequestID(rquid);
		request.setRequestOriginPortal(rContenido.getPortletOrigen());
		request.setRequestPage(rContenido.getPaginaOrigen());
		
		logger.info("[REQUEST - addFrequentSearch] DATA: "+new Gson().toJson(request));
		
		String endpoint = ConfigurationService.getInstance().getEndpointRest();
		
		logger.info("[addFrequentSearch] ENDPOINT: "+endpoint+"addFrequentSearch");
		
		response = (CnvBusquedasFrecuentesRs) WebServiceClientHTTPS.getInstance(CnvBusquedasFrecuentesRs.class).procesarRequest(endpoint+"addFrequentSearch", request);
		
		logger.info("[RESPONSE - addFrequentSearch] DATA: "+new Gson().toJson(response));
	}

    /**
     * HU18.1
     * 
     * @Metodo capturaid. Recupera el id del convenio recibido por m�todo GET en la url
     * @author M�lany Rozo
     * @since 16/01/2015
     * @param request
     * @exception Controla
     *                los errores ocasionados cuando no se puede capturar el id del convenio
     */
    public String capturarId(RenderRequest request) {
        String idConv = null;
        try {
            // Captura del id del convenio enviado por method GET
            idConv = com.ibm.ws.portletcontainer.portlet.PortletUtils.getHttpServletRequest(request).getParameter("idConv");
            logger.info("Id del convenio url: " + idConv);
            // Si el id del convenio no tiene reflejado la ampliación de nura se suman la cantidad de ceros necesarios para completar ocho dígitos
            if (idConv != null && idConv != "" && !CommonUtils.getInstance().isAlphanumeric(idConv) 
            		&& idConv.length() <= 4) {
            	idConv = String.format("%" + MAX_LENGTH + "s", idConv).replace(" ", "0");
			 }
            logger.info("Id del convenio url pos: " + idConv);
        } catch (Exception e) {
            RutaContenidoBean rContenido = (RutaContenidoBean) request.getPortletSession().getAttribute("RutaContenidoBean",
                    PortletSession.APPLICATION_SCOPE);
            ErrorData errorData = PublisherUtil.getInstance().getErrorData(e, rquid, ExceptionManager.PP_PORTAL_GENERIC_01, user,
                    ExceptionManager.MSG_PORTAL_GENERIC_01 + " - Operación: capturarId, Realizar pago facturadores", "capturarId",
                    rContenido.getPortletOrigen(), rContenido.getPaginaOrigen(), rContenido.getPortalOrigen());
            logger.error(errorData, e);
            String error[] = ErrorManager.getInstance(request).obtenerErrorWCM(rContenido.getPathErroresTecnicos(),
                    ExceptionManager.PP_PORTAL_GENERIC_01);
            this.mostrarModalError(request, error);
        }

        return idConv;

    }

    /**
     * HU112.1 Metodo para consultar la ruta de contenido del parametro de pagina
     * 
     * @author santiago.cuervo
     */
    public RutaContenidoBean rutaContenido(RenderRequest request, RenderResponse response) {
        PortletPreferences preference = request.getPreferences();
        RutaContenidoBean rContenido = new RutaContenidoBean();
        try {
            // Obtener la ruta de la plantilla de creación en Portal
            String urlHome = (String) ParametersPage.getParameterPage(request, response, "urlHome");
            if (null == urlHome) {
                urlHome = preference.getValue("urlHome", "");
            }
            String urlImagenes = (String) ParametersPage.getParameterPage(request, response, "urlImagenes");
            if (null == urlImagenes) {
                urlImagenes = preference.getValue("urlImagenes", "");
            }
            String pathReferenceFacturadores = (String) ParametersPage.getParameterPage(request, response, "pathReferenceFacturadores");
            if (null == pathReferenceFacturadores) {
                pathReferenceFacturadores = preference.getValue("pathReferenceFacturadores", "");
            }
            // Variable para capturar parametro de pagina que indica que vengo de taquillas
            String pagoDesdeTaquillas = (String) ParametersPage.getParameterPage(request, response, "taquillas");

            String urlRetornoPasarela = (String) ParametersPage.getParameterPage(request, response, "urlRetornoPasarela");
            if (null == urlRetornoPasarela) {
                urlRetornoPasarela = preference.getValue("urlRetornoPasarela", "");
            }
            String tituloError = (String) ParametersPage.getParameterPage(request, response, "TituloError");
            if (null == tituloError) {
                tituloError = preference.getValue("TituloError", "");
            }

            String bankName = (String) ParametersPage.getParameterPage(request, response, "bankName");
            if (null == bankName) {
                bankName = preference.getValue("bankName", "");
            }

            String paginaOrigen = (String) ParametersPage.getParameterPage(request, response, "pagina-origen");
            if (null == paginaOrigen) {
                paginaOrigen = preference.getValue("pagina-origen", "");
            }

            String pathTerminosCondiciones = (String) ParametersPage.getParameterPage(request, response, "path-TerminosYCondiciones");
            if (null == pathTerminosCondiciones) {
                pathTerminosCondiciones = preference.getValue("path-TerminosYCondiciones", "");
            }

            String bankId = (String) ParametersPage.getParameterPage(request, response, "bankId");
            if (null == bankId) {
                bankId = preference.getValue("bankId", "");
            }

            String pathImagenConv = (String) ParametersPage.getParameterPage(request, response, "path-imagenConv");
            if (null == pathImagenConv) {
                pathImagenConv = preference.getValue("path-imagenConv", "");
            }

            String nombreBaseImgConvenio = (String) ParametersPage.getParameterPage(request, response, "nombreBaseImgConvenio");
            if (null == nombreBaseImgConvenio) {
                nombreBaseImgConvenio = preference.getValue("nombreBaseImgConvenio", "");
            }

            String pathErroresTecnicos = (String) ParametersPage.getParameterPage(request, response, "pathErroresTecnicos");
            if (null == pathErroresTecnicos) {
                pathErroresTecnicos = preference.getValue("pathErroresTecnicos", "");
            }
            
            //RQ30801 Indicar Medios de Pago
            String pathImagenMedioPago = (String) ParametersPage.getParameterPage(request, response, "path-imagenMedioPago");
            if (null == pathImagenMedioPago) {
            	pathImagenMedioPago = preference.getValue("path-imagenMedioPago", "");
            }

            ResourceBundle rb = ResourceBundle.getBundle("com.portalpagos.realizarpagofact.portlet.nl.RealizarPagoFactV2PortletResource");
            String portletOrigen = rb.getString("auditoria.nombrePortlet");

            rContenido.setTaquillas(pagoDesdeTaquillas);
            rContenido.setPathTerminosCondiciones(pathTerminosCondiciones);
            rContenido.setUrlHome(urlHome);
            rContenido.setUrlImagenes(urlImagenes);
            rContenido.setPathReferenceFacturadores(pathReferenceFacturadores);
            rContenido.setUrlRetornoPasarela(urlRetornoPasarela);
            rContenido.setTituloError(tituloError);
            rContenido.setBankName(bankName);
            rContenido.setPortalOrigen(bankName);
            rContenido.setPortletOrigen(portletOrigen);
            rContenido.setPaginaOrigen(paginaOrigen);
            rContenido.setBankId(bankId);
            rContenido.setPathImagenConv(pathImagenConv);
            rContenido.setNombreBaseImgConvenio(nombreBaseImgConvenio);
            rContenido.setPathErroresTecnicos(pathErroresTecnicos);
            
            //RQ30801 Indicar Medios de Pago
            rContenido.setPathImagenMedioPago(pathImagenMedioPago);

            Puma puma = new Puma();
            User user = puma.getCurrenUser(request);
            String tipoDoc = null, documento = null, userName = null;

            if (user != null) {
                tipoDoc = puma.getPropertyFromPuma("ath-tipo-documento", request);
                documento = puma.getPropertyFromPuma("ath-numero-documento", request);
                userName = puma.getPropertyFromPuma("uid", request);
            }
            rContenido.setTipoDoc(tipoDoc);
            rContenido.setDocumento(documento);
            rContenido.setUserName(userName);

            String dn = (String) ParametersPage.getParameterPage(request, response, "dn");
            rContenido.setDn(dn);

            rContenido.setAccionIniciarPago(rb.getString("auditoria.iniciarPago"));
            logger.info("Ruta contenido: " + rContenido);
            request.getPortletSession().setAttribute("RutaContenidoBean", rContenido, PortletSession.APPLICATION_SCOPE);

        } catch (Exception e) {
            ErrorData errorData = PublisherUtil.getInstance().getErrorData(e, rquid, ExceptionManager.PP_PORTAL_GENERIC_01, user,
                    ExceptionManager.MSG_PORTAL_GENERIC_01 + " - Operación: rutaContenido, Realizar pago facturadores", "rutaContenido",
                    rContenido.getPortletOrigen(), rContenido.getPaginaOrigen(), rContenido.getPortalOrigen());
            logger.error(errorData, e);
        }

        return rContenido;
    }

    /**
     * HU 144 Funcion encargada de obtener la ip del usuario, dado un request
     * 
     * @author melany.rozo
     * @since 06/08/2015
     */
    public String getIpAddr(HttpServletRequest request, PortletRequest requestPortlet) {

        String ip = null;

        try {
            final String WL_PROXY_CLIENT_IP = "WL-Proxy-Client-IP";
            final String PROXY_CLIENT_IP = "Proxy-Client-IP";
            final String X_FORWARDER_FOR = "X-Forwarded-For";
            final String HTTP_X_FORWARDED_FOR = "HTTP_X_FORWARDED_FOR";
            final String HTTP_CLIENT_IP = "HTTP_CLIENT_IP";

            ip = request.getHeader(X_FORWARDER_FOR);

            if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
                ip = request.getHeader(WL_PROXY_CLIENT_IP);
            }
            if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
                ip = request.getHeader(PROXY_CLIENT_IP);
            }
            if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
                ip = request.getHeader(HTTP_X_FORWARDED_FOR);
            }
            if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
                ip = request.getHeader(HTTP_CLIENT_IP);
            }
            if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
                ip = request.getRemoteAddr();
            }

            // Validaci�n realizada para equipos que retornan dos ips
            if (ip.contains(",")) {
                String[] ipOrigin = ip.split(",");
                ip = ipOrigin[1].trim();
            }

        } catch (Exception e) {

            RutaContenidoBean rContenido = (RutaContenidoBean) requestPortlet.getPortletSession().getAttribute("RutaContenidoBean",
                    PortletSession.APPLICATION_SCOPE);
            ErrorData errorData = PublisherUtil.getInstance().getErrorData(e, rquid, ExceptionManager.PP_PORTAL_GENERIC_01, user,
                    ExceptionManager.MSG_PORTAL_GENERIC_01 + " - Operación: getIpAddr, Realizar pago facturadores", "getIpAddr",
                    rContenido.getPortletOrigen(), rContenido.getPaginaOrigen(), rContenido.getPortalOrigen());
            logger.error(errorData, e);
        }

        return ip;
    }

    /**
     * HU 143 Función encargada de Trazar la Rq de Iniciar Pago
     * 
     * @author germán Díaz
     * @param idRequest
     * @since 09/09/2015
     */
    private void auditorRqInicarPago(String accion, String idRequest, String bancoNombre, String portlet, String pagOrigen, String ipAdress,
            String userName, String idConvenio, RutaContenidoBean rContenido) {
        try {
            // Objeto Auditor Rq
            AuditorRq auditorRq = new AuditorRq();
            auditorRq.setAction(accion);
            auditorRq.setAdditionalInfo(
                    JSONUtil.getJson(COD_CONVENIO + DOSPUNTOS + idConvenio, NODO + DOSPUNTOS + IpNodoPortal.getIpNodo()));
            auditorRq.setExecutionDate(CommonUtils.getInstance().asXMLGregorianCalendar(new Date()));
            auditorRq.setIpAddress(ipAdress);
            auditorRq.setOriginPortal(bancoNombre);
            auditorRq.setPage(pagOrigen);
            auditorRq.setPortlet(portlet);
            auditorRq.setRequestId(idRequest);
            auditorRq.setTipoServicio(RQ);
            auditorRq.setUser(userName);
            
            logger.info("auditorRq [auditorRqInicarPago]: " + new Gson().toJson(auditorRq));
            // Llamado al metodo para trazar rq
            TrazaPublisher.getInstance().publish(auditorRq);
        } catch (Exception e) {
            ErrorData errorData = PublisherUtil.getInstance().getErrorData(e, rquid, ExceptionManager.PP_PORTAL_GENERIC_01, user,
                    ExceptionManager.MSG_PORTAL_GENERIC_01 + " - Operación: auditorRqInicarPago, Realizar pago facturadores",
                    "auditorRqInicarPago", rContenido.getPortletOrigen(), rContenido.getPaginaOrigen(), rContenido.getPortalOrigen());
            logger.error(errorData, e);
        }
    }

    /**
     * HU53.5
     * 
     * @Metodo Obtener Capctha para establecerlo en la imagen del formulario
     * @author Germán Díaz
     * @since 19/11/2015
     * @param request
     *            , response
     */
    private void generarCaptcha(RenderRequest request, RenderResponse response, RutaContenidoBean rContenido, String maxIntentosCaptcha) {
        logger.info("Generando captcha...");
    	PortletSession session = request.getPortletSession();
        try {
            CaptchaBean elem = new CaptchaBean();
            if (session.getAttribute("intentos", PortletSession.APPLICATION_SCOPE) != null) {
                int cantidadIntentos = (Integer) session.getAttribute("intentos", PortletSession.APPLICATION_SCOPE);
                logger.info("Cantidad de intentos: " + cantidadIntentos);
                if (cantidadIntentos >= Integer.parseInt(maxIntentosCaptcha)) {
                    String imgCapctha = response.encodeURL("/simpleCaptcha.png");
                    String pathImgCapctha = response.encodeURL(request.getContextPath() + "/simpleCaptcha.png");
                    String pathNoImgCapctha = response.encodeURL(request.getContextPath());
                    elem.setImageCaptcha(imgCapctha);
                    elem.setPathImageCaptcha(pathImgCapctha);
                    elem.setPathNoImageCaptcha(pathNoImgCapctha);
                    elem.setActiveCaptcha("true");

                } else {
                    elem.setActiveCaptcha("false");
                }
            } else {
                elem.setActiveCaptcha("false");
            }

            session.setAttribute("captchaBean", elem, PortletSession.APPLICATION_SCOPE);
        } catch (Exception e) {
            ErrorData errorData = PublisherUtil.getInstance().getErrorData(e, rquid, ExceptionManager.PP_PORTAL_GENERIC_01, user,
                    ExceptionManager.MSG_PORTAL_GENERIC_01 + " - Operación: Generar Captcha, Realizar Pago Facturador", "generarCaptcha",
                    rContenido.getPortletOrigen(), rContenido.getPaginaOrigen(), rContenido.getPortalOrigen());
            logger.error(errorData, e);
        }
    }

    /**
     * HU21.7
     * 
     * @Metodo Obtiene las referencias ingresadas en el doview
     * @author German Diaz
     * @since 17/03/2016
     * @param request
     *            , response
     */
    private List<ReferenceType> obtenerReferenciasVista(ActionRequest request, String referenciaPagoPrincipal, String labelPrincipal) {
        String[] referenciasArray = request.getParameterValues("referenciaAdicional");

        List<ReferenceType> listaReferencia = new ArrayList<ReferenceType>();
        // Adiciona la referencia de pago Principal
        ReferenceType referenciasPrincipal = new ReferenceType();
        referenciasPrincipal.setReference(referenciaPagoPrincipal.equals("0") ? "" : referenciaPagoPrincipal);
        referenciasPrincipal.setPosition(1);
        referenciasPrincipal.setLabel(labelPrincipal);
        listaReferencia.add(referenciasPrincipal);

        // Adiciona las referencias adicionales
        if (null != referenciasArray) {
            String[] posicionArray = request.getParameterValues("referenciaAdicionalPosicion");
            List<String> posicionList = Arrays.asList(posicionArray);

            String[] labelsArray = request.getParameterValues("referenciaAdicionalLabel");
            List<String> labelList = Arrays.asList(labelsArray);
            int posReference = 0;
            for (String referencia : referenciasArray) {
                ReferenceType referencias = new ReferenceType();

                // Valida si la referencia seleccionada es tipo select, en este caso se envia vacio
                referencias.setReference(referencia.equals("0") ? "" : referencia);
                referencias.setPosition(Integer.parseInt(posicionList.get(posReference)));
                referencias.setLabel(labelList.get(posReference));
                posReference++;
                listaReferencia.add(referencias);
            }
        }
        logger.info("Cantidad de referencias obtenidas: " + listaReferencia.size());
        return listaReferencia;
    }

    @ProcessAction(name = "processAct")
    public void processAct(ActionRequest request, ActionResponse response) throws PortletException, java.io.IOException {
    	logger.info("Action para continuar al paso 3");
        PortletSession session = request.getPortletSession();
        DatosPagoFactBean bean = (DatosPagoFactBean) session.getAttribute("datosPagoFactBean", PortletSession.APPLICATION_SCOPE);
        try {
            String referenciaPago = request.getParameter("referenciaPagoFact");
            logger.info("Referencia pago [processAct]: " + referenciaPago);
            String confirmReferenciaFact = request.getParameter("confirmReferenciaFact");
            logger.info("Confirm referencia pago [processAct]: " + confirmReferenciaFact);

            String labelPrincipal = request.getParameter("referenciaPrincipalLabel");
            boolean flagError = true;
            // Obtiene las referencias de la vista HU 21.7
            if (null != referenciaPago && !"".equals(referenciaPago)) {

                List<ReferenceType> listaReferencia = obtenerReferenciasVista(request, referenciaPago, labelPrincipal);
                String intencionPago = request.getParameter("intencionPago");
                logger.info("intencionPago [processAct]: " + intencionPago);
                String tipoDocumento = request.getParameter("tipoDocumento");
                logger.info("tipoDocumento [processAct]: " + tipoDocumento);
                String numeroDocumento = request.getParameter("numeroDocumento");
                logger.info("numeroDocumento [processAct]: " + numeroDocumento);
                String comentarios = request.getParameter("comentariosFact");
                logger.info("comentarios [processAct]: " + comentarios);
                String mensaje = ReferenciaValidator.validate(referenciaPago, confirmReferenciaFact);
                if (!"".equals(mensaje)) {
                    response.setRenderParameter("vista", "/jsp/CapturaReferenciaView.jsp");
                    response.setRenderParameter("errorReferencia", mensaje);
                } else {
                    if (null != bean) {

                        bean.setReferenciaPago(referenciaPago);
                        bean.setValoresReferenciaAdicionalStringJson(new Gson().toJson(listaReferencia));
                        if (null != intencionPago && !"".equals(intencionPago)) {
                            bean.setIntencionPago(intencionPago);
                        }
                        if (null != tipoDocumento && !"".equals(tipoDocumento)) {
                            bean.setTipoDocumento(tipoDocumento);
                        }
                        bean.setNumeroDocumento(numeroDocumento);
                        bean.setComentarios(comentarios);

                        /*
                         * HU 21.7 Enviar etiquetas en el addTransaction
                         */
                        bean.setValoresReferenciaAdicionalList(listaReferencia);
                        /* FIN HU 21.7 */

                        /*
                         * HU 220 Enviar etiquetas en el addTransaction
                         */
                        String urlConv = request.getParameter("urlDelConvenio");
                        String temaConv = request.getParameter("temaDelConvenio");
                        bean.setUrlImgConvAddTran(urlConv);
                        bean.setTemaConv(temaConv);
                        /* FIN HU 220 */
                        String vistaResult = bean.continuar(request);
                        logger.info("Vista acción continuar: " + vistaResult);
                        response.setRenderParameter("vista", vistaResult);
                        if (vistaResult.equalsIgnoreCase("/jsp/formConfirmacionPago.jsp")) {
                            session.setAttribute("flagCustom", false);
                        }

                        session.setAttribute("datosPagoFactBean", bean, PortletSession.APPLICATION_SCOPE);
                    }
                }
            } else {
            	logger.info("Flujo pagar listener");
                // HU 231 validacion de topes
                if (bean.getIsCPV().isEmpty()) {
                    bean.consultaTopesPorValor(request);
                }

                String rdTipoConsulta = request.getParameter("tipoPago");
                logger.info("rdTipoConsulta [processAct]: " + rdTipoConsulta);

                // Obtiene de la sesion el bean de datos de pago

                String page = "";
                if (null != bean) {
                  //Si el pago se realiza desde mis finanzas
                    if (null != session.getAttribute("flagCustom") || (bean != null && bean.getIsMisFinanzas())) {
                        flagError = false;
                    }

                    if (null != bean.getReferenciaPago() && !bean.getReferenciaPago().isEmpty() && !flagError) {
                        page = PagarListener.processAction(request, response, rdTipoConsulta);
                    }
                    logger.info("Page pagarListener [processAct]: " + page);
                }
                if (!page.equals("")) {
                    response.setRenderParameter("vista", page);
                }
            }

        } catch (Exception e) {
            logger.info(e.getMessage());
        }
    }

    @ProcessAction(name = "pagoAgil")
    public void pagoAgil(ActionRequest request, ActionResponse response) throws PortletException, java.io.IOException {
        logger.info("Action pago agil...");
    	PortletSession session = request.getPortletSession();
        DatosPagoFactBean bean = (DatosPagoFactBean) session.getAttribute("datosPagoFactBean", PortletSession.APPLICATION_SCOPE);

        // HU 231 validacion de topes
        if (bean.getIsCPV().isEmpty()) {
            bean.consultaTopesPorValor(request);
        }
        String rdTipoConsulta = request.getParameter("tipoPago");
        logger.info("rdTipoConsulta [pagoAgil]: " + rdTipoConsulta);
        PagoAgilListener.processAction(request, response, rdTipoConsulta, bean.getValoresReferenciaAdicionalList());
        response.setRenderParameter("vista", "/jsp/formConfirmacionPago.jsp");
    }

    @ProcessAction(name = "processVolver")
    public void processVolver(ActionRequest request, ActionResponse response) throws PortletException, java.io.IOException {
        logger.info("Action volver...");
    	PortletSession session = request.getPortletSession();
        DatosPagoFactBean datosPagoFactBean = (DatosPagoFactBean) session.getAttribute("datosPagoFactBean",
                PortletSession.APPLICATION_SCOPE);
        datosPagoFactBean.setMostrarModal("false");
        session.setAttribute("datosPagoObligFinc", datosPagoFactBean, PortletSession.APPLICATION_SCOPE);
        response.setRenderParameter("vista", "/jsp/CapturaReferenciaView.jsp");
    }

    /* Obtener el valor del campo previsualizacion de la ventanilla de pagos */
    public String capturoParametro(RenderRequest request, RutaContenidoBean rContenido, String parametro) {
        String idConv = null;
        try {
            // Captura del id del convenio enviado por method GET
            idConv = com.ibm.ws.portletcontainer.portlet.PortletUtils.getHttpServletRequest(request).getParameter(parametro);
            logger.info("Id del convenio url: " + idConv);
         // Si el id del convenio no tiene reflejado la ampliación de nura se suman la cantidad de ceros necesarios para completar ocho dígitos
            if (idConv != null && idConv != "" && !CommonUtils.getInstance().isAlphanumeric(idConv) 
            		&& idConv.length() <= 4) {
            	idConv = String.format("%" + MAX_LENGTH + "s", idConv).replace(" ", "0");
			}
            logger.info("Id del convenio url pos: " + idConv);
        } catch (Exception e) {
            ErrorData errorData = PublisherUtil.getInstance().getErrorData(e, "", ExceptionManager.PP_PORTAL_GENERIC_01,
                    rContenido.getUserName(),
                    ExceptionManager.MSG_PORTAL_GENERIC_01 + " - Operacion: capturarId, Cargar Configuracion Ventanilla", "capturarId",
                    "Cargar configuracion Vanetanilla", rContenido.getPortalOrigen(), "Portal de Pagos");
            logger.error(errorData, e);
        }
        return idConv;

    }

    /*
     * (non-Javadoc)
     * 
     * @see javax.portlet.GenericPortlet#serveResource(javax.portlet.ResourceRequest, javax.portlet.ResourceResponse)
     */
    @Override
    public void serveResource(ResourceRequest request, ResourceResponse response) throws PortletException, IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        String resourceId = request.getResourceID();
        logger.info("resourceId [serveResource]: " + resourceId);
        PortletSession session = request.getPortletSession();
        if ("limpiarModalSession".equals(resourceId)) {
            logger.info("borrar la informacion del modal en sesion");
            try {
                DatosPagoFactBean bean = (DatosPagoFactBean) session.getAttribute("datosPagoFactBean", PortletSession.APPLICATION_SCOPE);
                logger.info("Bean attribute [serveResource]: " + bean);
                bean.setMostrarModal("false");
                session.setAttribute("datosPagoFactBean", bean, PortletSession.APPLICATION_SCOPE);
            } catch (Exception e) {
                logger.error("Error al borrar la informacion del modal en sesion", e);
            }
        }
    }
}
