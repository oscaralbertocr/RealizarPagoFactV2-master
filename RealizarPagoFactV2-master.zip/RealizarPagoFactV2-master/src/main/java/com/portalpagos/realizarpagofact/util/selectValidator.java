package com.portalpagos.realizarpagofact.util;

import java.util.ResourceBundle;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.validator.FacesValidator;
import javax.faces.validator.Validator;
import javax.faces.validator.ValidatorException;

import co.com.ath.logger.CustomLogger;

import com.portalpagos.realizarpagofact.portlet.RealizarPagoFactV2Portlet;

/**
 * HU163
 * Clase que realiza la validaci�n de las referencias, que sean numericas, o si no es obligatoria que acepte vacios
 **/

@FacesValidator(value = "selectValidator")
public class selectValidator implements Validator {	
	
	private CustomLogger logger= new CustomLogger(RealizarPagoFactV2Portlet.class);
	private static final String CERO = "0";
	@Override
	public void validate(FacesContext context, UIComponent component, Object value)
			throws ValidatorException {

		String valorSelect = (String) value;
		if(CERO.equals(valorSelect)){
			ResourceBundle rbNl = ResourceBundle.getBundle("com.portalpagos.realizarpagofact.portlet.nl.RealizarPagoFactV2PortletResource");

			String mensaje = rbNl.getString("msg.campoObligatorio");
			FacesMessage msg = new FacesMessage(mensaje);
			msg.setSeverity(FacesMessage.SEVERITY_ERROR);
			throw new ValidatorException(msg);
		}
	}


}
