package com.portalpagos.realizarpagofact.util;

import java.util.ResourceBundle;

/**
 * HU21
 * Clase que realiza la validaci�n de la coincidencia de los valores ingresados en los campos Referencia de Pago y Confirmar 
 * Referencia de Pago en el form de Captura de Referencia de Facturadores
 * @author: M�lany Rozo
	 * @Since: 24/02/15
 **/

public class ReferenciaValidator {
	/**
	 * Funci�n que obtiene los valores de los campos Referencia de Pago y Confirmar Referencia de Pago para validar su 
	 * coincidencia. Si no coinciden, crea un FacesMessage para mostrar en la vista
	 * @author: M�lany Rozo
	 * @Since: 24/02/15
	 **/
	public static String validate(String valorReferencia, String valorConfirmacion) {
			ResourceBundle rb = ResourceBundle.getBundle("com.portalpagos.realizarpagofact.portlet.nl.RealizarPagoFactV2PortletResource");
			String mensaje = "";
			if(!valorConfirmacion.equals("") && valorConfirmacion!=null){ //si es campo de confirmaci�n no est� vac�o
				if(!valorConfirmacion.equals(valorReferencia)){ // si la confirmaci�n de la referencia no coincide
					mensaje = rb.getString("error.confirmReferencia");
				}
			} else {
				mensaje = rb.getString("msg.campoObligatorio");
			}
			return mensaje;
	}

}
