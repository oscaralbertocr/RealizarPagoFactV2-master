package com.portalpagos.realizarpagofact.beans;

import java.io.Serializable;
import java.lang.reflect.Type;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import java.util.ResourceBundle;

import javax.naming.NamingException;
import javax.portlet.ActionRequest;
import javax.portlet.PortletRequest;
import javax.portlet.PortletSession;
import javax.portlet.RenderRequest;

import co.com.ath.clientes.payments.mc.service.util.ConfigurationService;
import co.com.ath.logger.CustomLogger;
import co.com.ath.mc.utilities.service.ConfigurationEndpointRestService;
import co.com.ath.mc.utilities.util.ManejadorTexto;
import co.com.ath.payments.mc.auditor.publisher.traza.TrazaPublisher;
import co.com.ath.payments.mc.auditor.publisher.util.PublisherUtil;
import co.com.ath.payments.mc.auditor.publisher.util.WebServiceClientHTTPS;
import co.com.ath.payments.mc.cache.manager.CacheManager;
import co.com.ath.payments.mc.service.model.AuditorRq;
import co.com.ath.payments.mc.service.model.ErrorData;
import co.com.ath.payments.mc.service.model.GetIntencionesPagoRs;
import co.com.ath.payments.mc.service.model.GetTiposDocumentoRs;
import co.com.ath.payments.mc.service.model.IntencionPagoType;
import co.com.ath.payments.mc.service.model.TipoDocumentoType;
import co.com.ath.payments.mc.service.model.json.BankInfoType;
import co.com.ath.payments.mc.service.model.json.ConfigAgreementType;
import co.com.ath.payments.mc.service.model.json.CustomInvoiceField;
import co.com.ath.payments.mc.service.model.json.GetConvenioInfoRq;
import co.com.ath.payments.mc.service.model.json.GetConvenioInfoRs;
import co.com.ath.payments.mc.service.model.json.GetCustomInvoiceRq;
import co.com.ath.payments.mc.service.model.json.GetCustomInvoiceRs;
import co.com.ath.payments.mc.service.model.json.GetTopesValorConvenioRq;
import co.com.ath.payments.mc.service.model.json.GetTopesValorConvenioRs;
import co.com.ath.payments.mc.service.model.json.GetTransactionForReferenceRq;
import co.com.ath.payments.mc.service.model.json.GetTransactionForReferenceRs;
import co.com.ath.payments.mc.service.model.json.MedioPagoType;
import co.com.ath.payments.mc.service.model.json.ObtenerConfiguracionTaquillaRq;
import co.com.ath.payments.mc.service.model.json.ObtenerConfiguracionTaquillaRs;
import co.com.ath.payments.mc.service.model.json.PayCentralBillRequest;
import co.com.ath.payments.mc.service.model.json.PayCentrallBillResponse;
import co.com.ath.payments.mc.service.model.json.ReferenceAgreementType;
import co.com.ath.payments.mc.service.model.json.ReferenceType;
import co.com.ath.payments.mc.service.model.json.TopeMedioPagoType;

import com.ath.portalpagos.util.ExceptionManager;
import com.ath.portalpagos.util.IpNodoPortal;
import com.ath.portalpagos.util.JSONUtil;
import com.ath.portalpagos.util.Modal;
import com.co.pragma.portal.utils.WCMCliente;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.ibm.workplace.wcm.api.ImageComponent;
import com.ibm.workplace.wcm.api.exceptions.WCMException;
import com.portalpagos.realizarpagofact.beans.RutaContenidoBean;
import com.portalpagos.realizarpagofact.portlet.RealizarPagoFactV2Portlet;
import com.portalpagos.realizarpagofact.util.CommonUtils;
import com.portalpagos.realizarpagofact.util.ErrorManager;
//import co.com.ath.payments.mc.auditor.publisher.util.WebServiceClientHTTPS;

/**
 * HU18, HU19, HU20 ManagedBean utilizado para almacenar los datos del pago necesarios para los forms de Captura de Referencia de Pago y
 * Confirmaci�n de Pago del flujo de Facturadores
 * 
 * @author: M�lany Rozo
 * @Since: 16/12/14
 **/

public class DatosPagoFactBean implements Serializable {

    private static final long serialVersionUID = 1L;

    private static final String RS = "RS";

    private static final String RQ = "RQ";

    private static final Boolean TRUE = true;

    private CustomLogger logger = new CustomLogger(RealizarPagoFactV2Portlet.class);
    Gson gson = new GsonBuilder().setPrettyPrinting().create();
    private static String user;
    private static String ip;
    private static String rquid;

    private String idConvenio;

    private String nombreConvenio;

    private String urlImagen;

    private String textoAyuda;

    private String placeholderComentarios;

    private String referenciaPago;

    private String confirmReferencia;

    private String valorTotal;

    private String valorPago;

    private boolean permiteParcial;

    private String valorPagoParcial;

    private String comentarios;

    private String tipoPago;

    private Date fechaPagoOportuno;

    private Date fechaLimitePago;

    private Date fechaVencimientoPago;

    private String cuerpoLighbox;

    private String mostrarModal;

    private String tituloModal;

    private String tipoModal;

    private String anchoModal;

    private String altoModal;
    
    private RenderRequest request;

    private boolean mostrarTerminosCondiciones;

    private boolean aceptaTerminos;

    private boolean banderaMsgValorCero;

    private static final String DOSPUNTOS = ":";

    private static final String NODO_INTREGRA = "Nodo WebLogic";

    private static final String COD_CONVENIO = "Código Convenio";

    private static final String NODO = "Nodo Portal";

    private static final String PRIMERA_REFERENCIA = "Primera referencia adicional";

    private static final String SEGUNDA_REFERENCIA = "Segunda referencia adicional";

    private static final String TERCERA_REFERENCIA = "Tercera referencia adicional";

    private static final String ESTADO = "Tipo Respuesta";

    private static final String VACIO = "";

    private static final String NUMERICO = "numerico";

    private String tooltipReferencia;

    private String maxLengthReferencia;

    private Boolean obligatoriedadReferencia;

    private String labelPrimeraReferenciaAdicional;

    private String tooltipPrimeraReferenciaAdicional;

    private String referenciaPrimeraAdicional;

    private String maxLengthPrimeraReferenciaAdicional;

    private Boolean isObligatorioPrimeraReferenciaAdicional;

    private String obligatorioPrimeraReferenciaAdicional;

    private String labelSegundaReferenciaAdicional;

    private String tooltipSegundaReferenciaAdicional;

    private String referenciaSegundaAdicional;

    private String maxLengthSegundaReferenciaAdicional;

    private Boolean isObligatorioSegundaReferenciaAdicional;

    private String obligatorioSegundaReferenciaAdicional;

    private String labelTerceraReferenciaAdicional;

    private String tooltipTerceraReferenciaAdicional;

    private String referenciaTerceraAdicional;

    private String maxLengthTerceraReferenciaAdicional;

    private Boolean isObligatorioTerceraReferenciaAdicional;

    private String obligatorioTerceraReferenciaAdicional;

    private String labelTipoDocumento;

    private String tipoDocumento;

    private String seleccionaOpt;

    private List<TipoDocumentoType> listaTiposDocumento;

    private String labelNumeroDocumento;

    private String numeroDocumento;

    private String labelIntencionPago;

    private String intencionPago;

    private List<IntencionPagoType> listaIntencionesPago;

    private Boolean isRequierePrimeraReferencia;

    private Boolean isRequiereSegundaReferencia;

    private Boolean isRequiereTerceraReferencia;

    private Boolean isRequiereDocumento;

    private Boolean isRequiereIntencionPago;

    private String duenoId;

    private String descripcionIntencionPago;

    private String descripcionTipoDocumento;

    private String trm;

    private String isRedireccion;

    private String formato;

    private String isCPV;

    private String imagen;

    private String modalidad;

    private Boolean isPermiteInscribir;

    private String mensajeAyudaPagoAgil;
    
    private boolean isMisFinanzas;

    /* HU 21.7 Multiples referencias */
    private Boolean isPermiteMultiplesRef;
    private List<ReferenceAgreementType> referenciasAdicionalesList;
    private List<ReferenceType> valoresReferenciaAdicionalList;
    private String valoresReferenciaAdicionalStringJson;

    // Este atributo es solo para web responsive
    private String nombrePasoUnoMovil;
    // Este atributo es solo para web responsive
    private String nombrepasoDosMovil;

    /* HU 21.5.4 INI GD 13/12/2016 SPRINT 1_2017 */
    private Double valorCostoTransaccion;
    private String stLabelCostoTransaccion;
    private String txtCostoTransaccion;
    /* FIN GD 13/12/2016 SPRINT 1_2017 */

    /* HU 220 Enviar etiquetas en el addTransaction */
    private String urlImgConvAddTran;
    private String temaConv;

    // HU 231 Validacion de topes
    private List<TopeMedioPagoType> topesPorValor;

    /* Incidencia ventanilla in-habilitada */
    private String validacionEstadoVentanilla;

    // HU 60.1.6.2 mostrar tooltip cuando viene de convenios frecuentes
    private boolean mostrarTooltipValorPAgo;

    // HU21.8 tooltips campos
    private String tooltipTipoDoc;
    private String tooltipNumDoc;
    private String tooltipIntenPago;
    private String tooltipConfRef;
    private String labelConfirmacion;
    
    // RQ 29184 Cargue de archivo personalizado - Requerimiento funcional 3 Ajuste pantalla de confirmación de pago
    private int convenioTipoCargueId;
    private List<CustomInvoiceField> camposFacturaPersonzalizada;
    
    // IM77375 validar valor pago con valor factura
    private boolean validTope;
    
    /*Validacion topes para todos los medios de pago*/
    List<MedioPagoType> mediosPago;
    /*Valida se optiene el porcentaje*/
    
    private int porcentajeTope;
    
    
	public String getLabelConfirmacion() {
        return labelConfirmacion;
    }

    public void setLabelConfirmacion(String labelConfirmacion) {
        this.labelConfirmacion = labelConfirmacion;
    }

    public String getTooltipConfRef() {
        return tooltipConfRef;
    }

    public void setTooltipConfRef(String tooltipConfRef) {
        this.tooltipConfRef = tooltipConfRef;
    }

    public boolean isMostrarTooltipValorPAgo() {
        return mostrarTooltipValorPAgo;
    }

    public void setMostrarTooltipValorPAgo(boolean mostrarTooltipValorPAgo) {
        this.mostrarTooltipValorPAgo = mostrarTooltipValorPAgo;
    }

    public String getNombrePasoUnoMovil() {
        return nombrePasoUnoMovil;
    }

    public Double getValorCostoTransaccion() {
        return valorCostoTransaccion;
    }

    public void setValorCostoTransaccion(Double valorCostoTransaccion) {
        this.valorCostoTransaccion = valorCostoTransaccion;
    }

    public String getStLabelCostoTransaccion() {
        return stLabelCostoTransaccion;
    }

    public void setStLabelCostoTransaccion(String stLabelCostoTransaccion) {
        this.stLabelCostoTransaccion = stLabelCostoTransaccion;
    }

    public String getTxtCostoTransaccion() {
        return txtCostoTransaccion;
    }

    public String getValoresReferenciaAdicionalStringJson() {
        return valoresReferenciaAdicionalStringJson;
    }

    public void setValoresReferenciaAdicionalStringJson(String valoresReferenciaAdicionalStringJson) {
        this.valoresReferenciaAdicionalStringJson = valoresReferenciaAdicionalStringJson;
    }

    public void setTxtCostoTransaccion(String txtCostoTransaccion) {
        this.txtCostoTransaccion = txtCostoTransaccion;
    }

    public void setNombrePasoUnoMovil(String nombrePasoUnoMovil) {
        this.nombrePasoUnoMovil = nombrePasoUnoMovil;
    }

    public String getNombrepasoDosMovil() {
        return nombrepasoDosMovil;
    }

    public void setNombrepasoDosMovil(String nombrepasoDosMovil) {
        this.nombrepasoDosMovil = nombrepasoDosMovil;
    }

    public String getMensajeAyudaPagoAgil() {
        return mensajeAyudaPagoAgil;
    }

    public void setMensajeAyudaPagoAgil(String mensajeAyudaPagoAgil) {
        this.mensajeAyudaPagoAgil = mensajeAyudaPagoAgil;
    }

    public String getModalidad() {
        return modalidad;
    }

    public void setModalidad(String modalidad) {
        this.modalidad = modalidad;
    }

    public Boolean getIsPermiteInscribir() {
        return isPermiteInscribir;
    }

    public void setIsPermiteInscribir(Boolean isPermiteInscribir) {
        this.isPermiteInscribir = isPermiteInscribir;
    }

    public String getFormato() {
        return formato;
    }

    public void setFormato(String formato) {
        this.formato = formato;
    }

    public String getIsCPV() {
        return isCPV;
    }

    public void setIsCPV(String isCPV) {
        this.isCPV = isCPV;
    }

    public String getTrm() {
        return trm;
    }

    public void setTrm(String trm) {
        this.trm = trm;
    }

    public String getDescripcionIntencionPago() {
        return descripcionIntencionPago;
    }

    public void setDescripcionIntencionPago(String descripcionIntencionPago) {
        this.descripcionIntencionPago = descripcionIntencionPago;
    }

    public String getDescripcionTipoDocumento() {
        return descripcionTipoDocumento;
    }

    public void setDescripcionTipoDocumento(String descripcionTipoDocumento) {
        this.descripcionTipoDocumento = descripcionTipoDocumento;
    }

    public String getObligatorioPrimeraReferenciaAdicional() {
        return obligatorioPrimeraReferenciaAdicional;
    }

    public void setObligatorioPrimeraReferenciaAdicional(String obligatorioPrimeraReferenciaAdicional) {
        this.obligatorioPrimeraReferenciaAdicional = obligatorioPrimeraReferenciaAdicional;
    }

    public String getObligatorioSegundaReferenciaAdicional() {
        return obligatorioSegundaReferenciaAdicional;
    }

    public void setObligatorioSegundaReferenciaAdicional(String obligatorioSegundaReferenciaAdicional) {
        this.obligatorioSegundaReferenciaAdicional = obligatorioSegundaReferenciaAdicional;
    }

    public String getObligatorioTerceraReferenciaAdicional() {
        return obligatorioTerceraReferenciaAdicional;
    }

    public void setObligatorioTerceraReferenciaAdicional(String obligatorioTerceraReferenciaAdicional) {
        this.obligatorioTerceraReferenciaAdicional = obligatorioTerceraReferenciaAdicional;
    }

    public String getDuenoId() {
        return duenoId;
    }

    public void setDuenoId(String duenoId) {
        this.duenoId = duenoId;
    }

    public String getTooltipReferencia() {
        return tooltipReferencia;
    }

    public void setTooltipReferencia(String tooltipReferencia) {
        this.tooltipReferencia = tooltipReferencia;
    }

    public String getMaxLengthReferencia() {
        return maxLengthReferencia;
    }

    public void setMaxLengthReferencia(String maxLengthReferencia) {
        this.maxLengthReferencia = maxLengthReferencia;
    }

    public Boolean getObligatoriedadReferencia() {
        return obligatoriedadReferencia;
    }

    public void setObligatoriedadReferencia(Boolean obligatoriedadReferencia) {
        this.obligatoriedadReferencia = obligatoriedadReferencia;
    }

    public String getLabelPrimeraReferenciaAdicional() {
        return labelPrimeraReferenciaAdicional;
    }

    public void setLabelPrimeraReferenciaAdicional(String labelPrimeraReferenciaAdicional) {
        this.labelPrimeraReferenciaAdicional = labelPrimeraReferenciaAdicional;
    }

    public String getTooltipPrimeraReferenciaAdicional() {
        return tooltipPrimeraReferenciaAdicional;
    }

    public void setTooltipPrimeraReferenciaAdicional(String tooltipPrimeraReferenciaAdicional) {
        this.tooltipPrimeraReferenciaAdicional = tooltipPrimeraReferenciaAdicional;
    }

    public String getReferenciaPrimeraAdicional() {
        return referenciaPrimeraAdicional;
    }

    public void setReferenciaPrimeraAdicional(String referenciaPrimeraAdicional) {
        this.referenciaPrimeraAdicional = referenciaPrimeraAdicional;
    }

    public String getMaxLengthPrimeraReferenciaAdicional() {
        return maxLengthPrimeraReferenciaAdicional;
    }

    public void setMaxLengthPrimeraReferenciaAdicional(String maxLengthPrimeraReferenciaAdicional) {
        this.maxLengthPrimeraReferenciaAdicional = maxLengthPrimeraReferenciaAdicional;
    }

    public Boolean getIsObligatorioPrimeraReferenciaAdicional() {
        return isObligatorioPrimeraReferenciaAdicional;
    }

    public void setIsObligatorioPrimeraReferenciaAdicional(Boolean isObligatorioPrimeraReferenciaAdicional) {
        this.isObligatorioPrimeraReferenciaAdicional = isObligatorioPrimeraReferenciaAdicional;
    }

    public String getLabelSegundaReferenciaAdicional() {
        return labelSegundaReferenciaAdicional;
    }

    public void setLabelSegundaReferenciaAdicional(String labelSegundaReferenciaAdicional) {
        this.labelSegundaReferenciaAdicional = labelSegundaReferenciaAdicional;
    }

    public String getTooltipSegundaReferenciaAdicional() {
        return tooltipSegundaReferenciaAdicional;
    }

    public void setTooltipSegundaReferenciaAdicional(String tooltipSegundaReferenciaAdicional) {
        this.tooltipSegundaReferenciaAdicional = tooltipSegundaReferenciaAdicional;
    }

    public String getReferenciaSegundaAdicional() {
        return referenciaSegundaAdicional;
    }

    public void setReferenciaSegundaAdicional(String referenciaSegundaAdicional) {
        this.referenciaSegundaAdicional = referenciaSegundaAdicional;
    }

    public String getMaxLengthSegundaReferenciaAdicional() {
        return maxLengthSegundaReferenciaAdicional;
    }

    public void setMaxLengthSegundaReferenciaAdicional(String maxLengthSegundaReferenciaAdicional) {
        this.maxLengthSegundaReferenciaAdicional = maxLengthSegundaReferenciaAdicional;
    }

    public Boolean getIsObligatorioSegundaReferenciaAdicional() {
        return isObligatorioSegundaReferenciaAdicional;
    }

    public void setIsObligatorioSegundaReferenciaAdicional(Boolean isObligatorioSegundaReferenciaAdicional) {
        this.isObligatorioSegundaReferenciaAdicional = isObligatorioSegundaReferenciaAdicional;
    }

    public String getLabelTerceraReferenciaAdicional() {
        return labelTerceraReferenciaAdicional;
    }

    public void setLabelTerceraReferenciaAdicional(String labelTerceraReferenciaAdicional) {
        this.labelTerceraReferenciaAdicional = labelTerceraReferenciaAdicional;
    }

    public String getTooltipTerceraReferenciaAdicional() {
        return tooltipTerceraReferenciaAdicional;
    }

    public void setTooltipTerceraReferenciaAdicional(String tooltipTerceraReferenciaAdicional) {
        this.tooltipTerceraReferenciaAdicional = tooltipTerceraReferenciaAdicional;
    }

    public String getReferenciaTerceraAdicional() {
        return referenciaTerceraAdicional;
    }

    public void setReferenciaTerceraAdicional(String referenciaTerceraAdicional) {
        this.referenciaTerceraAdicional = referenciaTerceraAdicional;
    }

    public String getMaxLengthTerceraReferenciaAdicional() {
        return maxLengthTerceraReferenciaAdicional;
    }

    public void setMaxLengthTerceraReferenciaAdicional(String maxLengthTerceraReferenciaAdicional) {
        this.maxLengthTerceraReferenciaAdicional = maxLengthTerceraReferenciaAdicional;
    }

    public Boolean getIsObligatorioTerceraReferenciaAdicional() {
        return isObligatorioTerceraReferenciaAdicional;
    }

    public void setIsObligatorioTerceraReferenciaAdicional(Boolean isObligatorioTerceraReferenciaAdicional) {
        this.isObligatorioTerceraReferenciaAdicional = isObligatorioTerceraReferenciaAdicional;
    }

    public String getLabelTipoDocumento() {
        return labelTipoDocumento;
    }

    public void setLabelTipoDocumento(String labelTipoDocumento) {
        this.labelTipoDocumento = labelTipoDocumento;
    }

    public String getTipoDocumento() {
        return tipoDocumento;
    }

    public void setTipoDocumento(String tipoDocumento) {
        if (this.getListaTiposDocumento() != null) {
            List<TipoDocumentoType> listIterator = this.getListaTiposDocumento();
            for (TipoDocumentoType iterador : listIterator) {
                if (tipoDocumento.equals(iterador.getId())) {
                    this.descripcionTipoDocumento = iterador.getDescripcion();
                }
            }
        }
        this.tipoDocumento = tipoDocumento;
    }

    public String getSeleccionaOpt() {
        return seleccionaOpt;
    }

    public void setSeleccionaOpt(String seleccionaOpt) {
        this.seleccionaOpt = seleccionaOpt;
    }

    public List<TipoDocumentoType> getListaTiposDocumento() {
        return listaTiposDocumento;
    }

    public void setListaTiposDocumento(List<TipoDocumentoType> listaTiposDocumento) {
        this.listaTiposDocumento = listaTiposDocumento;
    }

    public String getLabelNumeroDocumento() {
        return labelNumeroDocumento;
    }

    public void setLabelNumeroDocumento(String labelNumeroDocumento) {
        this.labelNumeroDocumento = labelNumeroDocumento;
    }

    public String getNumeroDocumento() {
        return numeroDocumento;
    }

    public void setNumeroDocumento(String numeroDocumento) {
        this.numeroDocumento = numeroDocumento;
    }

    public String getLabelIntencionPago() {
        return labelIntencionPago;
    }

    public void setLabelIntencionPago(String labelIntencionPago) {
        this.labelIntencionPago = labelIntencionPago;
    }

    public String getIntencionPago() {
        return intencionPago;
    }

    public void setIntencionPago(String intencionPago) {
        if (this.getListaIntencionesPago() != null) {
            List<IntencionPagoType> listIterator = this.getListaIntencionesPago();
            for (IntencionPagoType iterador : listIterator) {
                if (intencionPago.equals(iterador.getId())) {
                    this.descripcionIntencionPago = iterador.getDescripcion();
                }
            }
        }
        this.intencionPago = intencionPago;
    }

    public List<IntencionPagoType> getListaIntencionesPago() {
        return listaIntencionesPago;
    }

    public void setListaIntencionesPago(List<IntencionPagoType> listaIntencionesPago) {
        this.listaIntencionesPago = listaIntencionesPago;
    }

    public Boolean getIsRequierePrimeraReferencia() {
        return isRequierePrimeraReferencia;
    }

    public void setIsRequierePrimeraReferencia(Boolean isRequierePrimeraReferencia) {
        this.isRequierePrimeraReferencia = isRequierePrimeraReferencia;
    }

    public Boolean getIsRequiereSegundaReferencia() {
        return isRequiereSegundaReferencia;
    }

    public void setIsRequiereSegundaReferencia(Boolean isRequiereSegundaReferencia) {
        this.isRequiereSegundaReferencia = isRequiereSegundaReferencia;
    }

    public Boolean getIsRequiereTerceraReferencia() {
        return isRequiereTerceraReferencia;
    }

    public void setIsRequiereTerceraReferencia(Boolean isRequiereTerceraReferencia) {
        this.isRequiereTerceraReferencia = isRequiereTerceraReferencia;
    }

    public Boolean getIsRequiereDocumento() {
        return isRequiereDocumento;
    }

    public void setIsRequiereDocumento(Boolean isRequiereDocumento) {
        this.isRequiereDocumento = isRequiereDocumento;
    }

    public Boolean getIsRequiereIntencionPago() {
        return isRequiereIntencionPago;
    }

    public void setIsRequiereIntencionPago(Boolean isRequiereIntencionPago) {
        this.isRequiereIntencionPago = isRequiereIntencionPago;
    }

    public boolean isBanderaMsgValorCero() {
        return banderaMsgValorCero;
    }

    public void setBanderaMsgValorCero(boolean banderaMsgValorCero) {
        this.banderaMsgValorCero = banderaMsgValorCero;
    }

    public String getConfirmReferencia() {
        return confirmReferencia;
    }

    public void setConfirmReferencia(String confirmReferencia) {
        this.confirmReferencia = confirmReferencia;
    }

    public String getMostrarModal() {
        return mostrarModal;
    }

    public void setMostrarModal(String mostrarModal) {
        this.mostrarModal = mostrarModal;
    }

    public String getTituloModal() {
        return tituloModal;
    }

    public void setTituloModal(String tituloModal) {
        this.tituloModal = tituloModal;
    }

    public String getTipoModal() {
        return tipoModal;
    }

    public void setTipoModal(String tipoModal) {
        this.tipoModal = tipoModal;
    }

    public String getAnchoModal() {
        return anchoModal;
    }

    public void setAnchoModal(String anchoModal) {
        this.anchoModal = anchoModal;
    }

    public String getAltoModal() {
        return altoModal;
    }

    public void setAltoModal(String altoModal) {
        this.altoModal = altoModal;
    }

    public String getPlaceholderComentarios() {
        if (placeholderComentarios == null || placeholderComentarios.length() == 0)
            return placeholderComentarios;

        placeholderComentarios = placeholderComentarios.toLowerCase();
        char[] caracteres = placeholderComentarios.toCharArray();
        caracteres[0] = Character.toUpperCase(caracteres[0]);

        return new String(caracteres);
    }

    public void setPlaceholderComentarios(String placeholderComentarios) {
        this.placeholderComentarios = placeholderComentarios;
    }

    public String getCuerpoLighbox() {
        return cuerpoLighbox;
    }

    public void setCuerpoLighbox(String cuerpoLighbox) {
        this.cuerpoLighbox = cuerpoLighbox;
    }

    public DatosPagoFactBean() {

    }

    public String getIdConvenio() {
        return idConvenio;
    }

    public void setIdConvenio(String idConvenio) {
        this.idConvenio = idConvenio;
    }

    public String getNombreConvenio() {
        if (nombreConvenio == null || nombreConvenio.isEmpty())
            return nombreConvenio;
        return nombreConvenio;
    }

    public void setNombreConvenio(String nombreConvenio) {
        this.nombreConvenio = nombreConvenio;
    }

    public String getReferenciaPago() {
        return referenciaPago;
    }

    public void setReferenciaPago(String referenciaPago) {
        this.referenciaPago = referenciaPago;
    }

    public String getTextoAyuda() {
        if (textoAyuda == null || textoAyuda.length() == 0)
            return textoAyuda;

        textoAyuda = textoAyuda.toLowerCase();
        char[] caracteres = textoAyuda.toCharArray();
        caracteres[0] = Character.toUpperCase(caracteres[0]);

        return new String(caracteres);
    }

    public void setTextoAyuda(String textoAyuda) {
        this.textoAyuda = textoAyuda;
    }

    public String getValorPago() {
        return valorPago;
    }

    public void setValorPago(String valorPago) {
        this.valorPago = valorPago;
    }

    public String getComentarios() {
        return comentarios;
    }

    public boolean isPermiteParcial() {
        return permiteParcial;
    }

    public void setPermiteParcial(boolean permiteParcial) {
        this.permiteParcial = permiteParcial;
    }

    public String getValorPagoParcial() {
        return valorPagoParcial;
    }

    public void setValorPagoParcial(String valorPagoParcial) {
        this.valorPagoParcial = valorPagoParcial;
    }

    public void setComentarios(String comentarios) {
        this.comentarios = comentarios;
    }

    public String getUrlImagen() {
        return urlImagen;
    }

    public void setUrlImagen(String urlImagen) {
        this.urlImagen = urlImagen;
    }

    public String getTipoPago() {
        return tipoPago;
    }

    public void setTipoPago(String tipoPago) {
        this.tipoPago = tipoPago;
    }

    public Date getFechaPagoOportuno() {
        return fechaPagoOportuno;
    }

    public void setFechaPagoOportuno(Date fechaPagoOportuno) {
        this.fechaPagoOportuno = fechaPagoOportuno;
    }

    public Date getFechaLimitePago() {
        return fechaLimitePago;
    }

    public void setFechaLimitePago(Date fechaLimitePago) {
        this.fechaLimitePago = fechaLimitePago;
    }

    public Date getFechaVencimientoPago() {
        return fechaVencimientoPago;
    }

    public void setFechaVencimientoPago(Date fechaVencimientoPago) {
        this.fechaVencimientoPago = fechaVencimientoPago;
    }

    public String getValorTotal() {
        return valorTotal;
    }

    public void setValorTotal(String valorTotal) {
        this.valorTotal = valorTotal;
    }

    public boolean isMostrarTerminosCondiciones() {
        return mostrarTerminosCondiciones;
    }

    public void setMostrarTerminosCondiciones(boolean mostrarTerminosCondiciones) {
        this.mostrarTerminosCondiciones = mostrarTerminosCondiciones;
    }

    public boolean isAceptaTerminos() {
        return aceptaTerminos;
    }

    public void setAceptaTerminos(boolean aceptaTerminos) {
        this.aceptaTerminos = aceptaTerminos;
    }

    public String getIsRedireccion() {
        return isRedireccion;
    }

    public void setIsRedireccion(String isRedireccion) {
        this.isRedireccion = isRedireccion;
    }

    public String getImagen() {
        return imagen;
    }

    public void setImagen(String imagen) {
        this.imagen = imagen;
    }

    public List<ReferenceAgreementType> getReferenciasAdicionalesList() {
        return referenciasAdicionalesList;
    }

    public void setReferenciasAdicionalesList(List<ReferenceAgreementType> list) {
        this.referenciasAdicionalesList = list;
    }

    public Boolean getIsPermiteMultiplesRef() {
        return isPermiteMultiplesRef;
    }

    public void setIsPermiteMultiplesRef(Boolean isPermiteMultiplesRef) {
        this.isPermiteMultiplesRef = isPermiteMultiplesRef;
    }

    public List<ReferenceType> getValoresReferenciaAdicionalList() {
        return valoresReferenciaAdicionalList;
    }

    public void setValoresReferenciaAdicionalList(List<ReferenceType> listaReferencia) {
        this.valoresReferenciaAdicionalList = listaReferencia;
    }

    public String getTooltipTipoDoc() {
        return tooltipTipoDoc;
    }

    public void setTooltipTipoDoc(String tooltipTipoDoc) {
        this.tooltipTipoDoc = tooltipTipoDoc;
    }

    public String getTooltipNumDoc() {
        return tooltipNumDoc;
    }

    public void setTooltipNumDoc(String tooltipNumDoc) {
        this.tooltipNumDoc = tooltipNumDoc;
    }

    public String getTooltipIntenPago() {
        return tooltipIntenPago;
    }

    public void setTooltipIntenPago(String tooltipIntenPago) {
        this.tooltipIntenPago = tooltipIntenPago;
    }
    
    public boolean getIsMisFinanzas() {
        return isMisFinanzas;
    }

    public void setIsMisFinanzas(boolean isMisFinanzas) {
        this.isMisFinanzas = isMisFinanzas;
    }

    public int getConvenioTipoCargueId() {
        return convenioTipoCargueId;
    }

    public void setConvenioTipoCargueId(int convenioTipoCargueId) {
        this.convenioTipoCargueId = convenioTipoCargueId;
    }

    public List<CustomInvoiceField> getCamposFacturaPersonzalizada() {
		return camposFacturaPersonzalizada;
	}

	public void setCamposFacturaPersonzalizada(List<CustomInvoiceField> camposFacturaPersonzalizada) {
		this.camposFacturaPersonzalizada = camposFacturaPersonzalizada;
	}
	
    public String getUrlImgConvAddTran() {
        return urlImgConvAddTran;
    }

    public void setUrlImgConvAddTran(String urlImgConvAddTran) {
        this.urlImgConvAddTran = urlImgConvAddTran;
    }

    public String getTemaConv() {
        return temaConv;
    }

    public void setTemaConv(String temaConv) {
        this.temaConv = temaConv;
    }

    public List<TopeMedioPagoType> getTopesPorValor() {
        return topesPorValor;
    }

    public void setTopesPorValor(List<TopeMedioPagoType> topesPorValor) {
        this.topesPorValor = topesPorValor;
    }

    public String getValidacionEstadoVentanilla() {
        return validacionEstadoVentanilla;
    }

    public void setValidacionEstadoVentanilla(String validacionEstadoVentanilla) {
        this.validacionEstadoVentanilla = validacionEstadoVentanilla;
    }

    public List<MedioPagoType> getMediosPago() {
        return mediosPago;
    }

    public void setMediosPago(List<MedioPagoType> mediosPago) {
        this.mediosPago = mediosPago;
    }

	public boolean isValidTope() {
		return validTope;
	}

	public void setValidTope(boolean validTope) {
		this.validTope = validTope;
	}

	  /**
		 * HU APC-882 Quiero que me permita realizar pago del convenio Banco de Occidente Recaudo Cartera Vehiculos NURA 00009506 que no supere tres veces dicho valor
		 * **/
	    public int getPorcentajeTope() {
			return porcentajeTope;
		}

		public void setPorcentajeTope(int porcentajeTope) {
			this.porcentajeTope = porcentajeTope;
		}

	
	
	/***
     * HU18 Funci�n que consulta en el middleware de comunicaciones la informaci�n del convenio dado un Id Asigna los datos consultados a
     * los atributos del ManagedBean
     * 
     * @param url
     *            - url donde se encuentran almacenadas las imagenes de ayuda para los convenios
     * @exception Captura
     *                las excepciones cuando se realiza la instancia de la clase ConvenioInfoRequest del Middleware de Comunicaciones
     * @since 16/12/14
     * @author: M�lany Rozo
     */
    public void cargarDatos(String url, RenderRequest request, String referencia) {
    	logger.info("CargueArchivoPersonalizado INICIO");
    	logger.info("Cargando datos");

        PortletSession session = request.getPortletSession();
        RutaContenidoBean rContenido = (RutaContenidoBean) session.getAttribute("RutaContenidoBean", PortletSession.APPLICATION_SCOPE);
        ResourceBundle rbPortlet = ResourceBundle
                .getBundle("com.portalpagos.realizarpagofact.portlet.nl.RealizarPagoFactV2PortletResource");
        ResourceBundle rb = ResourceBundle.getBundle("com.portalpagos.realizarpagofact.properties.RealizarPagoFactPortletResource");
        GetConvenioInfoRq requestInfo = null;
        GetConvenioInfoRs response = null;
        String errorCode = "";
        rquid = (String) session.getAttribute("rquid", PortletSession.APPLICATION_SCOPE);
        try {
            user = (String) session.getAttribute("user", PortletSession.APPLICATION_SCOPE);
            ip = (String) session.getAttribute("ip", PortletSession.APPLICATION_SCOPE);
            this.isRedireccion = "false";
            this.mostrarModal = "false";
            this.seleccionaOpt = rbPortlet.getString("stSeleccionaOpcion");

            GetConvenioInfoRq requestConvenioInfo = new GetConvenioInfoRq();
            requestConvenioInfo.setAgreementId(idConvenio);
            requestConvenioInfo.setRequiereActivo(true);

            logger.info("[REQUEST - getConvenioInfo] DATA: " + new Gson().toJson(requestConvenioInfo));

            response = CacheManager.getInstance().getConvenioInfo(requestConvenioInfo);
            
            this.request=request;

            logger.info("[RESPONSE - getConvenioInfo] DATA: " + gson.toJson(response));

            if (null != response && "SUCCESS".equals(response.getStatus().getStatusCode())) {
                String desc = response.getStatus().getStatusDesc();
                /*
                 * john.ramirez -- 14/02/2017-- Se realiza la validacion del estado del convenio para no cargar la informacion del convenio
                 * cuando el estado sea inactivo eliminado
                 */
                if ((desc != null && "CONVENIO_NOT_FOUND".equals(response.getStatus().getStatusDesc())) || null == response.getEstado()
                        || !response.getEstado().equals("1") || !"1".equals(response.getModeAgreement())) {
                        
                    logger.info("Redireccionando al home...");
                	this.isRedireccion = "true";
                } else {

                	this.duenoId = response.getDuenoId();
                    logger.info("duenoId [cargarDatos]: " + this.duenoId);

                    if (response.getDuenoId().equalsIgnoreCase("1")) {
                        this.formato = rb.getString("pattern.alfaNum");
                        this.isCPV = "cpv";
                    } else {
                        this.formato = rb.getString("pattern.numeros");
                        this.isCPV = "";
                    }

                    this.nombreConvenio = response.getName();
                    this.placeholderComentarios = rbPortlet.getString("placeholder.comentarios");
                    this.setPermiteParcial(response.isPartialPayment());
                    
                    if(response.getMediosPagoList() != null && response.getMediosPagoList().size() > 0) {
						for(MedioPagoType medioPago : response.getMediosPagoList()) {
							if(medioPago.getMpId().equals("2")) {
								MedioPagoType newMedioPago = new MedioPagoType();
								newMedioPago.setMpId("4");
								newMedioPago.setMpMedioPago("TCQR");
								response.getMediosPagoList().add(newMedioPago);
								break;
							}
						}
					}
					
					logger.info("[RESPONSE - getConvenioInfo - Medios pago] DATA: " + gson.toJson(response.getMediosPagoList()));
                    
                    this.setMediosPago(response.getMediosPagoList());
                    
                    this.convenioTipoCargueId = response.getTipoCargueId() != null ? Integer.parseInt(response.getTipoCargueId()) : -1;
                    cargarImagenesMedioPago();
                    String img = response.getImage();
                    if (img != null && !img.isEmpty() && !("No Existe Imagen".equalsIgnoreCase(img))
                            && !("No tiene Imagen".equalsIgnoreCase(img))) {
                        this.urlImagen = url + response.getImage();
                    }

                    // Consulta de la configuración de los convenios para tipo, documento e intención de pago
                    if (response.getConfigAgreementType() != null) {
                        requestInfo = new GetConvenioInfoRq();
                        requestInfo.setAgreementId(idConvenio.toUpperCase());
                        BankInfoType bankInfo = new BankInfoType();
                        bankInfo.setBankId(rContenido.getBankId());
                        bankInfo.setBankName(rContenido.getPortalOrigen());
                        requestInfo.setBankInfo(bankInfo);
                        requestInfo.setIpAddress(ip);
                        requestInfo.setRequestID(rquid);
                        requestInfo.setRequestUser(user);
                        requestInfo.setRequestOriginPortal(rContenido.getPortalOrigen());
                        requestInfo.setRequestPage(rContenido.getPaginaOrigen());
                        requestInfo.setRequestSender(rContenido.getPortalOrigen());
                        requestInfo.setRequestDate(new Date());

                        if (response.getConfigAgreementType().isRequiereDocUsuario()) {

                            GetTiposDocumentoRs rsTiposDocumento = CacheManager.getInstance().obtenerTiposDocumentos();
                            logger.info("[RESPONSE - obtenerTiposDocumentos] DATA: " + gson.toJson(rsTiposDocumento));

                            if (!("SUCCESS".equals(rsTiposDocumento.getStatus().getStatusCode()))) { // Si la respuesta del middleware
                                logger.info("ERROR obteniendo tipo de documento");                                                             // devuelve Error
                                String[] error = ErrorManager.getInstance(request).obtenerErrorWCM(rContenido.getPathErroresTecnicos(),
                                        rsTiposDocumento.getExcepcion().getCodigo());
                                this.mostrarModal(error[0], "icon-error", error[1]);
                            } else {
                                this.listaTiposDocumento = rsTiposDocumento.getTiposIdentificacion();
                                this.isRequiereDocumento = TRUE;
                                this.labelTipoDocumento = rbPortlet.getString("stLabelTipoDocumento");
                                this.labelNumeroDocumento = rbPortlet.getString("stLabelNumDocumento");
                            }

                        }
                        if (response.getConfigAgreementType().isRequiereIntencionPago()) {

                            GetIntencionesPagoRs rsIntencionPago = CacheManager.getInstance().obtenerIntencionesDePago(idConvenio);
                            logger.info("[RESPONSE - obtenerIntencionesDePago] DATA: " + gson.toJson(rsIntencionPago));

                            if (!("SUCCESS".equals(rsIntencionPago.getStatus().getStatusCode()))) { // Si la respuesta del middleware
                                                                                                    // devuelve Error
                                logger.info("consultaListaIntencionPago ID: " + this.idConvenio + ". Response CODE: "
                                        + rsIntencionPago.getStatus().getStatusCode() + ", DESC: "
                                        + rsIntencionPago.getStatus().getStatusDesc());
                                String[] error = ErrorManager.getInstance(request).obtenerErrorWCM(rContenido.getPathErroresTecnicos(),
                                        rsIntencionPago.getExcepcion().getCodigo());
                                this.mostrarModal(error[0], "icon-error", error[1]);
                            } else {
                                this.listaIntencionesPago = rsIntencionPago.getIntencionesPago();
                                this.isRequiereIntencionPago = TRUE;
                                this.labelIntencionPago = rbPortlet.getString("stLabelIntencionPago");
                            }
                        }
                        /* HU 21.5.4 INI GD 09/12/2016 SPRINT 1_2017 */
                        this.valorCostoTransaccion = response.getConfigAgreementType().getCostoTransaccion();
                        double costoTransacc = this.valorCostoTransaccion;
                        DecimalFormat formato = new DecimalFormat("#,###.###", new DecimalFormatSymbols(new Locale("ES")));
                        this.txtCostoTransaccion = formato.format(new Double(costoTransacc));
                        /* FIN GD 09/12/2016 */

                        // HU21.8 mapeo de tooltips, se hace validación si es diferente de null
                        ConfigAgreementType rs = response.getConfigAgreementType();
                        if (null != rs.getConvenioTooltip()) {
                            this.tooltipTipoDoc = null != rs.getConvenioTooltip().getTextoAyudaTipoDoc()
                                    ? rs.getConvenioTooltip().getTextoAyudaTipoDoc()
                                    : VACIO;
                            this.tooltipNumDoc = null != rs.getConvenioTooltip().getTextoAyudaNumDoc()
                                    ? rs.getConvenioTooltip().getTextoAyudaNumDoc()
                                    : VACIO;
                            this.tooltipIntenPago = null != rs.getConvenioTooltip().getTextoAyudaIntensPago()
                                    ? rs.getConvenioTooltip().getTextoAyudaIntensPago()
                                    : VACIO;
                            this.tooltipConfRef = null != rs.getConvenioTooltip().getTextoAyudaConfRef()
                                    ? rs.getConvenioTooltip().getTextoAyudaConfRef()
                                    : VACIO;
                        }
                        // Consulta de la configuración para cada uno de los convenios
                        // HU21.7 Lista de multiples referencias
                        this.setReferenciasAdicionalesList(response.getReferences());
                        this.setIsPermiteMultiplesRef(response.getConfigAgreementType().isMultiRef());

                        // HU 21.11 -referencia principal numerica para convenios de unica referencia
                        if (null != response.getReferences() && response.getReferences().size() > 0) {
                            
                                this.referenciasAdicionalesList.get(0).setTipoCampo(NUMERICO);
                            
                            // metodo para altas y bajas para el label de confirmacion de refrencia
                            this.labelConfirmacion = getLabelConfirmar(this.referenciasAdicionalesList.get(0).getLabel());
                        }
                    }

                    this.modalidad = response.getModeAgreement();
                    this.isPermiteInscribir = response.isPermiteInscripcion();
                    logger.info("referencia [cargarDatos]: " + referencia);
                    // Si existen referencias enviadas por evento
                    if (null != referencia && !referencia.equals("")) {
                        Gson gson = new Gson();
                        Type type = new TypeToken<List<ReferenceType>>() {
                        }.getType();
                        List<ReferenceType> listaReferencias = gson.fromJson(referencia, type);

                        // mapeo de valores referencia adicionales por evento
                        if (response.getConfigAgreementType().isMultiRef() == true) {
                            this.setValoresReferenciaAdicionalList(listaReferencias);
                        }
                        this.setReferenciaPago(listaReferencias.get(0).getReference());

                        // mapeo de valores de referencia en la referencia
                        mapeoReferenciasForEvent(listaReferencias, response.getReferences());

                    }

                    // Mensaje Ayuda Pago Agil
                    this.mensajeAyudaPagoAgil = rbPortlet.getString("txtMsjAyudaPagoAgil");
                    // Titulos pasos web responsive
                    this.nombrePasoUnoMovil = rbPortlet.getString("stNombrePasoUnoMovil");
                    this.nombrepasoDosMovil = rbPortlet.getString("stNombrePasoDosMovil");
                    // Método que consulta la imagen del convenio
                    searchConvImage(rContenido);

                }
            } else {
                if (null != response.getExcepcion() && null != response.getExcepcion().getCodigo()) {
                    errorCode = response.getExcepcion().getCodigo();
                }

                logger.info("getConvenioInfo ID: " + this.idConvenio + ". Response CODE: " + response.getStatus().getStatusCode()
                        + ", DESC: " + response.getStatus().getStatusDesc());
                String[] error = ErrorManager.getInstance(request).obtenerErrorWCM(rContenido.getPathErroresTecnicos(),
                        response.getExcepcion().getCodigo());
                this.mostrarModal(error[0], "icon-error", error[1]);
            }
        } catch (NamingException e) {
            errorCode = ExceptionManager.PP_PORTAL_MIDD_01;
            ErrorData errorData = PublisherUtil.getInstance().getErrorData(e, rquid, ExceptionManager.PP_PORTAL_MIDD_01, user,
                    ExceptionManager.MSG_PORTAL_MIDD_01 + " - Operación: cargarDatos, Realizar pago facturadores", "cargarDatos",
                    rContenido.getPortletOrigen(), rContenido.getPaginaOrigen(), rContenido.getPortalOrigen());
            logger.error(errorData, e);
            String[] error = ErrorManager.getInstance(request).obtenerErrorWCM(rContenido.getPathErroresTecnicos(),
                    ExceptionManager.PP_PORTAL_MIDD_01);
            this.mostrarModal(error[0], "icon-error", error[1]);
        } catch (Exception e) {
            errorCode = ExceptionManager.PP_PORTAL_GENERIC_01;
            ErrorData errorData = PublisherUtil.getInstance().getErrorData(e, rquid, ExceptionManager.PP_PORTAL_GENERIC_01, user,
                    ExceptionManager.MSG_PORTAL_GENERIC_01 + " Operación: cargarDatos, Realizar pago facturadores", "cargarDatos",
                    rContenido.getPortletOrigen(), rContenido.getPaginaOrigen(), rContenido.getPortalOrigen());
            logger.error(errorData, e);
            String[] error = ErrorManager.getInstance(request).obtenerErrorWCM(rContenido.getPathErroresTecnicos(),
                    ExceptionManager.PP_PORTAL_GENERIC_01);
            this.mostrarModal(error[0], "icon-error", error[1]);
        } finally {
            /*
             * john.ramirez --- 14/02/2017 --- se realiza la validacion para que no llame al auditorGetConvenioInfo cuando no se cargue la
             * informacion del convenio. Ya sea cuando haya un error obteniendo la informacion del convenio o cuando el estado del portlet
             * es eliminado o inactivo
             */
            if (null != response && null != response.getEstado() && response.getEstado().equals("1")) {
                auditorGetConvenioInfoRs(response, requestInfo, request, rbPortlet.getString("auditoria.iniciarPago"), rquid, errorCode,
                        this.idConvenio);
            }
        }
    }
  
	private String getLabelConfirmar(String label) {
        return ManejadorTexto.asignarAltosBajosMinuscula(label, true);
    }

    /**
     * HU21.7 Mapeo de referencias en la lista del response del cache manager
     * 
     * @since 03/04/17
     * @author: German Diaz
     **/
    private void mapeoReferenciasForEvent(List<ReferenceType> listaReferencias, List<ReferenceAgreementType> listResponse) {
    	logger.info("Cantidad de referencias a mapear [mapeoReferenciasForEvent]: " + listaReferencias.size());
        // recorrido de lista de referencias enviada por evento. Esto permite que en la vista se vean los valores de las referencias
        // enviadas por evento
        for (ReferenceType referenceEvent : listaReferencias) {
            // recorrido de lista de referencias del response del cache
            for (ReferenceAgreementType referenceType : listResponse) {
                if (referenceType.getPosicion().equals(String.valueOf(referenceEvent.getPosition()))) {
                    // Se asigna el valor al de la referencia
                    referenceType.setValorJson(referenceEvent.getReference().toLowerCase());
                    break;
                }

            }
        }
    }

    /**
     * HU18 Funci�n que retorna el outcome de la p�gina a la que debe redireccionar el portlet cuando se le da en el bot�n continuar La url
     * de la p�gina asociada al outcome se configura en las reglas de navegaci�n en el faces-config.xml
     * 
     * @since 16/12/14
     * @author: M�lany Rozo
     **/
    public String continuar(ActionRequest request) {
    	logger.info("CargueArchivoPersonalizado - CONTINUAR");
        PortletSession session = request.getPortletSession();
        logger.info("Acción continuar...");
        // Se genera nuevo RQUID para acción Consultar Factura
        rquid = PublisherUtil.getInstance().generateRequestID();
        session.setAttribute("rquid", rquid, PortletSession.APPLICATION_SCOPE);
        RutaContenidoBean rContenido = (RutaContenidoBean) session.getAttribute("RutaContenidoBean", PortletSession.APPLICATION_SCOPE);
        ResourceBundle rbPortlet = ResourceBundle
                .getBundle("com.portalpagos.realizarpagofact.portlet.nl.RealizarPagoFactV2PortletResource");
        String accion = rbPortlet.getString("auditoria.consultaFactura");
        /* Si no es un pago realizado por ventanilla se setea el usuario */
        if (rContenido.getTaquillas() == null || rContenido.getTaquillas().isEmpty()) {
            user = (String) session.getAttribute("user", PortletSession.APPLICATION_SCOPE);
        }
        ip = (String) session.getAttribute("ip", PortletSession.APPLICATION_SCOPE);
        logger.info("Datos globales: " + "user: " + user + " ip: " + ip);
        String refPago = this.referenciaPago;
        String idConvenio = this.idConvenio;
        boolean permitePacial = this.permiteParcial;
        logger.info("Datos pago [continuar]: " + "ref pago: " + refPago + " IdConv: " + idConvenio + " Parcial: " + permitePacial);
        // Llamado a método para realizar la Traza del RQ
        auditorRqPayCentralBill(request, rContenido, accion, rquid, ip, user, idConvenio, refPago);

        String tituloError = "", cuerpoLightbox = "", errorCode = "";
        this.consultarUsuarioAutenticado(request);
        PayCentralBillRequest requestPay = null;
        PayCentrallBillResponse responsePay = null;
        try {
            // Crea el objeto de consulta para enviar al MWC
            requestPay = new PayCentralBillRequest();

            BankInfoType objBanco = new BankInfoType();
            objBanco.setBankName(rContenido.getBankName());
            objBanco.setBankId(rContenido.getBankId());

            requestPay.setAgreementID(idConvenio.toUpperCase());
            requestPay.setBankID(rContenido.getBankId());
            requestPay.setIpAddress(ip);
            requestPay.setNIE(refPago);

            requestPay.setListReferences(this.valoresReferenciaAdicionalList);

            requestPay.setIntentionPayment(this.intencionPago);
            requestPay.setOwnerDocument(this.numeroDocumento);
            requestPay.setOwnerDocumentType(this.tipoDocumento);

            requestPay.setRequestDate(new Date());
            requestPay.setRequestSender(rContenido.getPortletOrigen());
            requestPay.setRequestPage(rContenido.getPaginaOrigen());
            requestPay.setRequestOriginPortal(rContenido.getPortalOrigen());
            requestPay.setBankInfo(objBanco);
            requestPay.setRequestID(rquid);
            requestPay.setRequestUser(user);
            requestPay.setCode(this.duenoId);
            
            // RQ29184 - Consultar campos de la factura personalizada
            // Se valida si el tipo del cargue del convenio es ACH
            if(this.convenioTipoCargueId == 3) {
            	logger.info("CargueArchivoPersonalizado - Tipo cargue es 3");
            	this.camposFacturaPersonzalizada = obtenerCamposFacturaPersonalizada(request);
            }

            logger.info("[REQUEST - PayCentrallBill] DATA: " + gson.toJson(requestPay));

            String EndPointRESTServicePayCentralBillRequest = ConfigurationService.getInstance().getEndpointRest();

            responsePay = (PayCentrallBillResponse) WebServiceClientHTTPS.getInstance(PayCentrallBillResponse.class)
                    .procesarRequest(EndPointRESTServicePayCentralBillRequest + "getPSPInvoicePurchases", requestPay);

            logger.info("[RESPONSE - PayCentrallBill] DATA: " + gson.toJson(responsePay));

            // Inicialización de variables para generación del captcha
            int intentos = null == session.getAttribute("intentos", PortletSession.APPLICATION_SCOPE) ? 0
                    : (Integer) session.getAttribute("intentos", PortletSession.APPLICATION_SCOPE);
            intentos++;
            session.setAttribute("intentos", intentos, PortletSession.APPLICATION_SCOPE);
            // Respuesta del llamado al middleware PayCentralBill
            if (!("SUCCESS".equals(responsePay.getStatus().getStatusCode()))) {
                if (null != responsePay.getExcepcion() && null != responsePay.getExcepcion().getCodigo()) {
                	errorCode = responsePay.getExcepcion().getCodigo();
                	logger.info("Exception en PayCentrallBill: " + errorCode);
                }

                logger.info("getPayCentralBill ID: " + this.idConvenio + ", REFERENCIA: " + refPago + ". Response CODE: "
                        + responsePay.getStatus().getStatusCode() + ", DESC: " + responsePay.getStatus().getStatusDesc() + ", errorCode: "
                        + errorCode);

                if ("ERROR_27".equals(responsePay.getStatus().getStatusDesc())) {
                    cuerpoLightbox = rbPortlet.getString("txtError27");
                    cuerpoLightbox = cuerpoLightbox.replace("#", "simboloNumeral");
                    cuerpoLightbox = cuerpoLightbox.replace("numRef", this.getReferenciaPago());
                    String pmtId = "";
                    if (responsePay.getMedioPagoId() == 3 && null != responsePay.getCus() && !"".equals(responsePay.getCus())
                            && !"null".equals(responsePay.getCus())) {
                        pmtId = responsePay.getCus();
                    } else {
                        pmtId = responsePay.getPmtId();
                    }
                    cuerpoLightbox = cuerpoLightbox.replace("pmtId", pmtId);
                    tituloError = rbPortlet.getString("stMensajeInformacion");
                    this.mostrarModal(cuerpoLightbox, "icon-alert", tituloError);
                    logger.info("---------------ERROR_27" + cuerpoLightbox + " " + tituloError);
                } else if ("PAY_IN_PROCESS".equals(responsePay.getStatus().getStatusDesc())) {
                    String mensajeGeneral = rbPortlet.getString("stMensajeTransaccionProceso");
                    tituloError = rbPortlet.getString("stMensajeInformacion");
                    cuerpoLightbox = mensajeGeneral;
                    /* john.ramirez HU 21.2.2 - Transaccion aprobada y pendiente de marcacion */
                    if (responsePay.getMedioPagoId() == 3 && null != responsePay.getCus() && !"".equals(responsePay.getCus())
                            && !"null".equals(responsePay.getCus())) {

                        cuerpoLightbox = rbPortlet.getString("stMensajeTransaccionProcesoPSE");
                        cuerpoLightbox = cuerpoLightbox.replace("#", "simboloNumeral");
                        cuerpoLightbox = cuerpoLightbox.replace("FFACTURA",
                                (this.referenciaPago != null && this.referenciaPago != "") ? this.referenciaPago : "");
                        cuerpoLightbox = cuerpoLightbox.replace("CCUS", responsePay.getCus());
                    }
                    this.mostrarModal(cuerpoLightbox, "icon-error", tituloError);
                    logger.info("---------------PAY_IN_PROCESS" + cuerpoLightbox + " " + tituloError);
                } else if ("ERROR_1860".equals(responsePay.getStatus().getStatusCode())) {
                    String mensajeGeneral = rbPortlet.getString("stMsgErrorConsultaFactura");
                    cuerpoLightbox = null != responsePay.getStatus().getStatusDesc() && !responsePay.getStatus().getStatusDesc().isEmpty()
                            ? responsePay.getStatus().getStatusDesc()
                            : mensajeGeneral;
                    tituloError = rbPortlet.getString("stTituloMensajeError");
                    this.mostrarModal(cuerpoLightbox, "icon-error", tituloError);
                    logger.info("---------------ERROR_1860" + cuerpoLightbox + " " + tituloError);
                } else if ("ERROR_1010".equals(responsePay.getStatus().getStatusCode())) {
                    String mensajeGeneral = rbPortlet.getString("ERROR_1010");
                    cuerpoLightbox = mensajeGeneral;
                    tituloError = rbPortlet.getString("stTituloMensajeError");
                    this.mostrarModal(cuerpoLightbox, "icon-error", tituloError);
                    logger.info("---------------ERROR_1010" + cuerpoLightbox + " " + tituloError);
                } else if ("ERROR_1400".equals(responsePay.getStatus().getStatusCode())) {
                    String mensajeGeneral = rbPortlet.getString("ERROR_1400");
                    cuerpoLightbox = mensajeGeneral;
                    tituloError = rbPortlet.getString("stTituloMensajeError");
                    this.mostrarModal(cuerpoLightbox, "icon-error", tituloError);
                    logger.info("---------------ERROR_1400" + cuerpoLightbox + " " + tituloError);
                } else if ("ERROR_2120".equals(responsePay.getStatus().getStatusCode())) {
                    String mensajeGeneral = rbPortlet.getString("ERROR_2120");
                    cuerpoLightbox = mensajeGeneral;
                    tituloError = rbPortlet.getString("stTituloMensajeError");
                    this.mostrarModal(cuerpoLightbox, "icon-error", tituloError);
                    logger.info("---------------ERROR_2120" + cuerpoLightbox + " " + tituloError);
                } else if ("ERROR_2100".equals(responsePay.getStatus().getStatusCode())) {
                    String mensajeGeneral = rbPortlet.getString("ERROR_2100");
                    cuerpoLightbox = mensajeGeneral;
                    tituloError = rbPortlet.getString("stTituloMensajeError");
                    this.mostrarModal(cuerpoLightbox, "icon-error", tituloError);
                    logger.info("---------------ERROR_2100" + cuerpoLightbox + " " + tituloError);
                } else if ("ERROR_1220".equals(responsePay.getStatus().getStatusCode())) {
                    String mensajeGeneral = rbPortlet.getString("ERROR_1220");
                    cuerpoLightbox = mensajeGeneral;
                    tituloError = rbPortlet.getString("stTituloMensajeError");
                    this.mostrarModal(cuerpoLightbox, "icon-error", tituloError);
                    logger.info("---------------ERROR_1220" + cuerpoLightbox + " " + tituloError);
                } else if ("ERROR_200".equals(responsePay.getStatus().getStatusDesc())) {
                    String mensajeGeneral = rbPortlet.getString("stMsgErrorConsultaFactura");
                    String serverStatusCode = null != responsePay.getStatus().getServerStatusCode() && !responsePay.getStatus().getServerStatusCode().isEmpty() ?
                            "("+responsePay.getStatus().getServerStatusCode()+")": "";
                    cuerpoLightbox = null != responsePay.getStatus().getServerStatusDescp() && !responsePay.getStatus().getServerStatusDescp().isEmpty() ? 
                            responsePay.getStatus().getServerStatusDescp()+ " "+ serverStatusCode : mensajeGeneral + " "+ serverStatusCode;
                    tituloError = rbPortlet.getString("stTituloMensajeError");
                    this.mostrarModal(cuerpoLightbox, "icon-error", tituloError);
                    logger.info("---------------ERROR_200" + cuerpoLightbox + " " + tituloError);
                }else if("ERROR_100".equals(responsePay.getStatus().getStatusDesc())){
                    String mensajeGeneral = rbPortlet.getString("stMensajeError100");
                    String serverStatusCode = null != responsePay.getStatus().getServerStatusCode() && !responsePay.getStatus().getServerStatusCode().isEmpty() ?
                            "("+responsePay.getStatus().getServerStatusCode()+")": "";
                    cuerpoLightbox = mensajeGeneral + " " +serverStatusCode;
                    tituloError = rbPortlet.getString("stTituloMensajeError");
                    this.mostrarModal(cuerpoLightbox, "icon-error", tituloError);   
                    logger.info("---------------ERROR_100" + cuerpoLightbox + " " + tituloError);
                }else if("ERROR_300".equals(responsePay.getStatus().getStatusDesc())){
                    String mensajeGeneral = rbPortlet.getString("stMensajeError300");
                    String serverStatusCode = null != responsePay.getStatus().getServerStatusCode() && !responsePay.getStatus().getServerStatusCode().isEmpty() ?
                            "("+responsePay.getStatus().getServerStatusCode()+")": "";
                    cuerpoLightbox = mensajeGeneral + " " +serverStatusCode;
                    tituloError = rbPortlet.getString("stTituloMensajeError");
                    this.mostrarModal(cuerpoLightbox, "icon-error", tituloError);
                    logger.info("---------------ERROR_300" + cuerpoLightbox + " " + tituloError);
                }else if("ERROR_600".equals(responsePay.getStatus().getStatusDesc())){
                    String mensajeGeneral = rbPortlet.getString("stMensajeError600");
                    String serverStatusCode = null != responsePay.getStatus().getServerStatusCode() && !responsePay.getStatus().getServerStatusCode().isEmpty() ?
                            "("+responsePay.getStatus().getServerStatusCode()+")": "";
                    cuerpoLightbox = mensajeGeneral + " " +serverStatusCode;
                    tituloError = rbPortlet.getString("stTituloMensajeError");
                    this.mostrarModal(cuerpoLightbox, "icon-error", tituloError);
                    logger.info("---------------ERROR_600" + cuerpoLightbox + " " + tituloError);
                }else if("ERROR_700".equals(responsePay.getStatus().getStatusDesc())){
                    String mensajeGeneral = rbPortlet.getString("stMensajeError700");
                    String serverStatusCode = null != responsePay.getStatus().getServerStatusCode() && !responsePay.getStatus().getServerStatusCode().isEmpty() ?
                            "("+responsePay.getStatus().getServerStatusCode()+")": "";
                    cuerpoLightbox = mensajeGeneral + " " +serverStatusCode;
                    tituloError = rbPortlet.getString("stTituloMensajeError");
                    this.mostrarModal(cuerpoLightbox, "icon-error", tituloError);
                    logger.info("---------------ERROR_700" + cuerpoLightbox + " " + tituloError);
                } else {
                    String[] error = ErrorManager.getInstance(request).obtenerErrorWCM(rContenido.getPathErroresTecnicos(),
                            responsePay.getExcepcion().getCodigo());
                    this.mostrarModal(error[0], "icon-error", error[1]);
                }

            } else if (responsePay.getTransactionStatusRs().getTrnStatusCode().equalsIgnoreCase("0")) {
            	logger.info("PayCentralBill respuesta 0");
                String valorPago = "";
                // Valida si el valor a pagar es cero
                if (responsePay.getPaymentShareAmount() != null && Double.compare(Double.parseDouble(responsePay.getPaymentShareAmount()), Double.valueOf("0.0")) > 0) {
                    logger.info("Valor a pagar diferente de 0");
                	banderaMsgValorCero = false;
                    Double valor = Double.parseDouble(responsePay.getPaymentShareAmount());
                    try {

                        // Captura los valores almacenados en el properties
                        ResourceBundle rb = ResourceBundle
                                .getBundle("com.portalpagos.realizarpagofact.portlet.nl.RealizarPagoFactV2PortletResource");
                        String formatValor = rb.getString("transaccion.formatValor");
                        String caracterSeparador = rb.getString("transaccion.separadorCaracter");
                        String caracterReplace = rb.getString("transaccion.separadorReplace");
                        DecimalFormat formatoMoneda = new DecimalFormat(formatValor);
                        // Realiza la conversi�n del valor para que cumpla con
                        // el formato #.###.###
                        valorPago = formatoMoneda.format(valor);
                        valorPago = valorPago.replace(caracterSeparador, caracterReplace);
                    } catch (Exception ex) {
                        logger.info("Exception formatear Moneda " + ex.getMessage());
                        valorPago = responsePay.getPaymentShareAmount();
                    }
                } else {
                	logger.info("Valor a pagar igual a 0");
                    banderaMsgValorCero = true;
                }
                if (!banderaMsgValorCero) {
                    String valorTotal = "";
                    if (responsePay.getPaymentAmount() != null) {
                        Double valor = Double.parseDouble(responsePay.getPaymentAmount());
                        try {

                            // Captura los valores almacenados en el properties
                            ResourceBundle rb = ResourceBundle
                                    .getBundle("com.portalpagos.realizarpagofact.properties.RealizarPagoFactPortletResource");
                            String formatValor = rb.getString("transaccion.formatValor");
                            String caracterSeparador = rb.getString("transaccion.separadorCaracter");
                            String caracterReplace = rb.getString("transaccion.separadorReplace");
                            DecimalFormat formatoMoneda = new DecimalFormat(formatValor);
                            // Realiza la conversi�n del valor para que cumpla con
                            // el formato #.###.###
                            valorTotal = formatoMoneda.format(valor);
                            valorTotal = valorTotal.replace(caracterSeparador, caracterReplace);
                        } catch (Exception ex) {
                            logger.info("Exception formatear Moneda " + ex.getMessage());
                            valorTotal = responsePay.getPaymentAmount();
                        }
                    }

                    this.permiteParcial = permitePacial;
                    this.tipoPago = "1";
                    this.valorPago = valorPago;
                    this.valorTotal = valorTotal;
                    logger.info("Se setean los valores de pago y total de factura");
                    logger.info("validacion tope factura: " + responsePay.isValidTope());
                    this.validTope = responsePay.isValidTope(); 
                    setPorcentajeTope(responsePay.getPorcentajevalorpagar());
                    String trm = null != responsePay.getTRMAmt() ? responsePay.getTRMAmt() : "";
                    this.trm = trm;
                    
                    logger.info("Trm [continuar]: " + trm);

                    Date fecPagoOportuno = responsePay.getTimelyPaymentDate();
                    Date fecLimitePago = responsePay.getDuePaymentDate();

                    logger.info("FehcaPagoOportuno [continuar]: " + fecPagoOportuno);
                    logger.info("fecLimitePago [continuar]: " + fecLimitePago);
                    if (String.valueOf(fecPagoOportuno).equalsIgnoreCase(String.valueOf(fecLimitePago))) {
                        this.fechaVencimientoPago = fecPagoOportuno;
                    } else if (fecPagoOportuno != fecLimitePago) {
                        this.fechaPagoOportuno = fecPagoOportuno;
                        this.fechaLimitePago = fecLimitePago;
                    } else {
                        logger.info(
                                "Error en las fechas, getDuePaymentDate: " + fecPagoOportuno + " - getTimelyPaymentDate: " + fecLimitePago);
                    }
                    // Se eliminan las variables de session para la generación del captcha
                    session.removeAttribute("intentos", PortletSession.PORTLET_SCOPE);
                    session.removeAttribute("captchaBean", PortletSession.PORTLET_SCOPE);

                    this.mostrarModal = "false";
                    return "/jsp/formConfirmacionPago.jsp";
                } else {
                    cuerpoLightbox = rbPortlet.getString("stValorPagarCero");
                    tituloError = rContenido.getTituloError();
                    this.mostrarModal(cuerpoLightbox, "icon-error", tituloError);
                    logger.info("Mostrando modal valor a pagar igual a 0");
                }
            } else {
            	logger.info("No exitoso y diferente de 0 PayCentralBill");
                cuerpoLightbox = responsePay.getTransactionStatusRs().getTrnStatusDesc();
                tituloError = rContenido.getTituloError();

                ResourceBundle rb = ResourceBundle
                        .getBundle("com.portalpagos.realizarpagofact.portlet.nl.RealizarPagoFactV2PortletResource");
                String estadoNoExiste = rb.getString("msg.errorNoExiste");
                String estadoPagado = rb.getString("msg.errorPagada");
                String estadoPagadoDos = rb.getString("msg.errorPagadaDos");
                String estadoVencido = rb.getString("msg.errorVencida");
                if (String.valueOf(estadoNoExiste).equalsIgnoreCase(cuerpoLightbox)) {
                    cuerpoLightbox = rb.getString("stMensajeErrorNoExiste");
                    logger.info("MensajeErrorNoExiste [continuar]");
                } else if (cuerpoLightbox.equalsIgnoreCase(estadoPagado + this.referenciaPago + " " + estadoPagadoDos)) {
                    /*
                     * john.ramirez HU 28.5 Se consulta el nuevo mensaje que se debe mostrar en caso de que el servicio retorne que la
                     * factura esta pagada
                     */
                    GetTransactionForReferenceRq requestTransReferen = null;
                    GetTransactionForReferenceRs responseTranReferen = null;

                    requestTransReferen = new GetTransactionForReferenceRq();
                    requestTransReferen.setReference(this.referenciaPago);
                    requestTransReferen.setAgreementId(this.idConvenio);

                    logger.info("[REQUEST - getTransactionForReference] DATA: " + gson.toJson(requestTransReferen));

                    responseTranReferen = (GetTransactionForReferenceRs) WebServiceClientHTTPS
                            .getInstance(GetTransactionForReferenceRs.class)
                            .procesarRequest(EndPointRESTServicePayCentralBillRequest + "getTransactionForReference", requestTransReferen);

                    logger.info("[RESPONSE - getTransactionForReference] DATA: " + gson.toJson(responseTranReferen));

                    if (null != responseTranReferen && null != responseTranReferen.getMedioPagoId()
                            && !("null").equals(responseTranReferen.getMedioPagoId()) && !"".equals(responseTranReferen.getMedioPagoId())) {
                        if (responseTranReferen.getMedioPagoId().equals("3")) {
                            if (null != responseTranReferen.getAprobacionId() && !("null").equals(responseTranReferen.getAprobacionId())
                                    && !("").equals(responseTranReferen.getAprobacionId())) {
                                cuerpoLightbox = rbPortlet.getString("stMensajeErrorPagado");
                                cuerpoLightbox = cuerpoLightbox.replace("#", "simboloNumeral");
                                cuerpoLightbox = cuerpoLightbox.replace("FFACTURA",
                                        (this.referenciaPago != null && this.referenciaPago != "") ? this.referenciaPago : "");
                                cuerpoLightbox = cuerpoLightbox.replace("CCUS", responseTranReferen.getAprobacionId());
                            }
                        } else {
                            if (null != responseTranReferen.getPagoId() && !("null").equals(responseTranReferen.getPagoId())
                                    && !("").equals(responseTranReferen.getPagoId())) {

                                cuerpoLightbox = rbPortlet.getString("stMensajeErrorPagado");
                                cuerpoLightbox = cuerpoLightbox.replace("#", "simboloNumeral");
                                cuerpoLightbox = cuerpoLightbox.replace("FFACTURA",
                                        (this.referenciaPago != null && this.referenciaPago != "") ? this.referenciaPago : "");
                                cuerpoLightbox = cuerpoLightbox.replace("CCUS", responseTranReferen.getPagoId());
                            }
                        }
                    }

                } else if (cuerpoLightbox.equalsIgnoreCase(estadoVencido)) {
                    cuerpoLightbox = rb.getString("stMensajeErrorVencido");
                    logger.info("MensajeErrorVencido [continuar]");
                }
                this.mostrarModal(cuerpoLightbox, "icon-alert", tituloError);
            }

        } catch (Exception e) {
            errorCode = ExceptionManager.PP_PORTAL_GENERIC_01;
            ErrorData errorData = PublisherUtil.getInstance().getErrorData(e, rquid, ExceptionManager.PP_PORTAL_GENERIC_01, user,
                    ExceptionManager.MSG_PORTAL_GENERIC_01 + " Operación: continuar, Realizar pago facturadores", "continuar",
                    rContenido.getPortletOrigen(), rContenido.getPaginaOrigen(), rContenido.getPortalOrigen());
            logger.error(errorData, e);
            String[] error = ErrorManager.getInstance(request).obtenerErrorWCM(rContenido.getPathErroresTecnicos(),
                    ExceptionManager.PP_PORTAL_GENERIC_01);
            this.mostrarModal(error[0], "icon-error", error[1]);
        } finally {
        	logger.info("Auditando PayCentralBill...");
            auditorPayCentralBillRs(responsePay, requestPay, accion, rquid, errorCode, rContenido.getPortletOrigen(), idConvenio, refPago);
        }

        // request.getPortletSession().setAttribute("datosPagoFactBean",param, PortletSession.APPLICATION_SCOPE);
        return "/jsp/CapturaReferenciaView.jsp";

    }

    /**
     * HU 143 Función encargada de validar si existe un usuario autenticado, para determinar si se muestra check de términos y condiciones
     * 
     * @author melany.rozo
     * @since 13/08/2015
     */
    public void consultarUsuarioAutenticado(ActionRequest request) {
    	logger.info("Usuario autenticado [consultarUsuarioAutenticado]: " + user);
        try {
            /*if (null != user) {
                this.mostrarTerminosCondiciones = false;
            } else {
                this.mostrarTerminosCondiciones = true;
            }*/
        	
        	this.mostrarTerminosCondiciones = true;
        	
            this.setAceptaTerminos(false);
        } catch (Exception e) {
            RutaContenidoBean rContenido = (RutaContenidoBean) request.getPortletSession().getAttribute("RutaContenidoBean",
                    PortletSession.APPLICATION_SCOPE);
            ErrorData errorData = PublisherUtil.getInstance().getErrorData(e, rquid, ExceptionManager.PP_PORTAL_GENERIC_01, user,
                    ExceptionManager.MSG_PORTAL_GENERIC_01 + " OperaciÃ³n: consultarUsuarioAutenticado, Realizar pago facturadores",
                    "consultarUsuarioAutenticado", rContenido.getPortletOrigen(), rContenido.getPaginaOrigen(),
                    rContenido.getPortalOrigen());
            logger.error(errorData, e);
            String[] error = ErrorManager.getInstance(request).obtenerErrorWCM(rContenido.getPathErroresTecnicos(),
                    ExceptionManager.PP_PORTAL_GENERIC_01);
            this.mostrarModal(error[0], "icon-error", error[1]);
        }

    }

    /**
     * HU20 Funci�n que retorna el outcome de la p�gina a la que debe redireccionar el portlet cuando se le da en el bot�n volver La url de
     * la p�gina asociada al outcome se configura en las reglas de navegaci�n en el faces-config.xml
     * 
     * @since 16/12/14
     * @author: M�lany Rozo
     **/
    public String volver() {
        this.mostrarModal = "false";
        return "CapturaReferenciaView";
    }

    /**
     * HU107 Funci�n encargada de setear los valores para mostrar el modal con el mensaje recibido
     * 
     * @author melany.rozo
     * @since 24/02/2015
     */
    public void mostrarModal(String mensaje, String tipo, String titulo) {
    	logger.info("Mostrando modal Bean...");
        this.cuerpoLighbox = mensaje;
        this.tipoModal = tipo;
        this.tituloModal = titulo;
        this.mostrarModal = "true";
        try {
            String[] categoriaArray = Modal.calcularDimensionModal(mensaje);
            this.anchoModal = categoriaArray[0];
            this.altoModal = categoriaArray[1];
        } catch (NoClassDefFoundError e) {
            this.anchoModal = "375";
            this.altoModal = "134";
        }
    }

    /**
     * HU 143 Funci�n encargada de Trazar del RS de GetConvenioInfoRs
     * 
     * @author germandiaz
     * @param idRequest
     * @since 13/08/2015
     */
    private void auditorGetConvenioInfoRs(GetConvenioInfoRs response, GetConvenioInfoRq requestInfo, RenderRequest request, String accion,
            String idRequest, String erroCode, String idConvenio) {
    	try {
            // Objeto Auditor Rq
            AuditorRq auditorRq = new AuditorRq();
            auditorRq.setAction(accion);
            auditorRq.setAdditionalInfo(
                    JSONUtil.getJson(COD_CONVENIO + DOSPUNTOS + idConvenio, NODO + DOSPUNTOS + IpNodoPortal.getIpNodo()));
            auditorRq.setCodigoServicioInt(response.getCodigoServicio());
            auditorRq.setErrorCode(erroCode);
            auditorRq.setExecutionDate(CommonUtils.getInstance().asXMLGregorianCalendar(new Date()));
            auditorRq.setIpAddress(requestInfo.getIpAddress());
            auditorRq.setOriginPortal(requestInfo.getBankInfo().getBankName());
            auditorRq.setPage(requestInfo.getRequestPage());
            auditorRq.setPortlet(requestInfo.getRequestSender());
            auditorRq.setRequestId(idRequest);
            auditorRq.setTipoServicio(RS);
            auditorRq.setUser(requestInfo.getRequestUser());
            logger.info("[RESPONSE - auditorGetConvenioInfoRs] DATA: " + gson.toJson(auditorRq));
            // Llamado al metodo para trazar rq
            TrazaPublisher.getInstance().publish(auditorRq);
        } catch (Exception e) {
            RutaContenidoBean rContenido = (RutaContenidoBean) request.getPortletSession().getAttribute("RutaContenidoBean",
                    PortletSession.APPLICATION_SCOPE);
            ErrorData errorData = PublisherUtil.getInstance().getErrorData(e, rquid, ExceptionManager.PP_PORTAL_GENERIC_01, user,
                    ExceptionManager.MSG_PORTAL_GENERIC_01 + " Operación: auditorGetConvenioInfoRs, Realizar pago facturadores",
                    "auditorGetConvenioInfoRs", rContenido.getPortletOrigen(), rContenido.getPaginaOrigen(), rContenido.getPortalOrigen());
            logger.error(errorData, e);
        }
    }

    /**
     * HU 143 Funci�n encargada de Trazar la Rq de auditorRqPayCentralBillRq
     * 
     * @author germandiaz
     * @param idRequest
     * @since 13/08/2015
     */
    private void auditorRqPayCentralBill(ActionRequest request, RutaContenidoBean requestPay, String accion, String idRequest,
            String ipAdress, String userName, String idConvenio, String referencia) {
        try {
            String primeraRef = this.referenciaPrimeraAdicional == null || "".equals(this.referenciaPrimeraAdicional) ? null
                    : this.referenciaPrimeraAdicional;
            String segundaRef = this.referenciaSegundaAdicional == null || "".equals(this.referenciaSegundaAdicional) ? null
                    : this.referenciaSegundaAdicional;
            String terceraRef = this.referenciaTerceraAdicional == null || "".equals(this.referenciaTerceraAdicional) ? null
                    : this.referenciaTerceraAdicional;
            // Objeto Auditor Rq
            AuditorRq auditorRq = new AuditorRq();
            auditorRq.setAction(accion);
            auditorRq.setAdditionalInfo(
                    JSONUtil.getJson(COD_CONVENIO + DOSPUNTOS + idConvenio, NODO + DOSPUNTOS + IpNodoPortal.getIpNodo()));
            if (null != this.isRequierePrimeraReferencia && this.isRequierePrimeraReferencia) {
                auditorRq.setAdditionalInfo(JSONUtil.getJson(COD_CONVENIO + DOSPUNTOS + idConvenio,
                        PRIMERA_REFERENCIA + DOSPUNTOS + primeraRef, NODO + DOSPUNTOS + IpNodoPortal.getIpNodo()));
            }
            if (null != this.isRequiereSegundaReferencia && this.isRequiereSegundaReferencia) {
                auditorRq.setAdditionalInfo(
                        JSONUtil.getJson(COD_CONVENIO + DOSPUNTOS + idConvenio, PRIMERA_REFERENCIA + DOSPUNTOS + primeraRef,
                                SEGUNDA_REFERENCIA + DOSPUNTOS + segundaRef, NODO + DOSPUNTOS + IpNodoPortal.getIpNodo()));
            }
            if (null != this.isRequiereTerceraReferencia && this.isRequiereTerceraReferencia) {
                auditorRq.setAdditionalInfo(JSONUtil.getJson(COD_CONVENIO + DOSPUNTOS + idConvenio,
                        PRIMERA_REFERENCIA + DOSPUNTOS + primeraRef, SEGUNDA_REFERENCIA + DOSPUNTOS + segundaRef,
                        TERCERA_REFERENCIA + DOSPUNTOS + terceraRef, NODO + DOSPUNTOS + IpNodoPortal.getIpNodo()));
            }
            auditorRq.setExecutionDate(CommonUtils.getInstance().asXMLGregorianCalendar(new Date()));
            auditorRq.setIpAddress(ipAdress);
            auditorRq.setOriginPortal(requestPay.getBankName());
            auditorRq.setPage(requestPay.getPaginaOrigen());
            auditorRq.setPortlet(requestPay.getPortletOrigen());
            auditorRq.setRequestId(idRequest);
            auditorRq.setTipoServicio(RQ);
            auditorRq.setUser(userName);
            auditorRq.setReference(referencia);

            // Llamado al m�todo para trazar rq
            TrazaPublisher.getInstance().publish(auditorRq);
        } catch (Exception e) {
            RutaContenidoBean rContenido = (RutaContenidoBean) request.getPortletSession().getAttribute("RutaContenidoBean",
                    PortletSession.APPLICATION_SCOPE);
            ErrorData errorData = PublisherUtil.getInstance().getErrorData(e, rquid, ExceptionManager.PP_PORTAL_GENERIC_01, user,
                    ExceptionManager.MSG_PORTAL_GENERIC_01 + " Operación: auditorRqPayCentralBill, Realizar pago facturadores",
                    "auditorRqPayCentralBill", rContenido.getPortletOrigen(), rContenido.getPaginaOrigen(), rContenido.getPortalOrigen());
            logger.error(errorData, e);
        }
    }

    /**
     * HU 143 Funci�n encargada de Trazar del RS de auditorPayCentralBillRs
     * 
     * @author germandiaz
     * @param PayCentrallBillResponse,
     *            PayCentralBillRequest, accion, idRequest
     * @since 13/08/2015
     */
    private void auditorPayCentralBillRs(PayCentrallBillResponse response, PayCentralBillRequest requestExe, String accion,
            String idRequest, String errorCode, String portlet, String idConvenio, String referencia) {
        String primeraRef = this.referenciaPrimeraAdicional == null || "".equals(this.referenciaPrimeraAdicional) ? null
                : this.referenciaPrimeraAdicional;
        String segundaRef = this.referenciaSegundaAdicional == null || "".equals(this.referenciaSegundaAdicional) ? null
                : this.referenciaSegundaAdicional;
        String terceraRef = this.referenciaTerceraAdicional == null || "".equals(this.referenciaTerceraAdicional) ? null
                : this.referenciaTerceraAdicional;
        // Objeto Auditor Rq
        AuditorRq auditorRq = new AuditorRq();
        auditorRq.setAction(accion);
        auditorRq.setAdditionalInfo(JSONUtil.getJson(COD_CONVENIO + DOSPUNTOS + idConvenio, NODO + DOSPUNTOS + IpNodoPortal.getIpNodo(),
                NODO_INTREGRA + DOSPUNTOS + response.getIpIntegracion(), ESTADO + DOSPUNTOS + response.getStatus().getStatusCode()));
        if (null != this.isRequierePrimeraReferencia && this.isRequierePrimeraReferencia) {
            auditorRq.setAdditionalInfo(JSONUtil.getJson(COD_CONVENIO + DOSPUNTOS + idConvenio, PRIMERA_REFERENCIA + DOSPUNTOS + primeraRef,
                    NODO + DOSPUNTOS + IpNodoPortal.getIpNodo(), NODO_INTREGRA + DOSPUNTOS + response.getIpIntegracion(),
                    ESTADO + DOSPUNTOS + response.getStatus().getStatusCode()));
        }
        if (null != this.isRequiereSegundaReferencia && this.isRequiereSegundaReferencia) {
            auditorRq.setAdditionalInfo(JSONUtil.getJson(COD_CONVENIO + DOSPUNTOS + idConvenio, PRIMERA_REFERENCIA + DOSPUNTOS + primeraRef,
                    SEGUNDA_REFERENCIA + DOSPUNTOS + segundaRef, NODO + DOSPUNTOS + IpNodoPortal.getIpNodo(),
                    NODO_INTREGRA + DOSPUNTOS + response.getIpIntegracion(), ESTADO + DOSPUNTOS + response.getStatus().getStatusCode()));
        }
        if (null != this.isRequiereTerceraReferencia && this.isRequiereTerceraReferencia) {
            auditorRq.setAdditionalInfo(JSONUtil.getJson(COD_CONVENIO + DOSPUNTOS + idConvenio, PRIMERA_REFERENCIA + DOSPUNTOS + primeraRef,
                    SEGUNDA_REFERENCIA + DOSPUNTOS + segundaRef, TERCERA_REFERENCIA + DOSPUNTOS + terceraRef,
                    NODO + DOSPUNTOS + IpNodoPortal.getIpNodo(), NODO_INTREGRA + DOSPUNTOS + response.getIpIntegracion(),
                    ESTADO + DOSPUNTOS + response.getStatus().getStatusCode()));
        }
        auditorRq.setCodigoServicioInt(response.getCodigoServicio());
        auditorRq.setErrorCode(errorCode);
        auditorRq.setExecutionDate(CommonUtils.getInstance().asXMLGregorianCalendar(new Date()));
        auditorRq.setIpAddress(requestExe.getIpAddress());
        auditorRq.setOriginPortal(requestExe.getBankInfo().getBankName());
        auditorRq.setPage(requestExe.getRequestPage());
        auditorRq.setPortlet(portlet);
        auditorRq.setReference(referencia);
        auditorRq.setRequestId(idRequest);
        auditorRq.setTipoServicio(RS);
        auditorRq.setUser(requestExe.getRequestUser());

        // Llamado al m�todo para trazar rq
        TrazaPublisher.getInstance().publish(auditorRq);
    }

    /**
     * HU 21.1.2 Función encargada de buscar la imagen del convenio en el WCM
     * 
     * @author santiago.cuervo
     * @param rContenido
     * @since 20/11/2015
     */
    private void searchConvImage(RutaContenidoBean rContenido) {
        WCMCliente clienteImage = null;
        try {
            // Preferencia para el nombre base del contenido de las imágenes de convenio
            String rutaContenido = rContenido.getPathImagenConv();
            String nombreBaseImgConvenio = rContenido.getNombreBaseImgConvenio();
            String nombreContenido = nombreBaseImgConvenio + idConvenio.toUpperCase();
            // Consulta la ruta de las im�genes para los convenios
            clienteImage = new WCMCliente(rutaContenido + nombreContenido);

            String rutaImg = ((ImageComponent) clienteImage.getComponent("imgImagenConvenio")).getResourceURL();
            if (rutaImg != null) {
                // Se realiza el parsing de la url en caso de corresponde con recursos del wcm
                rutaImg = rutaImg.replaceAll("/myconnect/", "/connect/");
            }
            // reemplaza la ruta de la imagen al objeto
            this.imagen = rutaImg;

            clienteImage.endWorkspace();
        } catch (WCMException e) {
            this.imagen = "";
        } catch (Exception e) {
            this.imagen = "";
        } finally {
            if (clienteImage != null)
                clienteImage.endWorkspace();
        }
    }

    /**
     * HU 231 Función encargada de consultar los topes por valor
     * 
     * @author andrea.florez
     * @param rContenido
     * @return
     * @since 01/03/2017
     */
    public void consultaTopesPorValor(ActionRequest request) {
    	logger.info("Consultando topes por valor...");
        GetTopesValorConvenioRq rqTopesValor = null;
        GetTopesValorConvenioRs rsTopesValor = null;

        PortletSession session = request.getPortletSession();
        ResourceBundle rb = ResourceBundle.getBundle("com.portalpagos.realizarpagofact.portlet.nl.RealizarPagoFactV2PortletResource");
        RutaContenidoBean rContenido = (RutaContenidoBean) session.getAttribute("RutaContenidoBean", PortletSession.APPLICATION_SCOPE);
        String errorCode = VACIO;

        // Auditoria rqGetTopesConvenio
        String accion = rb.getString("auditoria.consultaTopesValor");
        String portlet = rb.getString("auditoria.nombrePortlet");
        auditorRqGetTopesValor(rContenido, accion, rquid, portlet, ip, request, user);
        try {
            // Instancia de objeto banco para setter de requestInfo
            BankInfoType objbanco = new BankInfoType();
            objbanco.setBankName(rContenido.getBankName());
            objbanco.setBankId(rContenido.getBankId());

            rqTopesValor = new GetTopesValorConvenioRq();
            rqTopesValor.setBankInfo(objbanco);
            rqTopesValor.setConvenioId(idConvenio);
            rqTopesValor.setFecha(new Date());
            rqTopesValor.setIpAddress(ip);
            rqTopesValor.setRequestDate(new Date());
            rqTopesValor.setRequestID(rquid);
            rqTopesValor.setRequestOriginPortal(rContenido.getPortalOrigen());
            rqTopesValor.setRequestPage(rContenido.getPaginaOrigen());
            rqTopesValor.setRequestSender(rb.getString("auditoria.nombrePortlet"));
            rqTopesValor.setRequestUser(user);

            logger.info("[REQUEST - GetTopesPorValor] DATA: " + gson.toJson(rqTopesValor));

            String EndPointRESTServiceGetTopesConvenioRq = ConfigurationEndpointRestService.getInstance().getEndpointRestRecaudadores();

            rsTopesValor = (GetTopesValorConvenioRs) WebServiceClientHTTPS.getInstance(GetTopesValorConvenioRs.class)
                    .procesarRequest(EndPointRESTServiceGetTopesConvenioRq + "getTopesValorConvenio", rqTopesValor);

            logger.info("[RESPONSE - GetTopesPorValor] DATA: " + gson.toJson(rsTopesValor));

            if (null == rsTopesValor || "ERROR".equals(rsTopesValor.getStatus().getStatusCode())) {
                logger.info("GetTopesPorValor ID: " + rqTopesValor.getConvenioId() + ". Response CODE: "
                        + rsTopesValor.getExcepcion().getCodigo() + ", DESC: " + rsTopesValor.getExcepcion().getMensaje());
                String[] error = ErrorManager.getInstance(request).obtenerErrorWCM(rContenido.getPathErroresTecnicos(),
                        ExceptionManager.PP_PORTAL_GENERIC_01);
                this.mostrarModal(error[0], "icon-error", error[1]);
            } else {
                this.topesPorValor = rsTopesValor.getTopesMedioPago();
            }

        } catch (Exception e) {
        	logger.info("Exception obtener topes por valor");
            ErrorData errorData = PublisherUtil.getInstance().getErrorData(e, rquid, ExceptionManager.PP_PORTAL_GENERIC_01, user,
                    ExceptionManager.MSG_PORTAL_GENERIC_01 + " Operación: consultaTopes", "Realizar Pago Facturador",
                    rContenido.getPortletOrigen(), rContenido.getPaginaOrigen(), rContenido.getBankName());
            logger.error(errorData, e);
            String[] error = ErrorManager.getInstance(request).obtenerErrorWCM(rContenido.getPathErroresTecnicos(),
                    ExceptionManager.PP_PORTAL_MIDD_01);
            this.mostrarModal(error[0], "icon-error", error[1]);
        } finally {
            auditorGetTopesValorRs(rsTopesValor, rqTopesValor, rb.getString("auditoria.consultaTopesValor"), rquid, errorCode, request,
                    rContenido);
        }
    }

    /**
     * HU 231 Funcion encargada de Trazar la Rq de auditorRqGetTopesConvenio
     * 
     * @author andreaflorez
     * @param idRequest
     * @since 01/03/2017
     */
    private void auditorRqGetTopesValor(RutaContenidoBean rContenido, String accion, String idRequest, String portlet, String ipAdress,
            PortletRequest request, String user) {
        try {

            try {// Objeto Auditor Rq
                AuditorRq auditorRq = new AuditorRq();

                auditorRq.setAction(accion);
                auditorRq.setExecutionDate(CommonUtils.getInstance().asXMLGregorianCalendar(new Date()));
                auditorRq.setIpAddress(ipAdress);
                auditorRq.setOriginPortal(rContenido.getBankName());
                auditorRq.setPage(rContenido.getPaginaOrigen());
                auditorRq.setPortlet(portlet);
                auditorRq.setRequestId(idRequest);
                auditorRq.setTipoServicio(RQ);
                auditorRq.setUser(user);
                auditorRq.setCodigoServicioInt(idConvenio);

                // Llamado al m�todo para trazar rq
                TrazaPublisher.getInstance().publish(auditorRq);
            } catch (Exception e) {
                ErrorData errorData = PublisherUtil.getInstance().getErrorData(e, rquid, ExceptionManager.PP_PORTAL_GENERIC_01, user,
                        ExceptionManager.MSG_PORTAL_GENERIC_01 + " Operación: auditorRqGetTopesConvenio", "auditorRqGetTopesConvenio",
                        rContenido.getPortletOrigen(), rContenido.getPaginaOrigen(), rContenido.getPortalOrigen());
                logger.error(errorData, e);
            }

        } catch (Exception e) {
            ErrorData errorData = PublisherUtil.getInstance().getErrorData(e, idRequest, ExceptionManager.PP_PORTAL_GENERIC_01, null,
                    ExceptionManager.MSG_PORTAL_GENERIC_01 + " - Operación: auditorRqGetTopesConvenio, RealizarPagoFacturador",
                    "auditorRqGetTopesConvenio", rContenido.getPortletOrigen(), rContenido.getPaginaOrigen(), rContenido.getPortalOrigen());
            logger.error(errorData, e);
        }
    }

    /**
     * HU 231 Funcion encargada de Trazar del RS de auditorGetTopesConvenioRs
     * 
     * @author andreaflorez
     * @param GetTopesConvenioRs,
     *            GetTopesConvenioRq, accion, idRequest
     * @since 01/03/2017
     */
    private void auditorGetTopesValorRs(GetTopesValorConvenioRs response, GetTopesValorConvenioRq requestExe, String accion,
            String idRequest, String errorcode, PortletRequest reques, RutaContenidoBean rContenido) {
        try {// Objeto Auditor Rq
            AuditorRq auditorRq = new AuditorRq();

            auditorRq.setAction(accion);
            auditorRq.setCodigoServicioInt(response.getCodigoServicio());
            auditorRq.setExecutionDate(CommonUtils.getInstance().asXMLGregorianCalendar(new Date()));
            auditorRq.setIpAddress(requestExe.getIpAddress());
            auditorRq.setOriginPortal(requestExe.getBankInfo().getBankName());
            auditorRq.setPage(requestExe.getRequestPage());
            auditorRq.setPortlet(requestExe.getRequestSender());
            auditorRq.setRequestId(idRequest);
            auditorRq.setTipoServicio(RS);
            auditorRq.setUser(requestExe.getRequestUser());
            auditorRq.setErrorCode(errorcode);

            // Llamado al m�todo para trazar rq
            TrazaPublisher.getInstance().publish(auditorRq);
        } catch (Exception e) {
            ErrorData errorData = PublisherUtil.getInstance().getErrorData(e, rquid, ExceptionManager.PP_PORTAL_GENERIC_01, user,
                    ExceptionManager.MSG_PORTAL_GENERIC_01 + " Operación: auditorGetTopesConvenioRs", "auditorGetTopesConvenioRs",
                    rContenido.getPortletOrigen(), rContenido.getPaginaOrigen(), rContenido.getPortalOrigen());
            logger.error(errorData, e);
        }
    }

    
    public String validarTopes(String valorPagar, RutaContenidoBean rContenido, ResourceBundle rb) {
        String isValidTope = "";
        
        try {
            if (null != this.topesPorValor && !this.topesPorValor.isEmpty()) {
                // Obtiene el tope mínimo y el tope mayor
                Comparator<TopeMedioPagoType> comparatorMax = new Comparator<TopeMedioPagoType>() {
                    @Override
                    public int compare(TopeMedioPagoType o1, TopeMedioPagoType o2) {
                        if (o1.getValorMax() < o2.getValorMax())
                            return -1;
                        if (o1.getValorMax() > o2.getValorMax())
                            return 1;
                        return 0;
                    }
                };

                Comparator<TopeMedioPagoType> comparatorMin = new Comparator<TopeMedioPagoType>() {
                    @Override
                    public int compare(TopeMedioPagoType o1, TopeMedioPagoType o2) {
                        if (o1.getValorMin() < o2.getValorMin())
                            return -1;
                        if (o1.getValorMin() > o2.getValorMin())
                            return 1;
                        return 0;
                    }
                };

                TopeMedioPagoType esMayor = Collections.max(this.topesPorValor, comparatorMax);
                TopeMedioPagoType esMenor = Collections.min(this.topesPorValor, comparatorMin);
                logger.info("valorPagar [validarTopes]: " + valorPagar);
                logger.info("valorMax [validarTopes]: " + esMayor.getValorMax());
                logger.info("valorMin [validarTopes]: " + esMenor.getValorMin());
                
                // Validamos el tope maximo
                if (Double.parseDouble(valorPagar) > esMayor.getValorMax()) {
                    isValidTope = "false";
                }

                // Validamos el tope minimo
                if (Double.parseDouble(valorPagar) < esMenor.getValorMin()) {
                    isValidTope = "false";
                }
            }
            if ("false".equals(isValidTope)) {
                this.mostrarModal(rb.getString("stMensajeErrorTopesValor"), "icon-alert", rb.getString("stMensajeInformacion"));
            }

        } catch (Exception e) {
            ErrorData errorData = PublisherUtil.getInstance().getErrorData(e, rquid, ExceptionManager.PP_PORTAL_GENERIC_01, user,
                    ExceptionManager.MSG_PORTAL_GENERIC_01 + " Operación: validarTopes", "validarTopes", rContenido.getPortletOrigen(),
                    rContenido.getPaginaOrigen(), rContenido.getPortalOrigen());
            logger.error(errorData, e);
        }
        return isValidTope;
    }

    /*
     * Incidencia ventanilla in-habilitada Metodo que consulta la configuracion de la ventanilla de pagos solo cuando se haga un pago por la
     * ventanilla de pagos para saber si esta inactiva y no cargar el html
     */
    public void consultarConfiguracionVentanilla(String convenioId) {
    	logger.info("Consultando configuración ventanilla...");
        ObtenerConfiguracionTaquillaRq obtenerConfiguracionTaquillaRq = null;
        ObtenerConfiguracionTaquillaRs obtenerConfiguracionTaquillaRs = null;
        try {

            // Setters de los atributos necesarias para realizar la operacion de consulta en el MDW
            obtenerConfiguracionTaquillaRq = new ObtenerConfiguracionTaquillaRq();

            obtenerConfiguracionTaquillaRq.setIdConvenio(convenioId);

            logger.info("[REQUEST - obtenerConfiguracionTaquilla] DATA: " + new Gson().toJson(obtenerConfiguracionTaquillaRq));

            String EndPointRESTServiceGetTopesConvenioRq = ConfigurationEndpointRestService.getInstance().getEndpointRestRecaudadores();

            obtenerConfiguracionTaquillaRs = (ObtenerConfiguracionTaquillaRs) WebServiceClientHTTPS
                    .getInstance(ObtenerConfiguracionTaquillaRs.class).procesarRequest(
                            EndPointRESTServiceGetTopesConvenioRq + "obtenerConfiguracionTaquilla", obtenerConfiguracionTaquillaRq);

            logger.info("[RESPONSE - obtenerConfiguracionTaquilla] DATA: " + new Gson().toJson(obtenerConfiguracionTaquillaRs));

            if (obtenerConfiguracionTaquillaRs.getExcepcion() != null
                    && obtenerConfiguracionTaquillaRs.getExcepcion().getCodigo() != null) {
            }

            if ("SUCCESS".equals(obtenerConfiguracionTaquillaRs.getStatus().getStatusCode())) {
                if (!obtenerConfiguracionTaquillaRs.isActivo()) {
                    this.validacionEstadoVentanilla = "INACTIVA";
                } else {
                    this.validacionEstadoVentanilla = "";
                }
            } else {
                logger.info(
                        "Error consultando la configuracion de la ventanilla " + obtenerConfiguracionTaquillaRs.getStatus().getStatusCode()
                                + " " + obtenerConfiguracionTaquillaRs.getStatus().getStatusDesc());
            }
        } catch (Exception e) {
            logger.info("Error consultando la configuracion de la ventanilla " + e.getMessage());
        }
    }
    
    /**
     * RQ29184 Consulta los campos personalizados 
     * @author andres.morales
     * @since 23/08/2018
     * @return {@link List} con los objetos de tipo {@link CustomInvoiceField} que definen los campos personzalidados
     * de la factura
     */
    private List<CustomInvoiceField> obtenerCamposFacturaPersonalizada(ActionRequest request) {
        Gson gson = new Gson();
    	logger.info("CargueArchivoPersonalizado - obtenerCamposFacturaPersonalizada");
		GetCustomInvoiceRs respuesta = null;
		GetCustomInvoiceRq peticion = new GetCustomInvoiceRq();

		PortletSession session = request.getPortletSession();
		ResourceBundle rb = ResourceBundle
				.getBundle("com.portalpagos.realizarpagofact.portlet.nl.RealizarPagoFactV2PortletResource");
		RutaContenidoBean rContenido = (RutaContenidoBean) session.getAttribute("RutaContenidoBean",
				PortletSession.APPLICATION_SCOPE);

		// Auditoria rqGetTopesConvenio
		String accion = rb.getString("auditoria.consultarFacturaPersonalizada");
		String portlet = rb.getString("auditoria.nombrePortlet");
		auditorRqGetFacturaPersonalizada(rContenido, accion, rquid, portlet, ip, user);

		BankInfoType objbanco = new BankInfoType();
		objbanco.setBankName(rContenido.getBankName());
		objbanco.setBankId(rContenido.getBankId());
		peticion.setBankInfo(objbanco);

		peticion.setAgreementId(this.idConvenio);
		peticion.setIpAddress(DatosPagoFactBean.ip);
		peticion.setIdentificationNumber(this.numeroDocumento);
		peticion.setIdentificationType(this.tipoDocumento);
		peticion.setNie(this.referenciaPago);
		peticion.setReference(this.referenciaPago);
		peticion.setRequestID(DatosPagoFactBean.rquid);

		try {
			logger.info("CargueArchivoPersonalizado - se esta obteniendo el endpoint");
			String endPoint = ConfigurationEndpointRestService.getInstance().getEndpointRestClientes();
			logger.info("[REQUEST - getCustomInvoice] DATA: " + gson.toJson(peticion));
			respuesta = (GetCustomInvoiceRs) WebServiceClientHTTPS.getInstance(GetCustomInvoiceRs.class)
					.procesarRequest(endPoint + "getCustomInvoice", peticion);
			logger.info("[RESPONSE - getCustomInvoice] DATA: " + gson.toJson(peticion));
			if (respuesta == null || !respuesta.getStatus().getStatusCode().equals("0")) {
				logger.info("RQ29184 - Ocurrio un error, la respuesta del servicio es nula");
				return new LinkedList<CustomInvoiceField>();
			} else {
				return respuesta.getInvoice();
			}
		} catch (Exception e) {
			ErrorData errorData = PublisherUtil.getInstance().getErrorData(e, rquid,
					ExceptionManager.PP_PORTAL_GENERIC_01, user,
					ExceptionManager.MSG_PORTAL_GENERIC_01 + " Operación: ConsultarFacturaPersonalizada",
					"Consultar los campos de la factura personalizada", rContenido.getPortletOrigen(),
					rContenido.getPaginaOrigen(), rContenido.getBankName());
			logger.error(errorData, e);
			String[] error = ErrorManager.getInstance(request).obtenerErrorWCM(rContenido.getPathErroresTecnicos(),
					ExceptionManager.PP_PORTAL_MIDD_01);
			this.mostrarModal(error[0], "icon-error", error[1]);
			return new LinkedList<CustomInvoiceField>();
		} finally {
			auditorRsGetFacturaPersonalizada(respuesta, peticion, rb.getString("auditoria.consultaTopesValor"), rquid,
					VACIO, rContenido);
		}
	}
    
    /**
    * RQ29184 - Funcion encargada de trazar la auditoria de la consulta de la factura personalizada
    * @param rContenido 
    * @param accion
    * @param idRequest
    * @param portlet
    * @param ipAdress
    * @param request
    * @param user
    */
    private void auditorRqGetFacturaPersonalizada(RutaContenidoBean rContenido, String accion, String idRequest,
			String portlet, String ipAdress, String user) {
		try {
			AuditorRq auditorRq = new AuditorRq();

			auditorRq.setAction(accion);
			auditorRq.setExecutionDate(CommonUtils.getInstance().asXMLGregorianCalendar(new Date()));
			auditorRq.setIpAddress(ipAdress);
			auditorRq.setOriginPortal(rContenido.getBankName());
			auditorRq.setPage(rContenido.getPaginaOrigen());
			auditorRq.setPortlet(portlet);
			auditorRq.setRequestId(idRequest);
			auditorRq.setTipoServicio(RQ);
			auditorRq.setUser(user);
			auditorRq.setCodigoServicioInt(idConvenio);

			// Llamado al metodo para trazar rq
			TrazaPublisher.getInstance().publish(auditorRq);
		} catch (Exception e) {
			ErrorData errorData = PublisherUtil.getInstance().getErrorData(e, rquid,
					ExceptionManager.PP_PORTAL_GENERIC_01, user,
					ExceptionManager.MSG_PORTAL_GENERIC_01 + " Operación: auditorRqGetFacturaPersonalizada",
					"auditorRqGetFacturaPersonalizada", rContenido.getPortletOrigen(), rContenido.getPaginaOrigen(),
					rContenido.getPortalOrigen());
			logger.error(errorData, e);
		}
	}
    
    /**
     * RQ29184 - Funcion encargada de trazar la auditoria de la repuesta de la factura personalizada
     * @param rContenido 
     * @param accion
     * @param idRequest
     * @param portlet
     * @param ipAdress
     * @param request
     * @param user
     */
    private void auditorRsGetFacturaPersonalizada(GetCustomInvoiceRs response, GetCustomInvoiceRq request,
			String accion, String idRequest, String errorcode, RutaContenidoBean rContenido) {
		try {
			
			if(response == null || request == null) {
				logger.info("Operación: auditorRsGetFacturaPersonalizada - La respuesta o peticion son nulas");
				return;
			}
			
			AuditorRq auditorRq = new AuditorRq();
			auditorRq.setAction(accion);
			auditorRq.setCodigoServicioInt(response.getCodigoServicio());
			auditorRq.setExecutionDate(CommonUtils.getInstance().asXMLGregorianCalendar(new Date()));
			auditorRq.setIpAddress(request.getIpAddress());
			auditorRq.setOriginPortal(request.getBankInfo().getBankName());
			auditorRq.setPage(request.getRequestPage());
			auditorRq.setPortlet(request.getRequestSender());
			auditorRq.setRequestId(idRequest);
			auditorRq.setTipoServicio(RS);
			auditorRq.setUser(request.getRequestUser());
			auditorRq.setErrorCode(errorcode);

			// Llamado al metodo para trazar rs
			TrazaPublisher.getInstance().publish(auditorRq);
		} catch (Exception e) {
			ErrorData errorData = PublisherUtil.getInstance().getErrorData(e, rquid,
					ExceptionManager.PP_PORTAL_GENERIC_01, user,
					ExceptionManager.MSG_PORTAL_GENERIC_01 + " Operación: auditorRsGetFacturaPersonalizada",
					"auditorRsGetFacturaPersonalizada", rContenido.getPortletOrigen(), rContenido.getPaginaOrigen(),
					rContenido.getPortalOrigen());
			logger.error(errorData, e);
		}
	}
    public void cargarImagenesMedioPago() {
    	WCMCliente cliente2;
		ResourceBundle rbPortlet = ResourceBundle.getBundle("com.portalpagos.realizarpagofact.portlet.nl.RealizarPagoFactV2PortletResource");
		try {
			PortletSession session = request.getPortletSession();
			RutaContenidoBean rContenido = (RutaContenidoBean) session.getAttribute("RutaContenidoBean", PortletSession.APPLICATION_SCOPE);
			String rutaConteniodo = rContenido.getPathImagenMedioPago();
			
			if(rContenido.getPortalOrigen().equals("BALOTO")) {
				cliente2 = new WCMCliente("/Baloto"+rutaConteniodo);
			}else {
				cliente2 = new WCMCliente("/PortalPagosAval"+rutaConteniodo);
			}
			
			logger.info("rContenido.getPathImagenMedioPago(): "+rutaConteniodo);
			logger.info("Cliente2: "+cliente2);
			
			for (int i = 0; i<mediosPago.size(); i++) {
				String medioPagoUrl = ((ImageComponent) cliente2.getComponent("imgMedioPago"+mediosPago.get(i).getMpId())).getResourceURL();
				
				if(medioPagoUrl != null) {
					
					medioPagoUrl = medioPagoUrl.replaceAll("/myconnect/", "/connect/");
					mediosPago.get(i).setMpImagen(medioPagoUrl);
					
					if(mediosPago.get(i).getMpId().equals("4")) {
						mediosPago.get(i).setMpTextoImagen("<p>QR</p>");
					}else {
						mediosPago.get(i).setMpTextoImagen(rbPortlet.getString("stMensajeMedioPago" + mediosPago.get(i).getMpId()));	
					}
				}
			}
			
			// Organizamos la lista
            Collections.sort(mediosPago, new Comparator<MedioPagoType>() {
                @Override
                public int compare(MedioPagoType o1, MedioPagoType o2) {                	
                    return o1.getMpMedioPago().substring(0, 3).toUpperCase().compareTo(o2.getMpMedioPago().substring(0, 3).toUpperCase());
                }
            });
			
		} catch (WCMException e) {
			logger.error("error wcm medio pago: ",e);			
		}
    }
}
